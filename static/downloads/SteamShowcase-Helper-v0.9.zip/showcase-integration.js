(() => {
  const SITE = 'https://steamshowcase.up.railway.app/';
  const openSite = () => chrome.tabs.create({ url: SITE });
  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('open-showcase')?.addEventListener('click', openSite);
  });
})();
