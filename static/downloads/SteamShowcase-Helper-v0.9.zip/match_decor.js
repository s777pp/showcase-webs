document.addEventListener('DOMContentLoaded', () => {
  document.documentElement.classList.add('sds-popup-ready');
  // Popup width is controlled by popup.css. Do not override it here.
});
