document.addEventListener('DOMContentLoaded', function() {
    const header = document.querySelector('.header-container');
    if (!header) return;

    // Создаем несколько слоев волн для эффекта глубины
    for (let i = 0; i < 3; i++) {
        const wave = document.createElement('div');
        wave.className = 'wave-layer';
        
        wave.style.height = `${80 - i*20}px`;
        wave.style.bottom = `${-10 + i*5}px`;
        wave.style.opacity = `${0.3 - i*0.1}`;
        wave.style.animationDuration = `${15 + i*5}s`;
        wave.style.zIndex = `${1 + i}`;
        wave.style.backgroundSize = `${50 + i*10}% ${80 - i*20}px`;
        
        header.appendChild(wave);
    }
});