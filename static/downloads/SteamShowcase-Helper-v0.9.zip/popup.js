document.addEventListener('DOMContentLoaded', function() {
  const CONFIG = {
    translations: {
      ru: {
        eyebrow: "STEAM PROFILE TOOLS",
        title: "SteamShowcase Helper",
        heroDescription: "Витрины, подготовка контента и автоматизация Steam в одном окне.",
        processTop: "Обработать",
        openShowcase: "Открыть Showcase Maker",
        steamTools: "Steam tools",
        original: "ORIGINAL + SHOWCASE",
        artworkTitle: "Витрина иллюстраций",
        artworkDesc: "Автоматическая загрузка Artwork.",
        workshopTitle: "Мастерская Steam",
        workshopDesc: "Автозаполнение Workshop.",
        screenshotsTitle: "Витрина скриншотов",
        screenshotsDesc: "Подготовка Screenshot Showcase.",
        guidesTitle: "Руководства Steam",
        guidesDesc: "Guide без привязки к игре.",
        upload: "Загрузить",
        choose: "Выбрать",
        footerText: "SteamShowcase Helper · n1t1337",
        website: "Website", discord: "Discord", steamSocial: "Steam", youtube: "YouTube", tiktok: "TikTok", telegram: "Telegram",
        selectPlaceholder: "Выберите тематику"
      },
      en: {
        eyebrow: "STEAM PROFILE TOOLS",
        title: "SteamShowcase Helper",
        heroDescription: "Showcases, content preparation and Steam automation in one window.",
        processTop: "Process",
        openShowcase: "Open Showcase Maker",
        steamTools: "Steam tools",
        original: "ORIGINAL + SHOWCASE",
        artworkTitle: "Artwork Showcase",
        artworkDesc: "Automatic Artwork upload.",
        workshopTitle: "Steam Workshop",
        workshopDesc: "Automatic Workshop preparation.",
        screenshotsTitle: "Screenshot Showcase",
        screenshotsDesc: "Screenshot Showcase preparation.",
        guidesTitle: "Steam Guides",
        guidesDesc: "Guide without game binding.",
        upload: "Upload",
        choose: "Choose",
        footerText: "SteamShowcase Helper · n1t1337",
        website: "Website", discord: "Discord", steamSocial: "Steam", youtube: "YouTube", tiktok: "TikTok", telegram: "Telegram",
        selectPlaceholder: "Select theme"
      }
    },
    soundPaths: {
      hover: "sounds/hover.mp3",
      click: "sounds/click.mp3",
      easterEgg: "sounds/easter-egg.mp3",
      miniGameOpen: "sounds/mini-game-open.wav",
      miniGameHit: "sounds/mini-game-hit.wav",
      miniGameMiss: "sounds/mini-game-miss.wav",
      miniGameCombo: "sounds/mini-game-combo.wav"
    },
    themes: [
      { value: "", label: "-Тематика не выбрана-", labelEn: "-No theme selected-" },
      { value: "753", label: "На тематику Steam", labelEn: "Steam theme" },
      { value: "765", label: "На тематику Greenlight", labelEn: "Greenlight theme" },
      { value: "1840", label: "На тематику Source Filmmaker", labelEn: "Source Filmmaker theme" },
      { value: "202352", label: "Без тематики", labelEn: "No theme" }
    ],
    uiThemes: [
      { id: "default", name: "SteamShowcase", btnIcon: "fa-palette" },
      { id: "deepOcean", name: "Deep Ocean", btnIcon: "fa-water" },
      { id: "softAurora", name: "Soft Aurora", btnIcon: "fa-wand-magic-sparkles" },
      { id: "emberViolet", name: "Ember Violet", btnIcon: "fa-fire-flame-curved" },
      { id: "graphiteGold", name: "Graphite Gold", btnIcon: "fa-gem" },
      { id: "monoChrome", name: "Monochrome", btnIcon: "fa-circle-half-stroke" },
      { id: "neonNoir", name: "Neon Noir", btnIcon: "fa-bolt" }
    ]
  };

  // Звуковые элементы
  const hoverSound = new Audio(CONFIG.soundPaths.hover);
  const clickSound = new Audio(CONFIG.soundPaths.click);
  const easterEggSound = new Audio(CONFIG.soundPaths.easterEgg);
  const miniGameOpenSound = new Audio(CONFIG.soundPaths.miniGameOpen);
  const miniGameHitSound = new Audio(CONFIG.soundPaths.miniGameHit);
  const miniGameMissSound = new Audio(CONFIG.soundPaths.miniGameMiss);
  const miniGameComboSound = new Audio(CONFIG.soundPaths.miniGameCombo);

  // Текущая тема интерфейса
  let currentUITheme = 'default';
  let currentLang = localStorage.getItem('language') || 'ru';

  function getUITheme(themeId = currentUITheme) {
    return CONFIG.uiThemes.find(t => t.id === themeId) || CONFIG.uiThemes[0];
  }


  function persistUITheme(themeId) {
    localStorage.setItem('uiTheme', themeId);
    if (chrome?.storage?.local) {
      chrome.storage.local.set({ uiTheme: themeId });
    }
  }

  /**
   * Воспроизводит звук с обработкой ошибок.
   */
  function playSound(sound, volume = 0.12) {
    if (!sound || !sound.src) {
      console.error("Аудиофайл не загружен");
      return;
    }

    sound.currentTime = 0;
    sound.volume = Math.max(0, Math.min(1, volume));
    sound.play().catch((error) => {
      console.error("Ошибка воспроизведения звука:", error);
    });
  }

  /**
   * Применяет переводы к элементам интерфейса.
   */
  function applyTranslations(lang) {
    const safeLang = CONFIG.translations[lang] ? lang : 'ru';
    const translations = CONFIG.translations[safeLang];
    document.documentElement.lang = safeLang;

    document.querySelectorAll('[data-i18n]').forEach((element) => {
      const key = element.dataset.i18n;
      if (Object.prototype.hasOwnProperty.call(translations, key)) {
        element.textContent = translations[key];
      }
    });

    document.querySelectorAll('[data-i18n-title]').forEach((element) => {
      const key = element.dataset.i18nTitle;
      if (Object.prototype.hasOwnProperty.call(translations, key)) {
        element.setAttribute('title', translations[key]);
      }
    });

    document.querySelectorAll('[data-i18n-aria]').forEach((element) => {
      const key = element.dataset.i18nAria;
      if (Object.prototype.hasOwnProperty.call(translations, key)) {
        element.setAttribute('aria-label', translations[key]);
      }
    });

    // Обновляем подпись на кнопке переключения языка.
    const switcher = document.getElementById('language-switcher');
    const langText = switcher?.querySelector('.language-text');
    if (langText) langText.textContent = safeLang === 'ru' ? 'RU' : 'EN';

    // Обновляем варианты выбора тематики в существующем select, если он открыт.
    const themeSelect = document.getElementById('theme-select');
    if (themeSelect) {
      CONFIG.themes.forEach((theme, index) => {
        const option = themeSelect.options[index];
        if (option) option.textContent = safeLang === 'en' ? theme.labelEn : theme.label;
      });
    }
  }

  /**
   * Переключает язык интерфейса.
   */
  function switchLanguage(lang) {
    currentLang = CONFIG.translations[lang] ? lang : 'ru';
    applyTranslations(currentLang);
    localStorage.setItem("language", lang);
    if (chrome?.storage?.local) chrome.storage.local.set({ language: lang });
    const switcher = document.getElementById("language-switcher");
    if (switcher) {
      const langText = switcher.querySelector(".language-text");
      if (langText) {
        langText.textContent = lang === "ru" ? "RU" : "EN";
      }
    }
  }

  /**
   * Внедряет скрипт на страницу.
   */
  function injectScript(tabId, scriptFile, message) {
    if (!chrome.scripting) {
      console.error("Scripting API not available");
      return Promise.resolve(false);
    }

    return chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      files: [scriptFile]
    }).then(() => {
      console.log(message);
      return true;
    }).catch((error) => {
      console.error("Ошибка при внедрении скрипта:", error);
      return false;
    });
  }

  async function setActiveTool(tool) {
    try {
      if (chrome?.storage?.session) {
        await chrome.storage.session.set({ sshActiveTool: tool });
      } else if (chrome?.storage?.local) {
        await chrome.storage.local.set({ sshActiveTool: tool });
      }
    } catch (error) {
      console.error("Не удалось сохранить активный инструмент:", error);
    }
  }

  function openToolTab(url, tool, scriptFile, message, afterInject) {
    setActiveTool(tool).finally(() => {
      chrome.tabs.create({ url }, (tab) => {
        if (!tab?.id) return;
        const tabId = tab.id;
        let done = false;
        const run = async () => {
          if (done) return;
          done = true;
          if (scriptFile) await injectScript(tabId, scriptFile, message);
          if (typeof afterInject === 'function') afterInject(tabId);
        };
        const listener = (updatedTabId, changeInfo) => {
          if (updatedTabId === tabId && changeInfo.status === 'complete') {
            chrome.tabs.onUpdated.removeListener(listener);
            run();
          }
        };
        chrome.tabs.onUpdated.addListener(listener);
        setTimeout(() => {
          chrome.tabs.get(tabId, (fresh) => {
            if (chrome.runtime.lastError || !fresh) return;
            if (fresh.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              run();
            }
          });
        }, 1500);
      });
    });
  }

  function applyScreenshotMainWorldCommand(tabId) {
    if (!chrome.scripting) return;

    chrome.scripting.executeScript(
      {
        target: { tabId, allFrames: true },
        world: 'MAIN',
        func: () => {
          if (typeof $J !== 'function') return;
          $J('#image_width').val(1000).attr('id',''),$J('#image_height').val(1).attr('id',''),$J('[name=file_type]').val(5);
          $J('#title,[name=title]').val(' ᠌᠌ ᠌᠌ ᠌᠌ ᠌᠌ ᠌᠌ ᠌').trigger('input').trigger('change');
          $J('#agree_terms,[name=agree_terms]').prop('checked', true).attr('checked','checked').trigger('change');
        }
      },
      () => {
        if (chrome.runtime.lastError) {
          console.error("Ошибка при применении параметров скриншотов:", chrome.runtime.lastError);
        }
      }
    );
  }

  /**
   * Переключает тему интерфейса.
   */
  function switchUITheme() {
    const themes = CONFIG.uiThemes;
    const currentIndex = themes.findIndex(t => t.id === currentUITheme);
    const nextIndex = (currentIndex + 1) % themes.length;
    const nextTheme = themes[nextIndex];
    
    currentUITheme = nextTheme.id;
    persistUITheme(currentUITheme);
    
    
    applyUITheme(nextTheme.id);
  }

  /**
   * Применяет выбранную тему интерфейса.
   */
  function applyUITheme(themeId) {
    const root = document.documentElement;
    
    // Сбрасываем все CSS-переменные
    root.style.removeProperty('--primary-bg');
    root.style.removeProperty('--primary-text');
    root.style.removeProperty('--accent-color');
    root.style.removeProperty('--accent-hover');
    root.style.removeProperty('--accent-gradient');
    root.style.removeProperty('--accent-gradient-hover');
    root.style.removeProperty('--card-bg');
    root.style.removeProperty('--card-border');
    root.style.removeProperty('--ambient-overlay');
    root.style.removeProperty('--card-icon-bg');
    root.style.removeProperty('--card-icon-border');
    root.style.removeProperty('--card-icon-color');
    
    // Применяем новую тему
    switch(themeId) {
      case 'default':
        root.style.setProperty('--primary-bg', 'linear-gradient(160deg, #07111c 0%, #0c1b2c 48%, #0a1622 100%)');
        root.style.setProperty('--primary-text', '#f3f7fb');
        root.style.setProperty('--accent-color', '#66c0f4');
        root.style.setProperty('--accent-hover', '#8fd3ff');
        root.style.setProperty('--accent-gradient', 'linear-gradient(135deg, #66c0f4, #3a9fd8)');
        root.style.setProperty('--accent-gradient-hover', 'linear-gradient(135deg, #8fd3ff, #66c0f4)');
        root.style.setProperty('--card-bg', 'rgba(16, 36, 56, 0.72)');
        root.style.setProperty('--card-border', '1px solid rgba(102, 192, 244, 0.16)');
        root.style.setProperty('--ambient-overlay', 'radial-gradient(circle at 16% 10%, rgba(102,192,244,0.16), transparent 34%), radial-gradient(circle at 88% 82%, rgba(47,127,184,0.14), transparent 32%)');
        root.style.setProperty('--card-icon-bg', 'linear-gradient(135deg, rgba(102,192,244,0.22), rgba(47,127,184,0.16))');
        root.style.setProperty('--card-icon-border', '1px solid rgba(102,192,244,0.28)');
        root.style.setProperty('--card-icon-color', '#e8f7ff');
        break;
      case 'deepOcean':
        root.style.setProperty('--primary-bg', 'linear-gradient(135deg, #06121f 0%, #12375b 45%, #0a2b34 100%)');
        root.style.setProperty('--primary-text', '#f8f8f8');
        root.style.setProperty('--accent-color', '#7fe7ff');
        root.style.setProperty('--accent-hover', '#c5fff6');
        root.style.setProperty('--accent-gradient', 'linear-gradient(135deg, #7fe7ff, #2f8cff 58%, #44d7b6)');
        root.style.setProperty('--accent-gradient-hover', 'linear-gradient(135deg, #b7fbff, #6aa7ef 58%, #75f0d1)');
        root.style.setProperty('--card-bg', 'rgba(17, 53, 77, 0.48)');
        root.style.setProperty('--card-border', '1px solid rgba(127, 231, 255, 0.28)');
        root.style.setProperty('--ambient-overlay', 'radial-gradient(circle at 18% 18%, rgba(68, 215, 182, 0.18) 0%, transparent 42%), radial-gradient(circle at 82% 78%, rgba(47, 140, 255, 0.18) 0%, transparent 44%)');
        root.style.setProperty('--card-icon-bg', 'linear-gradient(135deg, rgba(127, 231, 255, 0.35), rgba(68, 215, 182, 0.24))');
        root.style.setProperty('--card-icon-border', '1px solid rgba(127, 231, 255, 0.42)');
        root.style.setProperty('--card-icon-color', '#e6ffff');
        break;
        
      case 'softAurora':
        root.style.setProperty('--primary-bg', 'linear-gradient(135deg, #121b31 0%, #263758 42%, #173f3c 100%)');
        root.style.setProperty('--primary-text', '#e2f3f5');
        root.style.setProperty('--accent-color', '#9ff4d2');
        root.style.setProperty('--accent-hover', '#f5d7ff');
        root.style.setProperty('--accent-gradient', 'linear-gradient(135deg, #9ff4d2, #7eb7ff 55%, #d69cff)');
        root.style.setProperty('--accent-gradient-hover', 'linear-gradient(135deg, #cbffe9, #a7ccff 55%, #efc2ff)');
        root.style.setProperty('--card-bg', 'rgba(34, 62, 88, 0.42)');
        root.style.setProperty('--card-border', '1px solid rgba(159, 244, 210, 0.27)');
        root.style.setProperty('--ambient-overlay', 'radial-gradient(circle at 24% 20%, rgba(159, 244, 210, 0.16) 0%, transparent 42%), radial-gradient(circle at 78% 76%, rgba(214, 156, 255, 0.16) 0%, transparent 44%)');
        root.style.setProperty('--card-icon-bg', 'linear-gradient(135deg, rgba(159, 244, 210, 0.32), rgba(214, 156, 255, 0.22))');
        root.style.setProperty('--card-icon-border', '1px solid rgba(194, 232, 255, 0.4)');
        root.style.setProperty('--card-icon-color', '#f7fbff');
        break;

      case 'emberViolet':
        root.style.setProperty('--primary-bg', 'linear-gradient(135deg, #1b1424 0%, #3b2443 44%, #2d1b1f 100%)');
        root.style.setProperty('--primary-text', '#fff8f4');
        root.style.setProperty('--accent-color', '#ffb46f');
        root.style.setProperty('--accent-hover', '#ffd6a8');
        root.style.setProperty('--accent-gradient', 'linear-gradient(135deg, #ffb46f, #ff6f91 58%, #9d7cff)');
        root.style.setProperty('--accent-gradient-hover', 'linear-gradient(135deg, #ffd3a0, #ff8aa8 58%, #c2adff)');
        root.style.setProperty('--card-bg', 'rgba(54, 35, 63, 0.44)');
        root.style.setProperty('--card-border', '1px solid rgba(255, 180, 111, 0.25)');
        root.style.setProperty('--ambient-overlay', 'radial-gradient(circle at 18% 24%, rgba(255, 111, 145, 0.16) 0%, transparent 42%), radial-gradient(circle at 82% 72%, rgba(157, 124, 255, 0.16) 0%, transparent 44%)');
        root.style.setProperty('--card-icon-bg', 'linear-gradient(135deg, rgba(255, 180, 111, 0.34), rgba(157, 124, 255, 0.22))');
        root.style.setProperty('--card-icon-border', '1px solid rgba(255, 214, 168, 0.36)');
        root.style.setProperty('--card-icon-color', '#fff9f1');
        break;

      case 'graphiteGold':
        root.style.setProperty('--primary-bg', 'linear-gradient(135deg, #101820 0%, #25313a 48%, #182737 100%)');
        root.style.setProperty('--primary-text', '#f6f4ea');
        root.style.setProperty('--accent-color', '#ffd66b');
        root.style.setProperty('--accent-hover', '#ffefb3');
        root.style.setProperty('--accent-gradient', 'linear-gradient(135deg, #ffd66b, #73d8ff 58%, #6de0aa)');
        root.style.setProperty('--accent-gradient-hover', 'linear-gradient(135deg, #ffefb3, #9ee5ff 58%, #95f0c9)');
        root.style.setProperty('--card-bg', 'rgba(31, 43, 51, 0.48)');
        root.style.setProperty('--card-border', '1px solid rgba(255, 214, 107, 0.24)');
        root.style.setProperty('--ambient-overlay', 'radial-gradient(circle at 20% 24%, rgba(255, 214, 107, 0.14) 0%, transparent 42%), radial-gradient(circle at 84% 72%, rgba(115, 216, 255, 0.16) 0%, transparent 44%)');
        root.style.setProperty('--card-icon-bg', 'linear-gradient(135deg, rgba(255, 214, 107, 0.34), rgba(115, 216, 255, 0.22))');
        root.style.setProperty('--card-icon-border', '1px solid rgba(255, 239, 179, 0.36)');
        root.style.setProperty('--card-icon-color', '#fffbe8');
        break;

      case 'monoChrome':
        root.style.setProperty('--primary-bg', 'linear-gradient(135deg, #0b0d10 0%, #181c22 48%, #111418 100%)');
        root.style.setProperty('--primary-text', '#f4f5f7');
        root.style.setProperty('--accent-color', '#f2f4f8');
        root.style.setProperty('--accent-hover', '#ffffff');
        root.style.setProperty('--accent-gradient', 'linear-gradient(135deg, #f8fafc, #a7adb7 58%, #5f6875)');
        root.style.setProperty('--accent-gradient-hover', 'linear-gradient(135deg, #ffffff, #c8cdd6 58%, #7a8492)');
        root.style.setProperty('--card-bg', 'rgba(28, 32, 38, 0.58)');
        root.style.setProperty('--card-border', '1px solid rgba(232, 236, 243, 0.24)');
        root.style.setProperty('--ambient-overlay', 'radial-gradient(circle at 20% 24%, rgba(255,255,255,0.13) 0%, transparent 42%), radial-gradient(circle at 84% 72%, rgba(160,170,184,0.12) 0%, transparent 44%)');
        root.style.setProperty('--card-icon-bg', 'linear-gradient(135deg, rgba(255,255,255,0.24), rgba(130,140,154,0.22))');
        root.style.setProperty('--card-icon-border', '1px solid rgba(255,255,255,0.28)');
        root.style.setProperty('--card-icon-color', '#f7f8fa');
        break;

      case 'neonNoir':
        root.style.setProperty('--primary-bg', 'linear-gradient(135deg, #090d18 0%, #18122a 46%, #071d25 100%)');
        root.style.setProperty('--primary-text', '#f7fbff');
        root.style.setProperty('--accent-color', '#7df9ff');
        root.style.setProperty('--accent-hover', '#ff9de7');
        root.style.setProperty('--accent-gradient', 'linear-gradient(135deg, #7df9ff, #7c7cff 52%, #ff8bd8)');
        root.style.setProperty('--accent-gradient-hover', 'linear-gradient(135deg, #b7ffff, #9b9cff 52%, #ffafe6)');
        root.style.setProperty('--card-bg', 'rgba(21, 27, 48, 0.58)');
        root.style.setProperty('--card-border', '1px solid rgba(125, 249, 255, 0.24)');
        root.style.setProperty('--ambient-overlay', 'radial-gradient(circle at 18% 22%, rgba(125,249,255,0.14) 0%, transparent 42%), radial-gradient(circle at 82% 74%, rgba(255,139,216,0.14) 0%, transparent 44%)');
        root.style.setProperty('--card-icon-bg', 'linear-gradient(135deg, rgba(125,249,255,0.26), rgba(255,139,216,0.18))');
        root.style.setProperty('--card-icon-border', '1px solid rgba(125,249,255,0.34)');
        root.style.setProperty('--card-icon-color', '#f7fbff');
        break;
        
      default: // SteamShowcase site theme
        root.style.setProperty('--primary-bg', 'linear-gradient(160deg, #07111c 0%, #0c1b2c 48%, #0a1622 100%)');
        root.style.setProperty('--primary-text', '#f3f7fb');
        root.style.setProperty('--accent-color', '#66c0f4');
        root.style.setProperty('--accent-hover', '#8fd3ff');
        root.style.setProperty('--accent-gradient', 'linear-gradient(135deg, #66c0f4, #3a9fd8)');
        root.style.setProperty('--accent-gradient-hover', 'linear-gradient(135deg, #8fd3ff, #66c0f4)');
        root.style.setProperty('--card-bg', 'rgba(16, 36, 56, 0.72)');
        root.style.setProperty('--card-border', '1px solid rgba(102, 192, 244, 0.16)');
        root.style.setProperty('--ambient-overlay', 'radial-gradient(circle at 16% 10%, rgba(102,192,244,0.16), transparent 34%), radial-gradient(circle at 88% 82%, rgba(47,127,184,0.14), transparent 32%)');
        root.style.setProperty('--card-icon-bg', 'linear-gradient(135deg, rgba(102,192,244,0.22), rgba(47,127,184,0.16))');
        root.style.setProperty('--card-icon-border', '1px solid rgba(102,192,244,0.28)');
        root.style.setProperty('--card-icon-color', '#e8f7ff');

    }
  }

  /**
   * Устанавливает начальную тему и язык.
   */
  function setInitialThemeAndLanguage() {
    const savedLang = CONFIG.translations[localStorage.getItem("language")] ? localStorage.getItem("language") : "ru";
    const savedUITheme = "default";

    // Применяем UI тему
    currentUITheme = savedUITheme;
    applyUITheme(currentUITheme);
    

    switchLanguage(savedLang);

    if (chrome?.storage?.local) {
      chrome.storage.local.get({ uiTheme: savedUITheme }, ({ uiTheme }) => {
        if (!uiTheme || uiTheme === currentUITheme) return;
        currentUITheme = uiTheme;
        localStorage.setItem('uiTheme', currentUITheme);
        applyUITheme(currentUITheme);
      });
    }
  }

  /**
   * Создает выпадающий список тематик
   */
  function createThemeSelect(card, button4) {
    const selectContainer = document.createElement('div');
    selectContainer.className = 'theme-select-container';
    
    const select = document.createElement('select');
    select.id = 'theme-select';
    select.innerHTML = CONFIG.themes.map((theme) => {
      const label = currentLang === 'en' ? theme.labelEn : theme.label;
      return `<option value="${theme.value}">${label}</option>`;
    }).join('');
    
    selectContainer.appendChild(select);
    card.appendChild(selectContainer);
    
    selectContainer.classList.add('visible');
    selectContainer.style.opacity = '1';
    selectContainer.style.transform = 'translateY(0)';
    selectContainer.style.height = 'auto';
    
    const openNativePicker = () => {
      select.focus();
      if (typeof select.showPicker === 'function') {
        try {
          select.showPicker();
        } catch (error) {
          console.debug('Native select picker is unavailable:', error);
        }
      }
    };
    
    openNativePicker();
    
    // Обработчик выбора
    select.addEventListener('change', (event) => {
      if (event.target.value) {
        playSound(clickSound);
        setTimeout(() => {
          openToolTab(
            `https://steamcommunity.com/sharedfiles/editguide/?appid=${event.target.value}`,
            "guide",
            "content_button3.js",
            "Guide script injected"
          );
          removeThemeSelect(card, button4);
        }, 300);
      }
    });
    
    // Возвращаем кнопку при клике вне select
    const handleClickOutside = (e) => {
      if (!card.contains(e.target)) {
        removeThemeSelect(card, button4);
        document.removeEventListener('click', handleClickOutside);
      }
    };
    
    setTimeout(() => {
      document.addEventListener('click', handleClickOutside);
    }, 100);
  }

  /**
   * Удаляет выпадающий список и возвращает кнопку
   */
  function removeThemeSelect(card, button4) {
    const selectContainer = card.querySelector('.theme-select-container');
    if (!selectContainer) return;
    
    selectContainer.classList.remove('visible');
    selectContainer.style.opacity = '0';
    selectContainer.style.transform = 'translateY(-10px)';
    selectContainer.style.height = '0';
    
    setTimeout(() => {

      
      setTimeout(() => {
        selectContainer.remove();
      }, 300);
    }, 300);
  }

  // Инициализация кнопок
  function initButtons() {
    // Кнопка языка
    const langButton = document.getElementById('language-switcher');
    if (langButton) {
      langButton.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        switchLanguage(currentLang === 'ru' ? 'en' : 'ru');
        playSound(clickSound);
      });
    }

    // Основные Steam tools — кликабельны целиком, без отдельных кнопок.
    const openSteamTool = (element, handler) => {
      if (!element) return;
      const activate = (event) => {
        if (event?.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
        event?.preventDefault();
        handler();
        playSound(clickSound);
      };
      element.addEventListener('click', activate);
      element.addEventListener('keydown', activate);
    };

    openSteamTool(document.getElementById('button1'), () => {
      openToolTab(
        "https://steamcommunity.com/sharedfiles/edititem/767/3/",
        "artwork",
        "content_button1.js",
        "Artwork script injected"
      );
    });

    openSteamTool(document.getElementById('button2'), () => {
      openToolTab(
        "https://steamcommunity.com/workshop/edititem/767/3/",
        "workshop",
        "content_button2.js",
        "Workshop script injected"
      );
    });

    openSteamTool(document.getElementById('button3'), () => {
      openToolTab(
        "https://steamcommunity.com/sharedfiles/edititem/767/3/",
        "screenshot",
        "content_screenshot_showcase.js",
        "Screenshot script injected",
        (tabId) => applyScreenshotMainWorldCommand(tabId)
      );
    });

    openSteamTool(document.getElementById('button4'), () => {
      const card = document.getElementById('button4');
      if (!card || card.querySelector('.theme-select-container')) return;
      createThemeSelect(card, card);
    });

    document.getElementById('button5')?.addEventListener('click', (event) => {
      event.preventDefault();
      chrome.tabs.create({ url: 'https://t.me/SteamMakerBot' });
      playSound(clickSound);
    });

    // Звуковые эффекты при наведении
    document.querySelectorAll("button").forEach((button) => {
      button.addEventListener("mouseenter", () => playSound(hoverSound, 0.2));
    });
  }

  // Основная инициализация
  function initMiniPong() {
    const shell = document.getElementById("mini-pong");
    const closeBtn = document.getElementById("mini-pong-close");
    const canvas = document.getElementById("mini-pong-canvas");
    if (!shell || !canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const paddleH = 28;
    const paddleW = 5;
    const ballSize = 5;
    const state = {
      leftY: (height - paddleH) / 2,
      rightY: (height - paddleH) / 2,
      ballX: width / 2,
      ballY: height / 2,
      ballVX: 1.08,
      ballVY: 0.82,
      leftScore: 0,
      rightScore: 0,
      hits: 0,
      running: false,
      frame: null
    };

    function clamp(value, min, max) {
      return Math.max(min, Math.min(max, value));
    }

    function resetBall(direction = 1) {
      state.ballX = width / 2;
      state.ballY = height / 2;
      state.hits = 0;
      state.ballVX = 1.08 * direction;
      state.ballVY = (Math.random() > 0.5 ? 1 : -1) * (0.68 + Math.random() * 0.42);
    }

    function drawRoundedRect(x, y, w, h, r, color) {
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, r);
      ctx.fill();
    }

    function draw() {
      ctx.clearRect(0, 0, width, height);

      const bg = ctx.createLinearGradient(0, 0, width, height);
      bg.addColorStop(0, "rgba(102, 192, 244, 0.08)");
      bg.addColorStop(1, "rgba(255, 255, 255, 0.02)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);

      ctx.strokeStyle = "rgba(143, 211, 255, 0.22)";
      ctx.setLineDash([3, 5]);
      ctx.beginPath();
      ctx.moveTo(width / 2, 8);
      ctx.lineTo(width / 2, height - 8);
      ctx.stroke();
      ctx.setLineDash([]);

      drawRoundedRect(10, state.leftY, paddleW, paddleH, 3, "rgba(143, 211, 255, 0.95)");
      drawRoundedRect(width - 15, state.rightY, paddleW, paddleH, 3, "rgba(255, 255, 255, 0.82)");

      ctx.fillStyle = "rgba(255, 255, 255, 0.95)";
      ctx.shadowColor = "rgba(102, 192, 244, 0.9)";
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(state.ballX, state.ballY, ballSize, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.font = "700 13px Segoe UI, sans-serif";
      ctx.textAlign = "center";
      ctx.fillStyle = "rgba(255, 255, 255, 0.36)";
      ctx.fillText(String(state.leftScore), width / 2 - 18, 18);
      ctx.fillText(String(state.rightScore), width / 2 + 18, 18);
    }

    function drawIdle() {
      state.leftY = (height - paddleH) / 2;
      state.rightY = (height - paddleH) / 2;
      state.ballX = width / 2;
      state.ballY = height / 2;
      draw();
    }

    function accelerateBall() {
      state.hits += 1;
      const cap = 3.35;
      const currentSpeed = Math.hypot(state.ballVX, state.ballVY) || 1;
      const nextSpeed = Math.min(cap, currentSpeed + 0.14);
      const scale = nextSpeed / currentSpeed;
      state.ballVX *= scale;
      state.ballVY *= scale;
    }

    function step() {
      state.rightY += (state.ballY - (state.rightY + paddleH / 2)) * 0.08;
      state.rightY = clamp(state.rightY, 4, height - paddleH - 4);

      state.ballX += state.ballVX;
      state.ballY += state.ballVY;

      if (state.ballY <= ballSize + 3 || state.ballY >= height - ballSize - 3) {
        state.ballVY *= -1;
      }

      const leftHit = state.ballX <= 18
        && state.ballY >= state.leftY
        && state.ballY <= state.leftY + paddleH;
      const rightHit = state.ballX >= width - 18
        && state.ballY >= state.rightY
        && state.ballY <= state.rightY + paddleH;

      if (leftHit || rightHit) {
        state.ballVX *= -1;
        const paddleY = leftHit ? state.leftY : state.rightY;
        state.ballVY += (state.ballY - (paddleY + paddleH / 2)) * 0.035;
        accelerateBall();
      }

      if (state.ballX < -10) {
        state.rightScore = (state.rightScore + 1) % 10;
        resetBall(1);
      } else if (state.ballX > width + 10) {
        state.leftScore = (state.leftScore + 1) % 10;
        resetBall(-1);
      }

      draw();
      if (state.running) {
        state.frame = requestAnimationFrame(step);
      }
    }

    function startGame() {
      if (state.running) return;
      state.running = true;
      resetBall(Math.random() > 0.5 ? 1 : -1);
      state.frame = requestAnimationFrame(step);
    }

    function stopGame() {
      state.running = false;
      if (state.frame !== null) {
        cancelAnimationFrame(state.frame);
        state.frame = null;
      }
      drawIdle();
    }

    function openGame() {
      if (shell.classList.contains("is-open")) return;
      shell.classList.remove("is-collapsed");
      shell.classList.add("is-open");
      setTimeout(startGame, 180);
    }

    function closeGame(event) {
      if (event) event.stopPropagation();
      shell.classList.remove("is-open");
      shell.classList.add("is-collapsed");
      stopGame();
    }

    canvas.addEventListener("pointermove", (event) => {
      if (!state.running) return;
      const rect = canvas.getBoundingClientRect();
      const y = ((event.clientY - rect.top) / rect.height) * height;
      state.leftY = clamp(y - paddleH / 2, 4, height - paddleH - 4);
    });

    canvas.addEventListener("click", (event) => {
      if (!shell.classList.contains("is-open")) {
        openGame();
        return;
      }
      event.stopPropagation();
      resetBall(state.ballVX > 0 ? -1 : 1);
    });

    shell.addEventListener("click", openGame);
    closeBtn?.addEventListener("click", closeGame);
    drawIdle();
  }

  function initMiniGame() {
    const shell = document.getElementById("mini-game");
    const action = document.getElementById("mini-game-action");
    const track = document.getElementById("mini-game-track");
    const zone = document.getElementById("mini-game-zone");
    const runner = document.getElementById("mini-game-runner");
    const scoreNode = document.getElementById("mini-game-points");
    const streakNode = document.getElementById("mini-game-streak");
    const statusNode = document.getElementById("mini-game-status");
    const minimize = document.getElementById("mini-game-minimize");
    if (!shell || !action || !track || !zone || !runner || !scoreNode || !streakNode || !statusNode) return;

    const state = {
      score: 0,
      streak: 0,
      pos: 0.5,
      dir: 1,
      speed: 0.008,
      zoneStart: 0.39,
      zoneWidth: 0.22,
      running: false,
      frame: null,
      startTimer: null
    };

    function renderScore() {
      scoreNode.textContent = String(state.score);
      streakNode.textContent = `x${state.streak}`;
    }

    function randomizeZone() {
      state.zoneWidth = 0.18 + Math.random() * 0.08;
      state.zoneStart = 0.12 + Math.random() * (0.76 - state.zoneWidth);
      zone.style.left = `${state.zoneStart * 100}%`;
      zone.style.width = `${state.zoneWidth * 100}%`;
    }

    function renderRunner() {
      runner.style.left = `${state.pos * 100}%`;
    }

    function setStatus(text, kind = "") {
      statusNode.textContent = text;
      statusNode.classList.toggle("is-good", kind === "good");
      statusNode.classList.toggle("is-bad", kind === "bad");
    }

    function stopLoop() {
      state.running = false;
      if (state.frame !== null) {
        cancelAnimationFrame(state.frame);
        state.frame = null;
      }
    }

    function loop() {
      if (!state.running) return;
      state.pos += state.dir * state.speed;
      if (state.pos >= 1) {
        state.pos = 1;
        state.dir = -1;
      } else if (state.pos <= 0) {
        state.pos = 0;
        state.dir = 1;
      }
      renderRunner();
      state.frame = requestAnimationFrame(loop);
    }

    function openGame() {
      if (shell.classList.contains("is-open")) return;
      shell.classList.remove("is-collapsed");
      shell.classList.add("is-open");
      action.setAttribute("aria-expanded", "true");
      state.score = 0;
      state.streak = 0;
      state.pos = 0.5;
      state.dir = Math.random() > 0.5 ? 1 : -1;
      state.speed = 0.008;
      renderScore();
      randomizeZone();
      renderRunner();
      setStatus("go");
      playSound(miniGameOpenSound, 0.1);
      if (state.startTimer !== null) {
        clearTimeout(state.startTimer);
      }
      state.startTimer = setTimeout(() => {
        state.running = true;
        state.frame = requestAnimationFrame(loop);
        state.startTimer = null;
      }, 180);
    }

    function closeGame(event) {
      event?.stopPropagation();
      shell.classList.remove("is-open");
      shell.classList.add("is-collapsed");
      action.setAttribute("aria-expanded", "false");
      if (state.startTimer !== null) {
        clearTimeout(state.startTimer);
        state.startTimer = null;
      }
      stopLoop();
      state.pos = 0.5;
      state.streak = 0;
      renderScore();
      renderRunner();
      setStatus("tap");
    }

    function playRound(event) {
      event.stopPropagation();
      if (!shell.classList.contains("is-open")) {
        openGame();
        return;
      }

      const hit = state.pos >= state.zoneStart && state.pos <= state.zoneStart + state.zoneWidth;
      runner.classList.remove("is-hit", "is-miss");
      if (hit) {
        state.streak += 1;
        state.score += 1 + Math.min(5, state.streak - 1);
        state.speed = Math.min(0.02, state.speed + 0.0012);
        setStatus("nice", "good");
        runner.classList.add("is-hit");
        playSound(state.streak >= 3 ? miniGameComboSound : miniGameHitSound, state.streak >= 3 ? 0.11 : 0.1);
      } else {
        state.streak = 0;
        state.score = Math.max(0, state.score - 1);
        state.speed = Math.max(0.008, state.speed - 0.002);
        setStatus("miss", "bad");
        runner.classList.add("is-miss");
        playSound(miniGameMissSound, 0.08);
      }
      renderScore();
      randomizeZone();
      setTimeout(() => {
        runner.classList.remove("is-hit", "is-miss");
      }, 140);
    }

    action.addEventListener("click", playRound);
    minimize?.addEventListener("click", closeGame);
    randomizeZone();
    renderRunner();
    renderScore();
  }

  function init() {
    setInitialThemeAndLanguage();
    if (chrome?.storage?.onChanged) {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        const nextTheme = changes.uiTheme?.newValue;
        if (areaName !== 'local' || !nextTheme || nextTheme === currentUITheme) return;
        currentUITheme = nextTheme;
        localStorage.setItem('uiTheme', currentUITheme);
        applyUITheme(currentUITheme);
      });
    }
    initButtons();
    initMiniGame();
  }

  // Запуск инициализации
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(init, 100);
  } else {
    document.addEventListener('DOMContentLoaded', init);
  }

  document.getElementById('process-top')?.addEventListener('click', () => {
    window.open(chrome.runtime.getURL('browser-engine.html'), '_blank');
  });
});

