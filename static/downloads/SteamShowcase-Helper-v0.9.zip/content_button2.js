(() => {
  if (window.__sdsContentButton2Loaded) return;
  window.__sdsContentButton2Loaded = true;

  const TOOL_NAME = 'workshop';

  async function readActiveTool() {
    try {
      if (chrome?.storage?.session?.get) {
        const sessionData = await chrome.storage.session.get('sshActiveTool');
        if (sessionData?.sshActiveTool) return sessionData.sshActiveTool;
      }
      if (chrome?.storage?.local?.get) {
        const localData = await chrome.storage.local.get('sshActiveTool');
        if (localData?.sshActiveTool) return localData.sshActiveTool;
      }
    } catch (error) {
      console.warn('[SSH] active tool lookup failed', error);
    }
    return null;
  }

  function clearActiveTool() {
    try {
      chrome?.storage?.session?.remove?.('sshActiveTool');
      chrome?.storage?.local?.remove?.('sshActiveTool');
    } catch (error) {}
  }

  async function shouldRun() {
    const active = await readActiveTool();
    // Direct navigation fallback: artwork/workshop/guide content scripts may run without popup flag.
    if (!active) return TOOL_NAME !== 'screenshot';
    return active === TOOL_NAME;
  }

const CONFIG = {
  consumerAppIDValue: '480',
  fileTypeValue: '0',
  visibilityValue: '0',
  titleValue: ' ᠌᠌ ᠌᠌ ᠌᠌ ᠌᠌ ᠌᠌ ᠌',
  bannerImageUrl: chrome.runtime.getURL('./company_links/main.gif'),
  bannerLink: 'https://t.me/SteamMakerBot',
};

const SELECTORS = {
  consumerAppID: '#ConsumerAppID',
  fileType: '[name=file_type]',
  visibility: '[name=visibility]',
  titleInput: '#title',
  agreeTermsCheckbox: '#agree_terms',
  titleBlock: '.detailBox.collection .titleField',
  imageBlock: '.imagesizepreview',
};

/**
 * Применяет значения из конфигурации к элементам формы.
 * @returns {boolean} True, если значения успешно применены, иначе false.
 */
function applyValuesButton2() {
  const { consumerAppID, fileType, visibility, titleInput, agreeTermsCheckbox } = SELECTORS;
  const elements = {
    consumerAppID: document.querySelector(consumerAppID),
    fileType: document.querySelector(fileType),
    visibility: document.querySelector(visibility),
    title: document.querySelector(titleInput),
    agreeTerms: document.querySelector(agreeTermsCheckbox),
  };

  if (Object.values(elements).every(el => el !== null)) {
    elements.consumerAppID.value = CONFIG.consumerAppIDValue;
    elements.fileType.value = CONFIG.fileTypeValue;
    elements.visibility.value = CONFIG.visibilityValue;
    elements.title.value = CONFIG.titleValue;
    elements.agreeTerms.checked = true;

    console.log('Значения успешно применены!');
    return true;
  }
  console.log('Элементы не найдены.');
  return false;
}

/**
 * Добавляет рекламный баннер на страницу (если он еще не добавлен).
 */
function addBanner() {
  const { titleBlock, imageBlock } = SELECTORS;
  const titleElement = document.querySelector(titleBlock)?.closest('.detailBox.collection');
  const imageElement = document.querySelector(imageBlock)?.closest('.detailBox.collection');

  if (titleElement && imageElement && !document.querySelector('.ad-banner')) {
    const banner = document.createElement('div');
    banner.className = "detailBox collection";
    const bannerInner = document.createElement('div');
    bannerInner.className = 'ad-banner';
    const link = document.createElement('a');
    link.href = CONFIG.bannerLink;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    const img = document.createElement('img');
    img.src = CONFIG.bannerImageUrl;
    img.alt = 'Рекламный баннер';
    link.appendChild(img);
    bannerInner.appendChild(link);
    banner.appendChild(bannerInner);
    titleElement.insertAdjacentElement('afterend', banner);
  }
}

/**
 * Добавляет стили для рекламного баннера.
 */
function addBannerStyles() {
  if (!document.querySelector('style[data-banner-styles]')) {
    const styleSheet = document.createElement('style');
    styleSheet.type = 'text/css';
    styleSheet.setAttribute('data-banner-styles', 'true');
    styleSheet.textContent = `
      .ad-banner {
        margin: 10px 0 14px;
      }
      .ad-banner img {
        display: block;
        max-width: 100%;
        height: auto;
        cursor: pointer;
        border-radius: 12px;
        box-shadow: 0 10px 24px rgba(0,0,0,.25);
      }
    `;
    document.head.appendChild(styleSheet);
  }
}

/**
 * Инициализирует скрипт.
 */
async function init() {
  if (!(await shouldRun())) return;
  clearActiveTool();

  applyValuesButton2();
  addBanner();
  addBannerStyles();
}

// Запуск инициализации
if (document.readyState === 'complete' || document.readyState === 'interactive') {
  setTimeout(init, 100);
} else {
  document.addEventListener('DOMContentLoaded', init);
}

})();
