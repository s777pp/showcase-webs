(() => {
  let file = null;
  let mode = 'workshop';
  let outputs = [];
  const $ = id => document.getElementById(id);
  const status = (text, cls='') => { $('status').textContent = text; $('status').className = 'status ' + cls; };
  const crcTable = (() => { const t = new Uint32Array(256); for (let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1);t[n]=c>>>0;} return t; })();
  function crc32(data){let c=0xffffffff;for(const b of data)c=crcTable[(c^b)&255]^(c>>>8);return(c^0xffffffff)>>>0;}
  const u16=n=>new Uint8Array([n&255,(n>>>8)&255]);
  const u32=n=>new Uint8Array([n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]);
  function concat(parts){let len=parts.reduce((s,p)=>s+p.length,0),out=new Uint8Array(len),o=0;for(const p of parts){out.set(p,o);o+=p.length;}return out;}
  function zipStore(files){const local=[],central=[];let offset=0;for(const f of files){const name=new TextEncoder().encode(f.name),data=f.data,c=crc32(data);const h=concat([new Uint8Array([80,75,3,4]),u16(20),u16(0),u16(0),u16(0),u16(0),u32(c),u32(data.length),u32(data.length),u16(name.length),u16(0),name]);local.push(h,data);const ch=concat([new Uint8Array([80,75,1,2]),u16(20),u16(20),u16(0),u16(0),u16(0),u16(0),u32(c),u32(data.length),u32(data.length),u16(name.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),name]);central.push(ch);offset+=h.length+data.length;}const cd=central.reduce((s,p)=>s+p.length,0),body=local.concat(central),eoc=concat([new Uint8Array([80,75,5,6]),u16(0),u16(0),u16(files.length),u16(files.length),u32(cd),u32(offset),u16(0)]);return new Blob([...body,eoc],{type:'application/zip'});}

  function imageFromFile(f){return createImageBitmap(f).then(bmp=>{const c=document.createElement('canvas');c.width=bmp.width;c.height=bmp.height;c.getContext('2d').drawImage(bmp,0,0);bmp.close?.();return c;});}
  function canvasBytes(c){return new Promise(r=>c.toBlob(async b=>r(new Uint8Array(await b.arrayBuffer())),'image/png'));}
  function resizeCanvas(src,w){const h=Math.max(1,Math.floor(src.height*(w/src.width)));const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(src,0,0,w,h);return c;}
  function watermark(c){const text=$('wmText').value.trim(),opacity=parseFloat($('wmOpacity').value);if(!text||opacity<=0)return c;const out=document.createElement('canvas');out.width=c.width;out.height=c.height;const x=out.getContext('2d');x.drawImage(c,0,0);const size=Math.max(12,Math.floor(c.height/28));x.font=`${size}px Segoe UI, Arial, sans-serif`;x.fillStyle=$('wmColor').value;x.globalAlpha=opacity;x.textBaseline='top';const m=x.measureText(text),pad=Math.max(10,Math.floor(c.height*.02));const corner=$('wmCorner').value;let px=pad,py=pad;if(corner==='br'){px=c.width-m.width-pad;py=c.height-size-pad}else if(corner==='tr'){px=c.width-m.width-pad}else if(corner==='bl'){py=c.height-size-pad}x.fillText(text,px,py);return out;}

  // Browser-only GIF encoder. It uses a deterministic 3-3-2 palette and GIF LZW compression.
  function quantize332(imageData){
    const src=imageData.data, idx=new Uint8Array(imageData.width*imageData.height);
    for(let i=0,p=0;i<idx.length;i++,p+=4){const a=src[p+3]; if(a<128){idx[i]=0;continue;} idx[i]=((src[p]>>5)<<5)|((src[p+1]>>5)<<2)|(src[p+2]>>6);}
    const pal=new Uint8Array(256*3); let p=0;
    for(let r=0;r<8;r++)for(let g=0;g<8;g++)for(let b=0;b<4;b++){pal[p++]=Math.round(r*255/7);pal[p++]=Math.round(g*255/7);pal[p++]=Math.round(b*255/3);}
    return {idx,pal};
  }
  function lzwEncode(indices,minCodeSize=8){
    const clear=1<<minCodeSize, end=clear+1; let next=clear+2, codeSize=minCodeSize+1, dict=new Map();
    let bits=0,bitCount=0,bytes=[];
    const emit=code=>{bits|=code<<bitCount;bitCount+=codeSize;while(bitCount>=8){bytes.push(bits&255);bits>>>=8;bitCount-=8;}};
    emit(clear); let prefix=null;
    for(const k of indices){
      if(prefix===null){prefix=k;continue;}
      const key=(prefix<<8)|k;
      if(dict.has(key)){prefix=dict.get(key);continue;}
      emit(prefix);
      // The decoder creates a dictionary entry one emitted code later than the
      // encoder. Grow the code width only after the next code crosses the
      // current width limit; growing at equality shifts the bitstream.
      if(next<4096){dict.set(key,next++);if(next>(1<<codeSize)&&codeSize<12)codeSize++;}
      else{emit(clear);dict=new Map();next=clear+2;codeSize=minCodeSize+1;}
      prefix=k;
    }
    if(prefix!==null)emit(prefix);emit(end);if(bitCount>0)bytes.push(bits&255);
    const blocks=[];for(let i=0;i<bytes.length;i+=255){const chunk=bytes.slice(i,i+255);blocks.push(new Uint8Array([chunk.length]),new Uint8Array(chunk));}blocks.push(new Uint8Array([0]));
    return concat(blocks);
  }
  function gifFrameBlock(imageData,delayCs,palette){
    const {idx}=quantize332(imageData);
    const gce=new Uint8Array([0x21,0xf9,0x04,0x00,delayCs&255,(delayCs>>8)&255,0x00,0x00]);
    const desc=new Uint8Array([0x2c,0,0,0,0,imageData.width&255,(imageData.width>>8)&255,imageData.height&255,(imageData.height>>8)&255,0x00]);
    return concat([gce,desc,new Uint8Array([8]),lzwEncode(idx,8)]);
  }
  function encodeGif(frames,width,height,loop=0){
    if(!frames.length)throw new Error('GIF содержит 0 кадров.');
    const header=new TextEncoder().encode('GIF89a');
    const lsd=new Uint8Array([width&255,(width>>8)&255,height&255,(height>>8)&255,0xf7,0x00,0x00]);
    const palette=new Uint8Array(256*3);for(let r=0,p=0;r<8;r++)for(let g=0;g<8;g++)for(let b=0;b<4;b++){palette[p++]=Math.round(r*255/7);palette[p++]=Math.round(g*255/7);palette[p++]=Math.round(b*255/3);}
    const loopExt=new Uint8Array([0x21,0xff,0x0b,78,69,84,83,67,65,80,69,50,46,48,3,1,loop&255,(loop>>8)&255,0]);
    const blocks=[];for(const frame of frames){const delay=Math.max(1,Math.min(65535,Math.round((frame.durationMs||100)/10)));blocks.push(gifFrameBlock(frame.imageData,delay,palette));}
    return concat([header,lsd,palette,loopExt,...blocks,new Uint8Array([0x3b])]);
  }

  async function decodeGifFrames(blob){
    if(typeof ImageDecoder==='undefined')throw new Error('Ваш браузер не поддерживает GIF Browser Engine. Используйте актуальный Chrome или Edge.');
    // Always pass an owned Uint8Array. Some WebCodecs implementations reject
    // ArrayBuffers originating from File.arrayBuffer() across extension realms.
    let source;
    if(blob instanceof ArrayBuffer) source=new Uint8Array(blob);
    else if(ArrayBuffer.isView(blob)) source=new Uint8Array(blob.buffer,blob.byteOffset,blob.byteLength);
    else if(blob?.arrayBuffer) source=new Uint8Array(await blob.arrayBuffer());
    if(!source?.byteLength){
      throw new Error('Не удалось прочитать GIF как ArrayBuffer.');
    }
    const data=new Uint8Array(source);
    const decoder=new ImageDecoder({data, type: blob?.type || 'image/gif'});
    await decoder.tracks.ready;
    const track=decoder.tracks.selectedTrack;
    if(!track || !track.frameCount){
      decoder.close?.();
      throw new Error('GIF не содержит кадров или повреждён.');
    }
    const count=track.frameCount;
    const frames=[];
    for(let i=0;i<count;i++){
      status(`Декодирование GIF · кадр ${i+1} / ${count}…`);
      const decoded=await decoder.decode({frameIndex:i,completeFramesOnly:true});
      const image=decoded.image;
      const w=image.displayWidth||image.codedWidth;const h=image.displayHeight||image.codedHeight;
      const c=document.createElement('canvas');c.width=w;c.height=h;
      const ctx=c.getContext('2d',{willReadFrequently:true});
      ctx.drawImage(image,0,0,w,h);
      const durationMs=Math.max(10,(image.duration||100000)/1000);
      frames.push({canvas:c,durationMs});
      image.close?.();
    }
    decoder.close?.();
    return frames;
  }
  function transformedFrames(frames,transform){return frames.map(f=>{const c=transform(f.canvas);const ctx=c.getContext('2d');return {imageData:ctx.getImageData(0,0,c.width,c.height),durationMs:f.durationMs};});}

  async function processStatic(src){
    const result=[];
    if(mode==='workshop'){
      const pw=Math.max(1,Math.floor(src.width/5)),parts=[];
      for(let i=0;i<5;i++){const c=document.createElement('canvas');c.width=i===4?src.width-i*pw:pw;c.height=src.height;c.getContext('2d').drawImage(src,i*pw,0,c.width,c.height,0,0,c.width,c.height);parts.push(c);result.push({name:`part_${i+1}.png`,data:await canvasBytes(c)});}
      const full=document.createElement('canvas');full.width=src.width+24;full.height=src.height;const g=full.getContext('2d');g.fillStyle='#000';g.fillRect(0,0,full.width,full.height);let x=0;for(let i=0;i<parts.length;i++){g.drawImage(parts[i],x,0);x+=parts[i].width+(i<4?6:0);}result.push({name:'full_original.png',data:await canvasBytes(src)});result.push({name:'full_with_bars.png',data:await canvasBytes(watermark(full))});
    }else if(mode==='featured'){const c=resizeCanvas(src,630);result.push({name:'featured_630.png',data:await canvasBytes(c)});result.push({name:'full_original.png',data:await canvasBytes(c)});if($('wmText').value.trim())result.push({name:'full_with_watermark.png',data:await canvasBytes(watermark(c))});
    }else{const c=resizeCanvas(src,606),center=document.createElement('canvas'),side=document.createElement('canvas');center.width=506;center.height=c.height;side.width=100;side.height=c.height;center.getContext('2d').drawImage(c,0,0,506,c.height,0,0,506,c.height);side.getContext('2d').drawImage(c,506,0,100,c.height,0,0,100,c.height);result.push({name:'center_506.png',data:await canvasBytes(center)},{name:'side_100.png',data:await canvasBytes(side)},{name:'full_original.png',data:await canvasBytes(c)});const full=document.createElement('canvas');full.width=612;full.height=c.height;const g=full.getContext('2d');g.fillStyle='#000';g.fillRect(0,0,612,c.height);g.drawImage(center,0,0);g.drawImage(side,512,0);result.push({name:'full_with_bars.png',data:await canvasBytes(watermark(full))});}
    return result;
  }

  async function processGif(){
    const frames=await decodeGifFrames(file);if(frames.length>300)throw new Error('GIF слишком большой для Browser Engine (максимум 300 кадров).');
    const makePart=(index)=>transformedFrames(frames,f=>{const w=Math.max(1,Math.floor(f.width/5)),c=document.createElement('canvas');c.width=index===4?f.width-index*w:w;c.height=f.height;c.getContext('2d').drawImage(f,index*w,0,c.width,c.height,0,0,c.width,c.height);return c;});
    const result=[];
    if(mode==='workshop'){
      const parts=Array.from({length:5},(_,i)=>makePart(i));
      for(let i=0;i<5;i++){const bytes=encodeGif(parts[i],parts[i][0].imageData.width,parts[i][0].imageData.height);result.push({name:`part_${i+1}.gif`,data:bytes});}
      const fullFrames=frames.map(f=>{const src=f.canvas;const c=document.createElement('canvas');c.width=src.width+24;c.height=src.height;const g=c.getContext('2d');g.fillStyle='#000';g.fillRect(0,0,c.width,c.height);let x=0;for(let i=0;i<5;i++){const w=i===4?src.width-x:Math.floor(src.width/5);g.drawImage(src,x,0,w,src.height,x+(i*6),0,w,src.height);x+=w;}const wm=watermark(c);return {imageData:wm.getContext('2d').getImageData(0,0,wm.width,wm.height),durationMs:f.durationMs};});result.push({name:'full_original.gif',data:encodeGif(transformedFrames(frames,f=>f),frames[0].canvas.width,frames[0].canvas.height)});result.push({name:'full_with_bars.gif',data:encodeGif(fullFrames,fullFrames[0].imageData.width,fullFrames[0].imageData.height)});
    }else if(mode==='featured'){
      const out=transformedFrames(frames,f=>watermark(resizeCanvas(f,630)));result.push({name:'featured_630.gif',data:encodeGif(out,out[0].imageData.width,out[0].imageData.height)});if($('wmText').value.trim())result.push({name:'full_with_watermark.gif',data:encodeGif(out,out[0].imageData.width,out[0].imageData.height)});
    }else{
      const center=transformedFrames(frames,f=>{const c=resizeCanvas(f,606),o=document.createElement('canvas');o.width=506;o.height=c.height;o.getContext('2d').drawImage(c,0,0,506,c.height,0,0,506,c.height);return o;});
      const side=transformedFrames(frames,f=>{const c=resizeCanvas(f,606),o=document.createElement('canvas');o.width=100;o.height=c.height;o.getContext('2d').drawImage(c,506,0,100,c.height,0,0,100,c.height);return o;});
      result.push({name:'center_506.gif',data:encodeGif(center,506,center[0].imageData.height)},{name:'side_100.gif',data:encodeGif(side,100,side[0].imageData.height)});
      const full=frames.map(f=>{const c=resizeCanvas(f,606),o=document.createElement('canvas');o.width=612;o.height=c.height;const g=o.getContext('2d');g.fillStyle='#000';g.fillRect(0,0,612,c.height);g.drawImage(c,0,0);const wm=watermark(o);return {imageData:wm.getContext('2d').getImageData(0,0,612,c.height),durationMs:f.durationMs};});result.push({name:'full_with_bars.gif',data:encodeGif(full,612,full[0].imageData.height)});
    }
    return result;
  }

  async function process(){
    if(!file){status('Сначала выберите изображение или GIF.','err');return;}
    $('process').disabled=true;$('download').disabled=true;status('Подготовка…');
    try{outputs=file.type==='image/gif'||/\.gif$/i.test(file.name)?await processGif():await processStatic(await imageFromFile(file));$('download').disabled=false;status(`Готово · ${outputs.length} файлов · обработано в браузере на вашем ПК.`,'ok');}
    catch(e){console.error(e);status(`Ошибка: ${e.message||e}`,'err');}
    finally{$('process').disabled=false;}
  }
  function download(){if(!outputs.length)return;const blob=zipStore(outputs);const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='SteamShowcase-Browser-Engine.zip';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1500);}
  function setFile(f){file=f||null;$('file-name').textContent=file?`${file.name} · ${(file.size/1024/1024).toFixed(2)} MB`:'Файл не выбран';}
  $('drop').addEventListener('click',()=>$('file').click());$('file').addEventListener('change',e=>setFile(e.target.files[0]));
  ['dragenter','dragover'].forEach(ev=>$('drop').addEventListener(ev,e=>{e.preventDefault();$('drop').classList.add('drag');}));['dragleave','drop'].forEach(ev=>$('drop').addEventListener(ev,e=>{e.preventDefault();$('drop').classList.remove('drag');}));$('drop').addEventListener('drop',e=>setFile(e.dataTransfer.files[0]));
  document.querySelectorAll('.tool').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.tool').forEach(x=>x.classList.remove('active'));b.classList.add('active');mode=b.dataset.engine;}));
  $('wmOpacity').addEventListener('input',e=>$('wmValue').textContent=Math.round(e.target.value*100)+'%');$('process').addEventListener('click',process);$('download').addEventListener('click',download);
})();
