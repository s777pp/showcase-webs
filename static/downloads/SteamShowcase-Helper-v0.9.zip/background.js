/**
 * Lightweight MV3 service worker for SteamShowcase Helper.
 */

function isAllowedSteamEditUrl(url) {
  try {
    const parsed = new URL(url || '');
    return parsed.protocol === 'https:'
      && parsed.hostname === 'steamcommunity.com'
      && (
        parsed.pathname.startsWith('/sharedfiles/edititem/')
        || parsed.pathname.startsWith('/workshop/edititem/')
        || parsed.pathname.startsWith('/sharedfiles/editguide/')
      );
  } catch (error) {
    return false;
  }
}

function handleInstallOrUpdate(details) {
  console.info('[SSH] Extension lifecycle:', details.reason, chrome.runtime.getManifest().version);
}

function handleMessage(message, sender, sendResponse) {
  if (!message || !message.action) return false;
  if (sender?.id && sender.id !== chrome.runtime.id) return false;

  if (message.action === 'getTabInfo') {
    if (!sender.tab?.id) {
      sendResponse({ error: 'no-tab' });
      return false;
    }
    chrome.tabs.get(sender.tab.id, (tab) => {
      sendResponse({ url: tab?.url || '', title: tab?.title || '' });
    });
    return true;
  }

  if (message.action === 'applyValues') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs?.[0];
      if (!tab?.id || !isAllowedSteamEditUrl(tab.url)) {
        sendResponse?.({ ok: false });
        return;
      }
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content_button1.js'],
      }).then(() => sendResponse?.({ ok: true }))
        .catch((error) => {
          console.error('[SSH] applyValues failed', error);
          sendResponse?.({ ok: false, error: String(error) });
        });
    });
    return true;
  }

  return false;
}

chrome.runtime.onInstalled.addListener(handleInstallOrUpdate);
chrome.runtime.onMessage.addListener(handleMessage);
