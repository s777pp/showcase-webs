const css_part = `<style>

/* === Сайдбар: 3 состояния ===
   1) Закрыт: display:none
   2) Свёрнут (is-collapsed): узкая колонка с превью надетых предметов
   3) Раскрыт (is-open): полный интерфейс выбора */
.sidebar {
    --sds-sidebar-open-width: min(920px, calc(100vw - 12px));
    --sds-sidebar-collapsed-width: 160px;
    --sds-ease-out: cubic-bezier(0.16, 1, 0.3, 1);
    --sds-ease-soft: cubic-bezier(0.2, 0.8, 0.2, 1);
    display: flex;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', 'Roboto', system-ui, -apple-system, sans-serif;
    position: fixed;
    right: 0;
    top: 0;
    height: 100%;
    max-height: 100%;
    width: var(--sds-sidebar-open-width);
    background: rgba(8, 20, 34, 0.88);
    backdrop-filter: blur(20px) saturate(160%);
    -webkit-backdrop-filter: blur(20px) saturate(160%);
    border-left: 1px solid rgba(102, 192, 244, 0.22);
    transition: transform 0.56s var(--sds-ease-out),
                opacity 0.28s ease;
    max-width: 100%;
    z-index: 1000;
    box-shadow: -16px 0 48px rgba(0, 0, 0, 0.45), -1px 0 0 rgba(102, 192, 244, 0.08);
    overflow: hidden;
    visibility: hidden;
    pointer-events: none;
    opacity: 0;
    transform: translateX(100%);
    will-change: transform, opacity;
}

.sidebar,
.sidebar * {
    box-sizing: border-box;
}

.sidebar.is-collapsed {
    visibility: visible;
    pointer-events: auto;
    opacity: 1;
    transform: translateX(calc(100% - var(--sds-sidebar-collapsed-width)));
    width: var(--sds-sidebar-open-width);
    flex-direction: column;
}

.sidebar.is-open {
    visibility: visible;
    pointer-events: auto;
    opacity: 1;
    transform: translateX(0);
    width: var(--sds-sidebar-open-width);
    flex-direction: column;
}

.sidebar.is-open.is-closing {
    visibility: visible;
    pointer-events: none;
    opacity: 0;
    transform: translateX(100%);
    width: var(--sds-sidebar-open-width);
    flex-direction: column;
}

.sidebar.is-collapsed.is-closing {
    visibility: visible;
    pointer-events: none;
    opacity: 0;
    transform: translateX(100%);
    width: var(--sds-sidebar-open-width);
    flex-direction: column;
}

/* === Свёрнутый режим: вертикальный список превью === */
.collapsed-view {
    display: none;
    flex: 1;
    width: var(--sds-sidebar-collapsed-width);
    max-width: var(--sds-sidebar-collapsed-width);
    height: 100%;
    align-self: flex-start;
    flex-direction: column;
    overflow-y: auto;
    overflow-x: hidden;
    overscroll-behavior: contain;
    padding: 12px 10px 8px 10px;
    gap: 8px;
}

.sidebar.is-collapsed .collapsed-view {
    display: flex;
    animation: sdsCollapsedIn 0.42s var(--sds-ease-out) both;
}

.sidebar.is-collapsed .collapsed-reset-wrap {
    animation: sdsCollapsedIn 0.42s var(--sds-ease-out) both;
}

@keyframes sdsCollapsedIn {
    from { opacity: 0; transform: translateX(18px) scale(0.985); }
    to { opacity: 1; transform: translateX(0); }
}

.collapsed-view::-webkit-scrollbar { width: 4px; }
.collapsed-view::-webkit-scrollbar-track { background: transparent; }
.collapsed-view::-webkit-scrollbar-thumb {
    background: rgba(102, 192, 244, 0.3);
    border-radius: 2px;
}

.collapsed-slot {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    cursor: pointer;
    text-align: center;
    transition: transform 0.25s ease;
    flex-shrink: 0;
}

.collapsed-slot:hover {
    transform: translateY(-2px);
}

.collapsed-slot-label {
    font-size: 9px;
    font-weight: 700;
    letter-spacing: 0.5px;
    text-transform: uppercase;
    color: rgba(255, 255, 255, 0.55);
    text-align: left;
    padding: 0 2px 4px 2px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.collapsed-slot-preview {
    width: 100%;
    aspect-ratio: 1 / 1;
    border-radius: 8px;
    overflow: hidden;
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(102, 192, 244, 0.18);
    transition: all 0.25s cubic-bezier(0.25, 0.8, 0.25, 1);
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
}

.collapsed-slot:hover .collapsed-slot-preview {
    border-color: rgba(102, 192, 244, 0.55);
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(102, 192, 244, 0.25);
}

.collapsed-slot-preview img,
.collapsed-slot-preview video {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}

/* Аспект для тех слотов где картинка широкая */
.collapsed-slot.wide .collapsed-slot-preview {
    aspect-ratio: 16 / 9;
}

.collapsed-slot.empty .collapsed-slot-preview {
    background: repeating-linear-gradient(
        45deg,
        rgba(102, 192, 244, 0.04),
        rgba(102, 192, 244, 0.04) 6px,
        rgba(102, 192, 244, 0.10) 6px,
        rgba(102, 192, 244, 0.10) 12px
    );
}

.collapsed-slot.empty .collapsed-slot-preview::after {
    content: '+';
    color: rgba(255, 255, 255, 0.3);
    font-size: 26px;
    font-weight: 200;
    line-height: 1;
}

.collapsed-slot-name {
    font-size: 10px;
    color: rgba(255, 255, 255, 0.85);
    line-height: 1.25;
    padding: 4px 2px 0 2px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    text-align: left;
    font-weight: 500;
}

/* Кнопка сброса снизу (одинаковая в обоих режимах) */
.collapsed-reset-wrap {
    display: none;
    width: var(--sds-sidebar-collapsed-width);
    align-self: flex-start;
    padding: 8px 10px 12px 10px;
    border-top: 1px solid rgba(102, 192, 244, 0.12);
    background: rgba(20, 40, 58, 0.5);
}

.sidebar.is-collapsed .collapsed-reset-wrap {
    display: block;
}

/* === Раскрытый режим: основной контент === */
.expanded-view {
    display: none;
    flex-direction: row;
    width: 100%;
    height: 100%;
    overflow: hidden;
}

.sidebar.is-open .expanded-view {
    display: flex;
    animation: sdsPanelIn 0.46s var(--sds-ease-out) both;
}

@keyframes sdsPanelIn {
    from { opacity: 0; transform: translateX(34px) scale(0.982); }
    to { opacity: 1; transform: translateX(0); }
}

.sidebar-main {
    display: flex;
    flex-direction: column;
    flex: 1;
    min-width: 0;
    height: 100%;
}

/* Правая колонка надетых предметов (только в is-open) */
.equipped-column {
    width: 200px;
    flex-shrink: 0;
    background: rgba(20, 40, 58, 0.55);
    border-left: 1px solid rgba(102, 192, 244, 0.15);
    overflow: hidden;
    display: flex;
    flex-direction: column;
}

.equipped-title {
    padding: 14px 12px 10px 12px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1.2px;
    text-transform: uppercase;
    color: transparent;
    text-align: center;
    background: linear-gradient(90deg, #66c0f4, #ffffff, #66c0f4);
    background-size: 200% auto;
    -webkit-background-clip: text;
    background-clip: text;
    animation: shine 4s linear infinite;
    border-bottom: 1px solid rgba(102, 192, 244, 0.12);
}

.equipped-list {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    overscroll-behavior: contain;
    padding: 10px 8px;
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.equipped-list::-webkit-scrollbar { width: 4px; }
.equipped-list::-webkit-scrollbar-track { background: transparent; }
.equipped-list::-webkit-scrollbar-thumb {
    background: rgba(102, 192, 244, 0.3);
    border-radius: 2px;
}

.equipped-slot {
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding: 8px;
    background: rgba(12, 28, 44, 0.75);
    border: 1px solid rgba(102, 192, 244, 0.18);
    border-radius: 10px;
    transition: transform 0.2s var(--sds-ease-soft), background 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}

.equipped-slot:hover {
    background: rgba(12, 28, 44, 0.82);
    border-color: rgba(102, 192, 244, 0.45);
    transform: translateY(-2px);
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.35);
}

.equipped-slot-label {
    font-size: 9px;
    font-weight: 600;
    color: rgba(102, 192, 244, 0.85);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-align: center;
}

.equipped-slot-preview {
    width: 100%;
    aspect-ratio: 1/1;
    border-radius: 6px;
    overflow: hidden;
    background: rgba(0, 0, 0, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
}

.equipped-slot-preview img,
.equipped-slot-preview video {
    width: 100%;
    height: 100%;
    object-fit: contain;
    object-position: center;
    display: block;
}

.equipped-slot-preview .profile_avatar_frame,
.collapsed-slot-preview .profile_avatar_frame {
    position: absolute !important;
    inset: 0 !important;
    width: 100% !important;
    height: 100% !important;
    pointer-events: none;
    display: block;
}

.equipped-slot-preview .profile_avatar_frame img,
.collapsed-slot-preview .profile_avatar_frame img {
    width: 100% !important;
    height: 100% !important;
    object-fit: contain;
    object-position: center;
    display: block;
}

.equipped-slot.wide .equipped-slot-preview {
    aspect-ratio: 16/9;
}

.equipped-slot.wide .equipped-slot-preview img,
.equipped-slot.wide .equipped-slot-preview video {
    object-fit: contain;
}

.equipped-slot.empty .equipped-slot-preview {
    aspect-ratio: 1/1;
    background: repeating-linear-gradient(
        45deg,
        rgba(102, 192, 244, 0.04),
        rgba(102, 192, 244, 0.04) 6px,
        rgba(102, 192, 244, 0.10) 6px,
        rgba(102, 192, 244, 0.10) 12px
    );
    color: rgba(255, 255, 255, 0.4);
    font-size: 18px;
}

.equipped-slot.wide.empty .equipped-slot-preview {
    aspect-ratio: 16/9;
}

.equipped-slot.empty .equipped-slot-preview::after {
    content: '—';
    color: rgba(255, 255, 255, 0.3);
    font-size: 22px;
    font-weight: 300;
}

.equipped-slot-name {
    font-size: 10px;
    color: rgba(255, 255, 255, 0.85);
    line-height: 1.25;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    text-align: center;
    font-weight: 500;
}

/* Кнопка сброса в нижней части правой колонки */
.equipped-reset-wrap {
    padding: 8px;
    border-top: 1px solid rgba(102, 192, 244, 0.15);
    background: rgba(20, 40, 58, 0.6);
}

.reset-btn {
    width: 100%;
    padding: 10px;
    background: linear-gradient(135deg, rgba(244, 102, 102, 0.18), rgba(226, 74, 74, 0.18));
    color: rgba(255, 255, 255, 0.95);
    border: 1px solid rgba(244, 102, 102, 0.35);
    border-radius: 10px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-size: 12px;
    font-weight: 600;
    letter-spacing: 0.4px;
    text-transform: uppercase;
    transition: all 0.42s cubic-bezier(0.22, 1, 0.36, 1);
    backdrop-filter: blur(8px);
    position: relative;
    overflow: hidden;
}

.reset-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at center, rgba(244, 102, 102, 0.3) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.reset-btn:hover {
    background: linear-gradient(135deg, rgba(244, 102, 102, 0.4), rgba(226, 74, 74, 0.4));
    border-color: rgba(244, 102, 102, 0.6);
    transform: translateY(-2px);
    box-shadow: 0 6px 18px rgba(244, 102, 102, 0.25);
    color: white;
}

.reset-btn:hover::before { opacity: 1; }

.reset-btn:active {
    transform: translateY(0);
    box-shadow: 0 2px 8px rgba(244, 102, 102, 0.2);
}

.reset-btn .reset-icon-text {
    font-size: 16px;
    line-height: 1;
    transition: transform 0.4s ease;
    display: inline-block;
}

.reset-btn:hover .reset-icon-text {
    transform: rotate(-180deg);
}

/* Ссылка на Telegram в верхней панели */
.tg-link-btn {
    background: rgba(10, 24, 38, 0.72);
    color: rgba(255, 255, 255, 0.85);
    border: 1px solid rgba(102, 192, 244, 0.2);
    cursor: pointer;
    border-radius: 10px;
    width: 86px;
    height: 36px;
    flex-shrink: 0;
    font-size: 12px;
    font-weight: 700;
    line-height: 1;
    letter-spacing: 0.2px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.38s cubic-bezier(0.22, 1, 0.36, 1);
    backdrop-filter: blur(12px) saturate(180%);
    padding: 0;
    text-decoration: none;
}

.tg-link-btn:hover {
    background: linear-gradient(135deg, rgba(102, 192, 244, 0.34), rgba(74, 144, 226, 0.28));
    border-color: rgba(102, 192, 244, 0.58);
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.28);
}

.sds-lang-switch {
    background: linear-gradient(180deg, rgba(58, 102, 132, 0.72), rgba(32, 60, 83, 0.66));
    color: rgba(255, 255, 255, 0.94);
    border: 1px solid rgba(102, 192, 244, 0.24);
    cursor: pointer;
    border-radius: 18px;
    width: 70px;
    height: 36px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    font-size: 12px;
    font-weight: 800;
    line-height: 1;
    transition: transform 0.2s var(--sds-ease-soft), background 0.2s ease, border-color 0.2s ease;
    backdrop-filter: blur(12px) saturate(180%);
}

.sds-theme-switch { display: none !important; }
.sds-theme-switch-hidden-legacy {
    background: linear-gradient(180deg, rgba(58, 102, 132, 0.72), rgba(32, 60, 83, 0.66));
    color: rgba(255, 255, 255, 0.94);
    border: 1px solid rgba(102, 192, 244, 0.24);
    cursor: pointer;
    border-radius: 18px;
    width: 86px;
    height: 36px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    font-size: 10px;
    font-weight: 800;
    line-height: 1;
    text-transform: uppercase;
    letter-spacing: 0.35px;
    transition: transform 0.2s var(--sds-ease-soft), background 0.2s ease, border-color 0.2s ease;
    backdrop-filter: blur(12px) saturate(180%);
}

.sds-theme-switch:hover {
    transform: translateY(-1px);
    border-color: rgba(102, 192, 244, 0.58);
}

.sds-theme-dot {
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background: linear-gradient(135deg, #66c0f4, #4a90e2 58%, #58ffc2);
    box-shadow: inset 0 0 8px rgba(255, 255, 255, 0.2), 0 0 12px rgba(102, 192, 244, 0.35);
    flex: 0 0 auto;
}

.sds-lang-switch:hover {
    transform: translateY(-1px);
    border-color: rgba(102, 192, 244, 0.58);
    background: linear-gradient(180deg, rgba(86, 145, 184, 0.82), rgba(43, 76, 103, 0.78));
}

.sds-lang-icon {
    font-size: 15px;
    line-height: 1;
}

/* Стили вкладок */
.tabs {
    display: flex;
    flex-direction: row;
    padding: 8px 12px 6px 12px;
    flex-shrink: 0;
    width: 100%;
    z-index: 1001;
    gap: 6px;
    box-sizing: border-box;
    overflow-x: auto;
    overflow-y: hidden;
    scrollbar-width: thin;
    animation: sdsMenuBandIn 0.38s var(--sds-ease-out) both;
}

@keyframes sdsMenuBandIn {
    from { opacity: 0; transform: translateY(-8px); }
    to { opacity: 1; transform: translateY(0); }
}

.tab {
    background: rgba(10, 24, 38, 0.72);
    color: rgba(255, 255, 255, 0.9);
    border: 1px solid rgba(102, 192, 244, 0.2);
    padding: 8px 10px;
    margin: 0;
    cursor: pointer;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-size: 12px;
    font-weight: 500;
    transition: all 0.42s cubic-bezier(0.22, 1, 0.36, 1);
    white-space: nowrap;
    overflow: hidden;
    backdrop-filter: blur(12px) saturate(180%);
    position: relative;
    flex: 0 1 auto;
    min-width: 78px;
}

.tab[data-tab="tab1"] { min-width: 104px; }
.tab[data-tab="tab2"] { min-width: 112px; }
.tab[data-tab="tab3"] { min-width: 128px; }
.tab[data-tab="tab4"] { min-width: 122px; }
.tab[data-tab="tab5"] { min-width: 82px; }

.tab:hover {
    background: linear-gradient(135deg, rgba(102, 192, 244, 0.3), rgba(74, 144, 226, 0.3));
    border-color: rgba(102, 192, 244, 0.4);
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
}

.tab.active {
    background: linear-gradient(135deg, #66c0f4, #3a9fd8);
    border-color: rgba(102, 192, 244, 0.7);
    color: #062033;
    box-shadow: 0 6px 18px rgba(102, 192, 244, 0.28);
}

.sds-profile-cost {
    margin-left: auto;
    min-width: 118px;
    height: 36px;
    padding: 0 12px;
    border: 1px solid rgba(102, 192, 244, 0.24);
    border-radius: 999px;
    background: linear-gradient(180deg, rgba(31, 58, 78, 0.62), rgba(20, 40, 58, 0.7));
    color: rgba(255, 255, 255, 0.92);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 0.2px;
    white-space: nowrap;
    flex: 0 0 auto;
    box-shadow: inset 0 0 18px rgba(102, 192, 244, 0.06);
}

.sds-cost-icon {
    color: #8fd3ff;
    font-size: 14px;
    line-height: 1;
    text-shadow: 0 0 12px rgba(102, 192, 244, 0.75);
}

.tab.active::after {
    display: none;
}

.tab-content {
    overflow-x: hidden;
    overflow-y: auto;
    overscroll-behavior: contain;
    display: none;
    padding: 0 12px 12px 12px;
    color: rgba(255, 255, 255, 0.97);
    flex: 1;
    min-height: 0;
    width: 100%;
    box-sizing: border-box;
    border-radius: 0;
}

.sidebar.is-open .tab-content.active{
    display: block;
    animation: sdsContentIn 0.36s var(--sds-ease-out) both;
}

@keyframes sdsContentIn {
    from { opacity: 0; transform: translateY(10px) scale(0.995); }
    to { opacity: 1; transform: translateY(0); }
}

/* Грид-сетка для контента */
.content-grid {
    display: flex;
    margin-bottom: 60px;
    flex-direction: column;
    position: relative;
    min-height: 200px;
    will-change: transform;
    gap: 10px;
    padding-top: 12px;
}

.content-grid-row {
    display: grid;
    position: relative;
    grid-template-columns: repeat(3, minmax(0, 29%));
    justify-content: center;
    gap: 14px;
    height: auto;
}

.content-item {
    background: rgba(12, 28, 44, 0.7);
    border: 1px solid rgba(102, 192, 244, 0.2);
    border-radius: 10px;
    padding: 8px;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    min-height: 100px;
    justify-content: center;
    transition: transform 0.18s var(--sds-ease-soft), background 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
    backdrop-filter: blur(12px) saturate(180%);
    position: relative;
    overflow: hidden;
    width: 100%;
    min-width: 0;
}

.content-item::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at center, rgba(102, 192, 244, 0.1) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.3s ease;
    border-radius: inherit;
}

.content-item:hover {
    background: rgba(10, 24, 38, 0.72);
    border-color: rgba(102, 192, 244, 0.4);
    transform: translateY(-3px) scale(1.02);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.4);
}

.content-item:hover::before {
    opacity: 1;
}

.content-item img,
.content-item video,
.content-item svg  {
    width: 120px;
    height: 120px;
    object-fit: cover;
    border-radius: 8px;
    margin-bottom: 8px;
    transition: transform 0.2s var(--sds-ease-soft), opacity 0.18s ease;
    position: relative;
    z-index: 1;
}
#tab3 .content-item img,
#tab3 .content-item video {
    width: 100%;
    max-width: 178px;
    height: 100px;
    aspect-ratio:16/9;
    object-fit: contain;
    background: rgba(0, 0, 0, 0.25);
}
#tab4 .content-item img,
#tab4 .content-item video {
    width: 100%;
    max-width: 178px;
    height: 100px;
    aspect-ratio:16/9;
    object-fit: contain;
    background: rgba(0, 0, 0, 0.25);
}

#tab2 .content-item img,
#tab2 .content-item video,
#tab5 .content-item img,
#tab5 .content-item video {
    object-fit: contain;
    background: rgba(0, 0, 0, 0.18);
}

.custom-avatar-tile {
    border-style: dashed;
    border-color: rgba(102, 192, 244, 0.42);
    background: linear-gradient(135deg, rgba(102, 192, 244, 0.16), rgba(74, 144, 226, 0.08));
}

.custom-avatar-tile:hover {
    border-color: rgba(143, 211, 255, 0.8);
    box-shadow: 0 0 0 1px rgba(102, 192, 244, 0.24), 0 12px 28px rgba(0, 0, 0, 0.38);
}

.custom-avatar-icon,
.custom-avatar-slot-icon {
    width: 72px;
    height: 72px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 8px;
    color: #d9f1ff;
    font-size: 34px;
    font-weight: 300;
    background: rgba(102, 192, 244, 0.14);
    border: 1px solid rgba(102, 192, 244, 0.35);
    box-shadow: inset 0 0 18px rgba(102, 192, 244, 0.12);
}

.custom-avatar-slot-icon {
    width: 100%;
    height: 100%;
    margin: 0;
    border-radius: 6px;
}

.content-item:hover img,
.content-item:hover video {
    transform: scale(1.05);
}

.content-item:hover .animPart {
    display: block;
}

.content-item .animPart {
    display: none;
}

.content-item:hover .animPrev {
    display: none;
}

.content-item .animPrev {
    display: block;
}

.item-text {
    color: rgba(255, 255, 255, 0.9);
    font-size: 11px;
    line-height: 1.3;
    opacity: 0;
    transition: all 0.42s cubic-bezier(0.22, 1, 0.36, 1);
    word-break: break-word;
    white-space: normal;
    position: relative;
    z-index: 1;
    font-weight: 500;
}
.tabs button span {
    visibility: hidden;
}
/* Показываем текст при наведении на сайдбар */
.sidebar.is-open .item-text,
.sidebar.is-open .tab span,
.sidebar.is-open .tabs button span{
    opacity: 1;
    visibility: visible;
}

/* Заголовок сайдбара */
.sidebar-header {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 8px 16px 10px 16px;
    flex-shrink: 0;
    height: 72px;
    color: rgba(255, 255, 255, 0.97);
    font-size: 18px;
    font-weight: 800;
    border-top: 1px solid rgba(102, 192, 244, 0.2);
    white-space: nowrap;
    overflow: hidden;
    opacity: 0;
    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
    background: linear-gradient(90deg, #66c0f4, #ffffff, #66c0f4);
    background-size: 200% auto;
    color: transparent;
    -webkit-background-clip: text;
    background-clip: text;
    animation: shine 4s linear infinite;
}

.sidebar-header a {
    display: block;
    height: 54px;
    width: 100%;
    max-width: none;
    overflow: hidden;
    border-radius: 8px;
    border: 1px solid rgba(102, 192, 244, 0.24);
    background: rgba(7, 17, 28, 0.55);
    box-shadow: inset 0 0 18px rgba(102, 192, 244, 0.06), 0 8px 22px rgba(0, 0, 0, 0.22);
}

.sidebar-header img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center 42%;
    display: block;
}

.sidebar.is-open .sidebar-header{
    opacity: 1;
}

@keyframes shine {
    to { background-position: 200% center; }
}

/* Иконки для вкладок */
.tab-icon {
    width: 24px;
    height: 24px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    color: rgba(102, 192, 244, 0.8);
    transition: all 0.42s cubic-bezier(0.22, 1, 0.36, 1);
}

.tab:hover .tab-icon,
.tab.active .tab-icon {
    color: white;
    transform: scale(1.1);
}

/* Стили поиска */
.sidebar-search {
    width: 100%;
    padding: 9px 14px 9px 38px;
    background: rgba(10, 24, 38, 0.72);
    border: 1px solid rgba(102, 192, 244, 0.2);
    border-radius: 10px;
    color: rgba(255, 255, 255, 0.97);
    font-size: 13px;
    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
    opacity: 0;
    backdrop-filter: blur(12px) saturate(180%);
    box-sizing: border-box;
}

.sidebar-search::placeholder {
    color: rgba(149, 165, 166, 0.7);
}

.search-box {
    position: relative;
    display: flex;
    flex-shrink: 0;
    align-items: center;
    padding: 0 12px;
    margin-bottom: 8px;
    width: 100%;
    box-sizing: border-box;
}

/* CSS-лупа: круг + ручка через два псевдослоя на самой search-box */
.search-box::before {
    content: '';
    position: absolute;
    left: 22px;
    top: 50%;
    width: 11px;
    height: 11px;
    border: 1.5px solid rgba(102, 192, 244, 0.85);
    border-radius: 50%;
    transform: translateY(-50%);
    z-index: 1;
    transition: all 0.3s ease;
    opacity: 0;
    box-shadow: 6px 6px 0 -4.5px rgba(102, 192, 244, 0.85);
}

.sidebar.is-open .search-box::before{
    opacity: 1;
}

.sidebar-search:focus {
    outline: none;
    background: rgba(31, 58, 78, 0.7);
    border-color: rgba(102, 192, 244, 0.6);
    box-shadow: 0 0 0 2px rgba(102, 192, 244, 0.3);
}

.sidebar.is-open .sidebar-search{
    opacity: 1;
}

.search-box,
.action-row,
.paginator,
.sidebar-header {
    animation: sdsContentIn 0.38s var(--sds-ease-out) both;
}

.sidebar-search:focus + .search-box::before {
    color: #66c0f4;
    transform: scale(1.1);
}

/* Анимация для элементов контента */
.content-item {
    animation: fadeInUp 0.34s var(--sds-ease-out);
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(12px) scale(0.99);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Адаптивность для очень маленьких экранов */
@media (max-width: 480px) {
    .sidebar {
        --sds-sidebar-open-width: 100vw;
        --sds-sidebar-collapsed-width: 72px;
        width: var(--sds-sidebar-open-width);
    }
    
    .sidebar.is-open{
        width: var(--sds-sidebar-open-width);
    }
    
    .sidebar.is-open .content-grid-row{
        grid-template-columns: repeat(3, 1fr);
    }
    
    .content-item {
        height: 18%;
        min-height: 70px;
    }
    
    .content-item img,
    .content-item video {
        width: 11%;
        height: 11%;
    }
}

.content-grid:has(.content-item:nth-child(100)) .content-item {
    transition: none;
}

/* Эффект частиц для сайдбара */
.sidebar::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle at 20% 30%, rgba(102, 192, 244, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(102, 192, 244, 0.1) 0%, transparent 50%);
    z-index: -1;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.sidebar.is-open::before{
    opacity: 1;
}

/* Специальные эффекты для активных элементов */
.tab.active::after {
    display: none;
}

@keyframes pulse {
    0% { box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.7); }
    70% { box-shadow: 0 0 0 6px rgba(255, 255, 255, 0); }
    100% { box-shadow: 0 0 0 0 rgba(255, 255, 255, 0); }
}

/* Paginator Styles */
.paginator {
    display: none;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 8px 12px;
    flex-wrap: wrap;
    flex-shrink: 0;
    width: 100%;
    box-sizing: border-box;
    border-top: 1px solid rgba(102, 192, 244, 0.1);
}

.paginator-btn {
    background: rgba(10, 24, 38, 0.72);
    color: rgba(255, 255, 255, 0.9);
    border: 1px solid rgba(102, 192, 244, 0.2);

    flex-grow: 1;
    cursor: pointer;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.38s cubic-bezier(0.22, 1, 0.36, 1);
    backdrop-filter: blur(12px) saturate(180%);
    position: relative;
    overflow: hidden;
    text-decoration: none;
    user-select: none;
}

.paginator-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at center, rgba(102, 192, 244, 0.15) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.3s ease;
    border-radius: inherit;
}

.paginator-btn:hover {
    background: linear-gradient(135deg, rgba(102, 192, 244, 0.3), rgba(74, 144, 226, 0.3));
    border-color: rgba(102, 192, 244, 0.4);
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
    color: white;
}

.paginator-btn:hover::before {
    opacity: 1;
}

.paginator-btn.active {
    background: linear-gradient(135deg, #66c0f4, #4a90e2);
    border-color: rgba(102, 192, 244, 0.6);
    color: white;
    box-shadow: 0 4px 20px rgba(102, 192, 244, 0.4);
    font-weight: 600;
}

.paginator-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none !important;
    box-shadow: none;
}

.paginator-btn:disabled:hover {
    background: rgba(10, 24, 38, 0.72);
    border-color: rgba(102, 192, 244, 0.2);
    transform: none;
    box-shadow: none;
}

.paginator-btn:disabled::before {
    display: none;
}

/* Navigation arrows */
.paginator-btn.arrow {
    min-width: 48px;
    font-size: 16px;
}

.paginator-btn.arrow i {
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Page info text */
.paginator-info {
    color: rgba(255, 255, 255, 0.7);
    font-size: 13px;
    margin: 0 12px;
    white-space: nowrap;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.sidebar.is-open .paginator-info{
    opacity: 1;
}

.paginator-page-input {
    appearance: none;
    -webkit-appearance: none;
    width: 92px;
    height: 36px;
    padding: 0 10px;
    border: 1px solid rgba(102, 192, 244, 0.24) !important;
    border-radius: 12px;
    background: linear-gradient(180deg, rgba(31, 58, 78, 0.62), rgba(24, 38, 60, 0.58)) !important;
    color: rgba(255, 255, 255, 0.94) !important;
    text-align: center;
    font-size: 13px;
    font-weight: 700;
    outline: none;
    transition: all 0.38s cubic-bezier(0.22, 1, 0.36, 1);
    box-shadow: inset 0 0 14px rgba(0, 0, 0, 0.16);
    font-family: inherit;
    line-height: 36px;
    caret-color: #8fd3ff;
}

.paginator-page-input::placeholder {
    color: rgba(255, 255, 255, 0.46);
}

.paginator-page-input:hover,
.paginator-page-input:focus {
    background: linear-gradient(180deg, rgba(45, 78, 108, 0.78), rgba(29, 49, 76, 0.72)) !important;
    border-color: rgba(102, 192, 244, 0.48);
    box-shadow: 0 4px 18px rgba(102, 192, 244, 0.18);
}

.paginator-page-input::-webkit-outer-spin-button,
.paginator-page-input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

/* Animation for page change */
@keyframes pageFlip {
    from {
        opacity: 0;
        transform: scale(0.95) translateY(10px);
    }
    to {
        opacity: 1;
        transform: scale(1) translateY(0);
    }
}

.paginator-btn:not(.disabled):active {
    animation: pageFlip 0.2s ease-out;
}

/* Responsive adjustments */
@media (max-width: 480px) {
    .paginator {
        gap: 6px;
        margin: 10px 0 60px 10px;
        padding: 8px 10px;
    }
    
    .paginator-btn {
        min-width: 36px;
        height: 36px;
        padding: 8px 12px;
        font-size: 13px;
        border-radius: 10px;
    }
    
    .paginator-btn.arrow {
        min-width: 40px;
        font-size: 14px;
    }
    
    .paginator-info {
        font-size: 12px;
        margin: 0 8px;
    }
}

/* Hide text when sidebar collapsed, show on hover - matching your pattern */
.paginator-btn span {
    visibility: hidden;
    opacity: 0;
    transition: all 0.3s ease;
}

.sidebar.is-open .paginator-btn span{
    visibility: visible;
    opacity: 1;
}



/* SSH: single theme — hide UI theme switch */
.sds-theme-switch,
#sdsThemeSwitch {
    display: none !important;
}
</style>` 

+

`<style>


/* Контейнер лоадера */
.grid-loader {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, rgba(18, 38, 56, 0.44), rgba(31, 58, 78, 0.26));
    backdrop-filter: blur(10px) saturate(140%);
    z-index: 10;
    border-radius: 16px;
    transition: opacity 0.18s ease;
    animation: sdsLoaderIn 0.18s var(--sds-ease-out) both;
}

.empty-state {
    display: flex;
    min-height: 180px;
    align-items: center;
    justify-content: center;
    color: rgba(255, 255, 255, 0.62);
    font-size: 13px;
    font-weight: 600;
    border: 1px dashed rgba(102, 192, 244, 0.22);
    border-radius: 12px;
    background: rgba(31, 58, 78, 0.22);
}

/* Сам спиннер */
.spinner {
    width: 36px;
    height: 36px;
    border: 3px solid rgba(102, 192, 244, 0.12);
    border-radius: 50%;
    border-top-color: #66c0f4; /* Твой основной синий цвет */
    box-shadow: 0 0 15px rgba(102, 192, 244, 0.3);
    animation: spin 0.72s linear infinite;
    margin-bottom: 12px;
}

/* Текст под спиннером */
.loader-text {
    color: #66c0f4;
    font-size: 14px;
    font-weight: 500;
    letter-spacing: 1px;
    text-transform: uppercase;
    animation: pulseText 1.5s ease-in-out infinite;
}

/* Анимация вращения */
@keyframes spin {
    to { transform: rotate(360deg); }
}

@keyframes sdsLoaderIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Анимация пульсации текста */
@keyframes pulseText {
    0%, 100% { opacity: 0.6; }
    50% { opacity: 1; }
}

.sidebar.is-open .action-row{
    opacity: 1;
}

/* === Группированные фильтры: 3 блока (Дата / Популярность / Избранное) === */
.action-row {
    opacity: 0;
    display: flex;
    gap: 8px;
    padding: 0 12px 6px 12px;
    flex-shrink: 0;
    justify-content: flex-start;
    align-items: center;
    width: 100%;
    box-sizing: border-box;
    min-height: 34px;
}

.filter-group {
    display: flex;
    flex: 0 0 auto;
    height: 36px;
    background: rgba(22, 46, 67, 0.62);
    border: 1px solid rgba(102, 192, 244, 0.22);
    border-radius: 999px;
    overflow: hidden;
    backdrop-filter: blur(12px) saturate(180%);
    -webkit-backdrop-filter: blur(12px) saturate(180%);
    position: relative;
    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
}

.filter-group:hover {
    border-color: rgba(102, 192, 244, 0.35);
    box-shadow: 0 4px 14px rgba(0, 0, 0, 0.25);
}

.filter-group:nth-child(1) { width: 210px; }
.filter-group:nth-child(2) { width: 236px; }

.filter-group-label {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 9px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: rgba(102, 192, 244, 0.95);
    background: rgba(102, 192, 244, 0.08);
    border-right: 1px solid rgba(102, 192, 244, 0.15);
    white-space: nowrap;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
    flex-shrink: 0;
    gap: 6px;
}

.filter-group-label i {
    font-size: 11px;
}

.sidebar.is-open .filter-group-label{
    opacity: 1;
    visibility: visible;
}

.action-btn {
    flex: 1 1 auto;
    background: transparent;
    color: rgba(255, 255, 255, 0.8);
    border: none;
    padding: 0 10px;
    cursor: pointer;
    border-radius: 0;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    gap: 5px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    min-width: 58px;
    height: 100%;
}

.action-btn + .action-btn {
    border-left: 1px solid rgba(102, 192, 244, 0.12);
}

.action-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at center, rgba(102, 192, 244, 0.2) 0%, transparent 75%);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.action-btn:hover {
    background: rgba(102, 192, 244, 0.12);
    color: #fff;
}

.action-btn:hover::before {
    opacity: 1;
}

.action-btn i {
    font-size: 13px;
    color: rgba(102, 192, 244, 0.85);
    transition: transform 0.3s ease;
}

.action-btn:hover i {
    transform: scale(1.15);
    color: #66c0f4;
}

.action-btn .arrow-icon {
    font-size: 10px;
    font-weight: 900;
    color: rgba(255, 255, 255, 0.7);
    line-height: 1;
}

.action-btn .filter-text {
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.25px;
    opacity: 1;
    visibility: visible;
    transition: all 0.3s ease;
    white-space: nowrap;
}

.sidebar.is-open .action-btn .filter-text{
    opacity: 1;
    visibility: visible;
}

@media (max-width: 480px) {
    .action-row {
        gap: 5px;
        padding: 10px;
    }
    .action-btn {
        padding: 8px 2px;
    }
}

.action-btn.active {
    background: linear-gradient(135deg, #66c0f4, #4a90e2);
    color: white;
    box-shadow: inset 0 0 16px rgba(102, 192, 244, 0.4), 0 2px 10px rgba(102, 192, 244, 0.3);
    font-weight: 600;
    z-index: 1;
}

.action-btn.active i,
.action-btn.active .arrow-icon,
.action-btn.active .filter-text {
    color: white;
}

.action-btn.active::after {
    display: none;
}

.action-btn.active:hover {
    transform: none;
    background: linear-gradient(135deg, #66c0f4, #4a90e2);
}

/* Группа избранного занимает меньше места */
.filter-group.fav-group {
    flex: 0 0 auto;
    width: 126px;
    max-width: 126px;
}

.filter-group.fav-group .action-btn {
    padding: 0 12px;
    min-width: 126px;
}

.filter-group.fav-group .action-btn .star-icon {
    font-size: 14px;
    color: #ffd84d;
    filter: drop-shadow(0 0 5px rgba(255, 216, 77, 0.35));
}

.filter-group.fav-group .action-btn.active {
    background: linear-gradient(135deg, #ffd84d, #ff9f43);
    color: #14293a;
    border-radius: inherit;
    box-shadow: inset 0 0 14px rgba(255, 255, 255, 0.18), 0 2px 14px rgba(255, 179, 64, 0.35);
}

.filter-group.fav-group .action-btn.active .star-icon,
.filter-group.fav-group .action-btn.active .filter-text {
    color: #14293a;
    filter: none;
}

 .starBtn, .lnkBtn {
        position: absolute;
        top: 10px;
        left: 10px;
        width: 32px;
        height: 32px;
        background: rgba(18, 38, 56, 0.88);
        color: rgba(255, 255, 255, 0.78);
        border: 1px solid rgba(102, 192, 244, 0.36);
        border-radius: 50%;
        cursor: pointer;
        font-size: 0;
        line-height: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s;
        z-index: 1001;
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.28);
    }
        .lnkBtn{
        left: auto !important;
        right: 10px;
        background: linear-gradient(135deg, #3b7dff, #2469fd);
        color: #fff;
        border-color: rgba(102, 192, 244, 0.45);
        }
    .lnkBtn:hover{
    background: linear-gradient(135deg, #66c0f4, #3876fc);
    transform: scale(1.05);
    }
    .starBtn:hover  {
        color: #ffd84d;
        border-color: rgba(255, 216, 77, 0.58);
        background: rgba(35, 53, 62, 0.95);
        transform: scale(1.05);
    }

    .starBtn.is-favorite {
        color: #182d3b;
        background: linear-gradient(135deg, #ffd84d, #ff9f43);
        border-color: rgba(255, 216, 77, 0.9);
        box-shadow: 0 0 0 1px rgba(255, 216, 77, 0.18), 0 8px 20px rgba(255, 179, 64, 0.35);
    }

    .starBtn.is-favorite:hover {
        color: #102536;
        background: linear-gradient(135deg, #ffe57a, #ffb456);
    }

    .starBtn .btn-icon,
    .lnkBtn .btn-icon {
        width: 17px;
        height: 17px;
        display: block;
        stroke: currentColor;
        flex: 0 0 auto;
    }

/* === SDS layout stability patch: дизайн тот же, сетка ровнее === */
.sidebar {
    transition: transform 0.64s cubic-bezier(0.16, 1, 0.3, 1),
                opacity 0.34s ease,
                box-shadow 0.34s ease;
    contain: layout style;
}

.sidebar-main {
    min-width: 0;
}

.sidebar.is-open .expanded-view {
    display: flex;
    animation: sdsExpandedViewIn 0.48s cubic-bezier(0.16, 1, 0.3, 1) both;
}

.sidebar.is-collapsing .expanded-view {
    display: flex;
    opacity: 0;
    transform: translateX(18px) scale(0.992);
    transition: opacity 0.22s ease, transform 0.36s cubic-bezier(0.16, 1, 0.3, 1);
    pointer-events: none;
}

.sidebar.is-expanding .collapsed-view,
.sidebar.is-expanding .collapsed-reset-wrap,
.sidebar.is-collapsing .collapsed-view,
.sidebar.is-collapsing .collapsed-reset-wrap {
    opacity: 0;
    pointer-events: none;
}

@keyframes sdsExpandedViewIn {
    from { opacity: 0; transform: translateX(22px) scale(0.992); }
    to { opacity: 1; transform: translateX(0) scale(1); }
}

.sidebar.is-open .equipped-column {
    animation: sdsEquippedColumnIn 0.54s cubic-bezier(0.16, 1, 0.3, 1) 0.06s both;
}

@keyframes sdsEquippedColumnIn {
    from { opacity: 0; transform: translateX(26px); }
    to { opacity: 1; transform: translateX(0); }
}

.tabs {
    display: grid;
    grid-template-columns: 86px repeat(5, minmax(92px, 1fr)) 72px minmax(124px, max-content);
    align-items: center;
    overflow-x: auto;
    overflow-y: hidden;
}

.tg-link-btn,
.tab,
.sds-theme-switch,
.sds-lang-switch,
.sds-profile-cost {
    height: 36px;
    min-width: 0 !important;
}

.tab {
    width: 100%;
    padding: 0 10px;
}

.tab span,
.filter-text,
.equipped-slot-name,
.collapsed-slot-name {
    overflow: hidden;
    text-overflow: ellipsis;
}

.sds-profile-cost {
    margin-left: 0;
}

.action-row {
    min-height: 44px;
    overflow-x: auto;
    overflow-y: hidden;
    padding-bottom: 8px;
}

.filter-group {
    flex-shrink: 0;
}

.content-grid-row {
    grid-template-columns: repeat(3, minmax(160px, 1fr));
    justify-content: stretch;
    align-items: stretch;
    gap: 12px;
}

.content-item {
    min-height: 198px;
    border-radius: 8px;
    padding: 10px 40px 12px;
}

.item-text {
    min-height: 42px;
    width: 100%;
    max-width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.item-text a {
    max-width: 100%;
    line-height: 1.25;
    overflow-wrap: anywhere;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
}

#tab3 .content-grid-row,
#tab4 .content-grid-row {
    grid-template-columns: repeat(3, minmax(150px, 1fr));
}

#tab3 .content-item,
#tab4 .content-item {
    min-height: 166px;
    padding: 8px 38px 10px;
}

#tab3 .content-item img,
#tab3 .content-item video,
#tab4 .content-item img,
#tab4 .content-item video {
    width: clamp(124px, 72%, 154px);
    max-width: calc(100% - 8px);
    height: auto;
    aspect-ratio: 16 / 9;
    margin: 18px auto 8px;
    object-fit: contain;
}

#tab3 .item-text,
#tab4 .item-text {
    min-height: 34px;
}

#tab3 .item-text a,
#tab4 .item-text a {
    -webkit-line-clamp: 2;
}

.collapsed-slot.wide .collapsed-slot-preview img,
.collapsed-slot.wide .collapsed-slot-preview video {
    object-fit: contain;
}

.equipped-slot,
.collapsed-slot {
    min-width: 0;
}

.equipped-slot-name,
.collapsed-slot-name {
    white-space: normal;
    overflow-wrap: anywhere;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}

@media (max-width: 760px) {
    .sidebar {
        --sds-sidebar-open-width: 100vw;
        --sds-sidebar-collapsed-width: 86px;
    }
    .equipped-column {
        width: 178px;
    }
    .tabs {
        grid-template-columns: 76px repeat(5, minmax(86px, 1fr)) 68px 116px;
    }
    .content-grid-row {
        grid-template-columns: repeat(2, minmax(150px, 1fr));
    }
}

/* === SDS balanced tile layout + shared themes === */
.sidebar {
    --sds-accent: #66c0f4;
    --sds-accent-hover: #8fd3ff;
    --sds-accent-gradient: linear-gradient(135deg, #66c0f4, #4a90e2 58%, #58ffc2);
    --sds-accent-gradient-hover: linear-gradient(135deg, #7acdff, #5b9df5 58%, #90ffd7);
    --sds-panel-bg: linear-gradient(135deg, rgba(10, 21, 32, 0.94), rgba(23, 43, 60, 0.88), rgba(16, 38, 42, 0.90));
    --sds-card-bg: rgba(31, 58, 78, 0.36);
    --sds-card-border: 1px solid rgba(102, 192, 244, 0.24);
    --sds-ambient-overlay: radial-gradient(circle at 18% 24%, rgba(102, 192, 244, 0.14) 0%, transparent 42%),
                           radial-gradient(circle at 84% 72%, rgba(88, 255, 194, 0.10) 0%, transparent 40%);
    background: var(--sds-panel-bg);
}

.sidebar::before {
    background: var(--sds-ambient-overlay);
}

.sidebar.is-open .tabs {
    display: grid;
    grid-template-columns: 86px minmax(126px, 1.05fr) minmax(126px, 1.05fr) minmax(96px, 0.8fr) 72px minmax(124px, max-content);
    grid-template-rows: 36px 36px;
    gap: 6px;
    align-items: center;
    overflow: visible;
    padding: 8px 12px 8px 12px;
}

.tg-link-btn { grid-column: 1; grid-row: 1; }
.tab[data-tab="tab1"] { grid-column: 2; grid-row: 1; }
.tab[data-tab="tab2"] { grid-column: 3; grid-row: 1; }
.tab[data-tab="tab5"] { grid-column: 4; grid-row: 1; }
.sds-lang-switch { grid-column: 5; grid-row: 1; }
.sds-profile-cost { grid-column: 6; grid-row: 1; }
.sds-theme-switch { grid-column: 1; grid-row: 2; }
.tab[data-tab="tab3"] { grid-column: 2 / span 2; grid-row: 2; }
.tab[data-tab="tab4"] { grid-column: 4 / span 3; grid-row: 2; }

.tab,
.tg-link-btn,
.sds-theme-switch,
.sds-lang-switch,
.sds-profile-cost {
    background: rgba(31, 58, 78, 0.52);
    border-color: rgba(102, 192, 244, 0.22);
}

.tab:hover,
.tg-link-btn:hover,
.sds-theme-switch:hover,
.sds-lang-switch:hover {
    background: var(--sds-accent-gradient-hover);
    border-color: var(--sds-accent-hover);
}

.tab.active,
.action-btn.active,
.paginator-btn.active,
.filter-group.fav-group .action-btn.active {
    background: var(--sds-accent-gradient);
    border-color: var(--sds-accent-hover);
    color: white;
}

.sds-theme-dot {
    background: var(--sds-accent-gradient);
}

.action-row {
    flex-wrap: wrap;
    overflow: visible;
    min-height: 44px;
    padding-bottom: 8px;
}

.filter-group:nth-child(2) {
    width: 272px;
}

.filter-group:nth-child(2) .action-btn {
    min-width: 76px;
}

#popularityBtnDown .filter-text {
    min-width: 48px;
}

.content-grid {
    gap: 12px;
}

.content-grid-row,
#tab3 .content-grid-row,
#tab4 .content-grid-row {
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 12px;
}

.content-item,
#tab3 .content-item,
#tab4 .content-item {
    min-height: 214px;
    padding: 10px;
    justify-content: flex-start;
    gap: 8px;
    background: var(--sds-card-bg);
    border: var(--sds-card-border);
    border-radius: 10px;
}

.content-item:hover {
    border-color: var(--sds-accent-hover);
    background: rgba(31, 58, 78, 0.50);
}

.content-item > img,
.content-item > video,
#tab3 .content-item > img,
#tab3 .content-item > video,
#tab4 .content-item > img,
#tab4 .content-item > video {
    width: 100%;
    max-width: none;
    height: 136px;
    aspect-ratio: auto;
    margin: 0;
    object-fit: contain;
    object-position: center;
    background: rgba(0, 0, 0, 0.22);
    border-radius: 8px;
}

#tab1 .content-item > img {
    width: 82%;
    height: 112px;
    margin: 0 auto;
    object-fit: contain;
}

#tab2 .content-item > img,
#tab2 .content-item > video,
#tab5 .content-item > img,
#tab5 .content-item > video {
    width: 100%;
    max-width: none;
    height: 136px;
    object-fit: contain;
}

.custom-avatar-icon {
    width: 100%;
    height: 136px;
    border-radius: 8px;
    margin: 0;
}

.item-text {
    min-height: 42px;
    padding: 0 4px;
}

.item-text a {
    font-size: 12px;
    font-weight: 700;
}

.starBtn,
.lnkBtn {
    top: 12px;
    width: 34px;
    height: 34px;
    padding: 0;
    margin: 0;
    appearance: none;
    -webkit-appearance: none;
    box-sizing: border-box;
    z-index: 3;
}

.starBtn {
    left: 12px;
}

.lnkBtn {
    right: 12px;
    background: var(--sds-accent-gradient);
}

.starBtn .btn-icon,
.lnkBtn .btn-icon {
    width: 18px;
    height: 18px;
    margin: 0;
    position: static;
}

.equipped-slot,
.collapsed-slot {
    background: var(--sds-card-bg);
    border: var(--sds-card-border);
}

@media (max-width: 760px) {
    .sidebar.is-open .tabs {
        grid-template-columns: 76px repeat(3, minmax(82px, 1fr)) 68px 108px;
    }

    .content-grid-row,
    #tab3 .content-grid-row,
    #tab4 .content-grid-row {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

/* Final collapsed column polish + stable collapse transition */
.sidebar.is-open.is-collapsing {
    visibility: visible;
    pointer-events: none;
    opacity: 1;
    transform: translateX(calc(100% - var(--sds-sidebar-collapsed-width)));
}

.sidebar.is-open.is-collapsing .expanded-view {
    display: flex;
    opacity: 0;
    transform: translateX(18px) scale(0.992);
    transition: opacity 0.18s ease, transform 0.32s var(--sds-ease-out);
    pointer-events: none;
}

.sidebar.is-open.is-collapsing .collapsed-view,
.sidebar.is-open.is-collapsing .collapsed-reset-wrap {
    display: none !important;
}

.collapsed-view {
    padding: 12px 10px 10px;
    gap: 10px;
    background: linear-gradient(180deg, rgba(10, 20, 34, 0.36), rgba(18, 33, 48, 0.22));
}

.collapsed-slot {
    align-items: center;
    padding: 8px;
    border-radius: 14px;
    background: linear-gradient(180deg, rgba(38, 58, 78, 0.64), rgba(24, 39, 58, 0.54));
    border: 1px solid rgba(127, 211, 255, 0.22);
    box-shadow: inset 0 0 18px rgba(255, 255, 255, 0.03), 0 10px 24px rgba(0, 0, 0, 0.18);
}

.collapsed-slot:hover {
    border-color: rgba(143, 211, 255, 0.55);
    box-shadow: inset 0 0 20px rgba(255, 255, 255, 0.05), 0 12px 26px rgba(0, 0, 0, 0.28), 0 0 18px rgba(102, 192, 244, 0.18);
}

.collapsed-slot-label {
    width: 100%;
    padding: 0 0 6px;
    text-align: center;
    color: #8fd3ff;
    font-size: 9px;
    font-weight: 800;
    letter-spacing: 0.8px;
}

.collapsed-slot-preview {
    width: 100%;
    border-radius: 12px;
    background: linear-gradient(135deg, rgba(7, 15, 28, 0.74), rgba(19, 31, 48, 0.68));
    border: 1px solid rgba(143, 211, 255, 0.22);
    box-shadow: inset 0 0 18px rgba(0, 0, 0, 0.22);
}

.collapsed-slot-preview img,
.collapsed-slot-preview video {
    object-fit: contain;
    object-position: center;
}

.collapsed-slot.empty .collapsed-slot-preview {
    background: repeating-linear-gradient(
        45deg,
        rgba(102, 192, 244, 0.07),
        rgba(102, 192, 244, 0.07) 7px,
        rgba(143, 211, 255, 0.13) 7px,
        rgba(143, 211, 255, 0.13) 14px
    );
}

.collapsed-slot.empty .collapsed-slot-preview::after {
    color: rgba(255, 255, 255, 0.34);
}

.collapsed-slot-name {
    width: 100%;
    padding: 6px 2px 0;
    text-align: center;
    font-size: 10px;
    font-weight: 700;
    color: rgba(255, 255, 255, 0.9);
}

.collapsed-reset-wrap {
    padding: 9px 10px 12px;
    background: linear-gradient(180deg, rgba(18, 33, 48, 0.28), rgba(10, 20, 34, 0.42));
}

.collapsed-reset-wrap .reset-btn {
    min-height: 42px;
    border-radius: 14px;
}

.equipped-slot-name {
    text-align: center;
}

/* Clean readable pass */
.sidebar {
    font-family: 'Segoe UI Variable Text', 'Segoe UI', Arial, sans-serif;
    background: #112338 !important;
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
    border-left: 1px solid rgba(102, 192, 244, 0.28);
    box-shadow: -10px 0 28px rgba(0, 0, 0, 0.36);
}

.sidebar::before {
    display: none !important;
}

.sidebar-main {
    background: #112b3d;
}

.tab-content {
    background: #112b3d;
}

.content-item {
    min-height: 232px;
    padding: 12px 24px 16px;
    background: #17344a;
    border: 1px solid rgba(124, 183, 220, 0.34);
    border-radius: 10px;
    box-shadow: none;
}

.content-item:hover {
    background: #1a3a52;
    border-color: rgba(143, 211, 255, 0.58);
    transform: translateY(-2px);
    box-shadow: 0 8px 18px rgba(0, 0, 0, 0.22);
}

.content-item::before {
    display: none;
}

.content-item > img,
.content-item > video,
.content-item > svg {
    height: 130px;
    margin-bottom: 10px;
}

.item-text {
    min-height: 56px;
    padding: 0 2px;
}

.item-text a {
    color: rgba(255, 255, 255, 0.94);
    font-size: 13px;
    font-weight: 650;
    line-height: 1.28;
    text-align: center;
    -webkit-line-clamp: 3;
}

#tab3 .content-item,
#tab4 .content-item {
    min-height: 198px;
    padding: 10px 22px 14px;
}

#tab3 .item-text,
#tab4 .item-text {
    min-height: 52px;
}

#tab3 .item-text a,
#tab4 .item-text a {
    -webkit-line-clamp: 3;
}

.equipped-column {
    width: 188px;
    background: #10253a;
    border-left: 1px solid rgba(124, 183, 220, 0.24);
}

.equipped-title {
    padding: 12px 10px;
    color: #9cd2f7;
    background: none;
    -webkit-background-clip: initial;
    background-clip: initial;
    animation: none;
    border-bottom: 1px solid rgba(124, 183, 220, 0.18);
    letter-spacing: 1px;
}

.equipped-list {
    padding: 10px;
    gap: 10px;
}

.equipped-slot {
    padding: 9px;
    gap: 7px;
    background: #142e44;
    border: 1px solid rgba(124, 183, 220, 0.28);
    border-radius: 10px;
    box-shadow: none;
}

.equipped-slot:hover {
    background: #17354d;
    border-color: rgba(143, 211, 255, 0.5);
    transform: none;
    box-shadow: none;
}

.equipped-slot-label {
    font-size: 10px;
    font-weight: 750;
    letter-spacing: 0.7px;
    color: #9cd2f7;
}

.equipped-slot-preview {
    border-radius: 8px;
    background: #0c1726;
    border: 1px solid rgba(124, 183, 220, 0.18);
}

.equipped-slot-name {
    min-height: 30px;
    color: rgba(255, 255, 255, 0.92);
    font-size: 11px;
    font-weight: 650;
    line-height: 1.25;
    -webkit-line-clamp: 3;
}

.equipped-reset-wrap {
    background: #10253a;
    border-top: 1px solid rgba(124, 183, 220, 0.18);
}

.sidebar.is-open.is-collapsing {
    visibility: visible;
    pointer-events: none;
    opacity: 1;
    transform: translateX(calc(100% - var(--sds-sidebar-collapsed-width)));
}

.sidebar.is-open.is-collapsing .expanded-view {
    display: none !important;
}

.sidebar.is-open.is-collapsing .collapsed-view {
    display: flex !important;
    animation: none !important;
}

.sidebar.is-open.is-collapsing .collapsed-reset-wrap {
    display: block !important;
    animation: none !important;
}

.collapsed-view {
    background: #10253a;
    padding: 10px 8px;
    gap: 8px;
}

.collapsed-slot {
    padding: 7px;
    gap: 5px;
    background: #142e44;
    border: 1px solid rgba(124, 183, 220, 0.28);
    border-radius: 10px;
    box-shadow: none;
}

.collapsed-slot:hover {
    border-color: rgba(143, 211, 255, 0.5);
    box-shadow: none;
}

.collapsed-slot-label {
    padding-bottom: 4px;
    color: #9cd2f7;
    font-size: 9px;
    font-weight: 750;
}

.collapsed-slot-preview {
    border-radius: 8px;
    background: #0c1726;
    border: 1px solid rgba(124, 183, 220, 0.2);
    box-shadow: none;
}

.collapsed-slot-name {
    min-height: 28px;
    padding-top: 5px;
    color: rgba(255, 255, 255, 0.92);
    font-size: 10px;
    font-weight: 650;
    line-height: 1.22;
    -webkit-line-clamp: 3;
}

.collapsed-reset-wrap {
    background: #10253a;
    border-top: 1px solid rgba(124, 183, 220, 0.18);
}

/* Sidebar redesign v3: real compact width, no sliding slab */
.sidebar {
    --sds-sidebar-open-width: min(940px, calc(100vw - 10px));
    --sds-sidebar-collapsed-width: 174px;
    width: var(--sds-sidebar-collapsed-width) !important;
    transform: translateX(100%);
    background: linear-gradient(180deg, #102338 0%, #122a40 58%, #0e2135 100%) !important;
    transition: width 0.16s var(--sds-ease-out),
                transform 0.16s var(--sds-ease-out),
                opacity 0.12s ease !important;
    overflow: hidden;
}

.sidebar::before {
    content: '';
    display: block !important;
    position: absolute;
    inset: 0;
    z-index: 0;
    pointer-events: none;
    opacity: 0.35;
    background-image:
        radial-gradient(circle at 14% 24%, rgba(143, 211, 255, 0.18) 0 2px, transparent 3px),
        radial-gradient(circle at 72% 18%, rgba(130, 246, 211, 0.14) 0 2px, transparent 3px),
        radial-gradient(circle at 84% 70%, rgba(143, 211, 255, 0.12) 0 2px, transparent 3px),
        linear-gradient(135deg, rgba(102, 192, 244, 0.08), transparent 44%, rgba(88, 255, 194, 0.05));
    background-size: 180px 240px, 220px 260px, 260px 220px, 100% 100%;
    animation: sdsPanelDrift 12s linear infinite;
}

@keyframes sdsPanelDrift {
    from { background-position: 0 0, 0 0, 0 0, 0 0; }
    to { background-position: 0 -240px, 0 -260px, 0 -220px, 0 0; }
}

.sidebar.is-collapsed {
    width: var(--sds-sidebar-collapsed-width) !important;
    transform: translateX(0) !important;
    opacity: 1;
}

.sidebar.is-open {
    width: var(--sds-sidebar-open-width) !important;
    transform: translateX(0) !important;
    opacity: 1;
}

.sidebar.is-open.is-collapsing {
    width: var(--sds-sidebar-collapsed-width) !important;
    transform: translateX(0) !important;
    opacity: 1;
}

.sidebar.is-closing,
.sidebar.is-open.is-closing,
.sidebar.is-collapsed.is-closing {
    width: var(--sds-sidebar-collapsed-width) !important;
    transform: translateX(100%) !important;
    opacity: 0 !important;
    pointer-events: none !important;
}

.expanded-view,
.collapsed-view,
.collapsed-reset-wrap {
    position: relative;
    z-index: 1;
}

.sidebar.is-open.is-collapsing .expanded-view {
    display: none !important;
}

.sidebar.is-open.is-collapsing .collapsed-view {
    display: flex !important;
}

.sidebar.is-open.is-collapsing .collapsed-reset-wrap {
    display: block !important;
}

.sidebar-main,
.tab-content {
    background: transparent !important;
}

.content-grid-row,
#tab3 .content-grid-row,
#tab4 .content-grid-row {
    grid-template-columns: repeat(3, minmax(220px, 1fr));
    gap: 16px;
}

.content-item,
#tab3 .content-item,
#tab4 .content-item {
    min-height: 212px;
    padding: 14px 30px 16px;
    border-radius: 8px;
    background: rgba(24, 48, 72, 0.82);
    border: 1px solid rgba(122, 179, 216, 0.32);
}

.content-item > img,
.content-item > video,
.content-item > svg,
#tab3 .content-item img,
#tab3 .content-item video,
#tab4 .content-item img,
#tab4 .content-item video {
    width: 100%;
    max-width: none;
    height: 126px;
    margin: 2px auto 12px;
    aspect-ratio: 16 / 9;
    object-fit: contain;
    border-radius: 7px;
    background: rgba(7, 16, 28, 0.55);
}

.item-text,
#tab3 .item-text,
#tab4 .item-text {
    min-height: 50px;
}

.item-text a,
#tab3 .item-text a,
#tab4 .item-text a {
    font-size: 13px;
    font-weight: 650;
    line-height: 1.25;
    -webkit-line-clamp: 3;
}

.starBtn,
.lnkBtn {
    top: 12px;
}

.equipped-column {
    background: rgba(13, 29, 47, 0.82);
}

.collapsed-view {
    background: transparent;
}

.collapsed-slot,
.equipped-slot {
    background: rgba(19, 43, 66, 0.84);
    border-radius: 8px;
}

@media (max-width: 760px) {
    .sidebar {
        --sds-sidebar-open-width: calc(100vw - 8px);
        --sds-sidebar-collapsed-width: 156px;
    }

    .content-grid-row,
    #tab3 .content-grid-row,
    #tab4 .content-grid-row {
        grid-template-columns: repeat(2, minmax(180px, 1fr));
    }
}

/* Final v4: cleaner layout, slower preview reveal, synced theme surface */
.sidebar {
    --sds-sidebar-open-width: min(930px, calc(100vw - 8px));
    --sds-sidebar-collapsed-width: 172px;
    width: var(--sds-sidebar-collapsed-width) !important;
    background: var(--sds-panel-bg) !important;
    transition: width 0.18s var(--sds-ease-out), transform 0.14s var(--sds-ease-out), opacity 0.14s ease !important;
}

.sidebar.is-collapsed {
    width: var(--sds-sidebar-collapsed-width) !important;
    transform: translateX(0) !important;
}

.sidebar.is-open {
    width: var(--sds-sidebar-open-width) !important;
    transform: translateX(0) !important;
}

.sidebar.is-collapsing {
    display: none !important;
}

.sidebar.is-closing,
.sidebar.is-open.is-closing,
.sidebar.is-collapsed.is-closing {
    transform: translateX(100%) !important;
    opacity: 0 !important;
}

.sidebar::before {
    content: '';
    display: block !important;
    position: absolute;
    inset: 0;
    z-index: 0;
    pointer-events: none;
    opacity: 0.42;
    background-image:
        radial-gradient(circle at 16% 22%, var(--sds-accent) 0 2px, transparent 3px),
        radial-gradient(circle at 68% 18%, rgba(255,255,255,0.28) 0 1px, transparent 2px),
        radial-gradient(circle at 84% 74%, var(--sds-accent-hover) 0 2px, transparent 3px);
    background-size: 170px 230px, 210px 260px, 260px 240px;
    animation: sdsPanelDrift 18s linear infinite;
}

.expanded-view,
.collapsed-view,
.collapsed-reset-wrap {
    position: relative;
    z-index: 1;
}

.sidebar.is-collapsed .expanded-view,
.sidebar.is-open .collapsed-view,
.sidebar.is-open .collapsed-reset-wrap {
    display: none !important;
}

.sidebar.is-collapsed .collapsed-view {
    display: flex !important;
    opacity: 1 !important;
    animation: sdsSlotSoftIn 0.42s ease both;
}

.sidebar.is-collapsed .collapsed-reset-wrap {
    display: block !important;
    opacity: 1 !important;
}

.content-grid-row,
#tab3 .content-grid-row,
#tab4 .content-grid-row {
    grid-template-columns: repeat(3, minmax(0, 1fr));
    align-items: stretch;
    gap: 14px;
}

.content-item,
#tab3 .content-item,
#tab4 .content-item {
    min-height: 184px;
    height: 184px;
    padding: 12px 24px 14px;
    justify-content: flex-start;
    gap: 0;
    box-sizing: border-box;
    border-radius: 8px;
    background: rgba(24, 48, 72, 0.72);
    border: 1px solid rgba(122, 179, 216, 0.32);
}

.content-item > img,
.content-item > video,
.content-item > svg,
#tab3 .content-item img,
#tab3 .content-item video,
#tab4 .content-item img,
#tab4 .content-item video {
    width: 100%;
    height: 104px;
    max-width: none;
    aspect-ratio: 16 / 9;
    margin: 0 auto 10px;
    object-fit: cover;
    border-radius: 7px;
}

#tab1 .content-item > img,
#tab2 .content-item > img,
#tab2 .content-item > video,
#tab5 .content-item > img,
#tab5 .content-item > video {
    width: 100%;
    max-width: none;
    height: 104px;
    aspect-ratio: 16 / 9;
    margin: 0 auto 10px;
    object-fit: contain;
    border-radius: 7px;
    background: rgba(7, 16, 28, 0.55);
}

#tab3 .content-item img,
#tab3 .content-item video,
#tab4 .content-item img,
#tab4 .content-item video {
    object-fit: contain;
}

.item-text,
#tab3 .item-text,
#tab4 .item-text {
    min-height: 48px;
    height: 48px;
    max-height: 48px;
    margin-top: auto;
}

.item-text a,
#tab3 .item-text a,
#tab4 .item-text a {
    font-size: 13px;
    line-height: 1.22;
    -webkit-line-clamp: 3;
}

.equipped-column {
    width: 184px;
    background: rgba(12, 27, 44, 0.74);
}

.equipped-slot,
.collapsed-slot {
    background: rgba(18, 39, 62, 0.82);
    border: 1px solid rgba(122, 179, 216, 0.28);
    border-radius: 8px;
    animation: sdsSlotSoftIn 0.46s ease both;
}

.equipped-slot-preview img,
.equipped-slot-preview video,
.collapsed-slot-preview img,
.collapsed-slot-preview video {
    opacity: 0;
    animation: sdsMediaSoftIn 0.62s ease 0.06s forwards;
}

@keyframes sdsSlotSoftIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes sdsMediaSoftIn {
    from { opacity: 0; transform: scale(0.975); filter: blur(2px); }
    to { opacity: 1; transform: scale(1); filter: blur(0); }
}

@media (max-width: 760px) {
    .sidebar {
        --sds-sidebar-open-width: calc(100vw - 8px);
        --sds-sidebar-collapsed-width: 154px;
    }

    .content-grid-row,
    #tab3 .content-grid-row,
    #tab4 .content-grid-row {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

/* Final v5: opaque menu, no background effects */
.sidebar {
    background: var(--sds-panel-solid, #102338) !important;
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
}

.sidebar::before,
.sidebar::after {
    content: none !important;
    display: none !important;
    background: none !important;
    animation: none !important;
}

.expanded-view,
.sidebar-main,
.tab-content {
    background: var(--sds-panel-solid, #102338) !important;
}

.tabs,
.subtabs,
.action-row,
.paginator {
    background: var(--sds-panel-solid, #102338) !important;
}

.equipped-column,
.collapsed-view,
.collapsed-reset-wrap,
.equipped-reset-wrap {
    background: var(--sds-side-solid, #0f2236) !important;
}

.content-item,
#tab3 .content-item,
#tab4 .content-item {
    min-height: 184px;
    height: 184px;
    padding: 10px 22px 12px;
    gap: 0;
    box-sizing: border-box;
    background: var(--sds-card-solid, #173047) !important;
    border: var(--sds-card-border);
}

.content-item > img,
.content-item > video,
.content-item > svg,
#tab3 .content-item img,
#tab3 .content-item video,
#tab4 .content-item img,
#tab4 .content-item video {
    height: 104px;
    margin-bottom: 8px;
}

.item-text,
#tab3 .item-text,
#tab4 .item-text {
    min-height: 48px;
    height: 48px;
    max-height: 48px;
}

.equipped-slot,
.collapsed-slot {
    background: var(--sds-card-solid, #173047) !important;
}

.equipped-slot-preview,
.collapsed-slot-preview {
    background: var(--sds-side-solid, #0f2236) !important;
}

.content-item {
    position: relative;
    overflow: hidden;
}

.starBtn,
.lnkBtn {
    top: 14px !important;
    width: 34px !important;
    height: 34px !important;
    margin: 0 !important;
    z-index: 5;
}

.starBtn {
    left: 14px !important;
}

.lnkBtn {
    right: 14px !important;
}

/* Final performance/UX pass: real loader, smoother panel motion, theme-only switch */
.sidebar {
    width: var(--sds-sidebar-open-width) !important;
    transform: translateX(100%) !important;
    transition: transform 0.46s cubic-bezier(0.16, 1, 0.3, 1),
                opacity 0.26s ease !important;
}

.sidebar.is-collapsed {
    width: var(--sds-sidebar-open-width) !important;
    transform: translateX(calc(100% - var(--sds-sidebar-collapsed-width))) !important;
    opacity: 1 !important;
}

.sidebar.is-open {
    width: var(--sds-sidebar-open-width) !important;
    transform: translateX(0) !important;
    opacity: 1 !important;
}

.sidebar.is-open.is-collapsing,
.sidebar.is-collapsed.is-closing,
.sidebar.is-open.is-closing,
.sidebar.is-closing {
    width: var(--sds-sidebar-open-width) !important;
}

.sidebar.is-collapsed.is-closing,
.sidebar.is-open.is-closing,
.sidebar.is-closing {
    transform: translateX(100%) !important;
    opacity: 0 !important;
}

.sidebar.is-open.is-collapsing {
    transform: translateX(calc(100% - var(--sds-sidebar-collapsed-width))) !important;
    opacity: 1 !important;
}

.sidebar.is-open.is-collapsing .expanded-view {
    display: flex !important;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.24s ease !important;
}

.sidebar.is-open.is-collapsing .collapsed-view,
.sidebar.is-open.is-collapsing .collapsed-reset-wrap {
    display: none !important;
}

.sidebar.is-open .expanded-view {
    animation: sdsExpandedSmoothIn 0.42s cubic-bezier(0.16, 1, 0.3, 1) both !important;
}

@keyframes sdsExpandedSmoothIn {
    from {
        opacity: 0.45;
        transform: translateX(18px);
        filter: blur(1.5px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
        filter: blur(0);
    }
}

.content-grid-row {
    content-visibility: auto;
    contain-intrinsic-size: 184px;
}

.content-item.is-media-pending::before {
    content: 'Загрузка...';
    display: flex !important;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: 10px;
    left: 22px;
    right: 22px;
    height: 104px;
    border-radius: 7px;
    color: rgba(205, 231, 248, 0.9);
    font-size: 13px;
    font-weight: 800;
    letter-spacing: 0.2px;
    background:
        linear-gradient(90deg, rgba(102, 192, 244, 0.08), rgba(143, 211, 255, 0.18), rgba(102, 192, 244, 0.08)),
        rgba(7, 16, 28, 0.70);
    background-size: 220% 100%, 100% 100%;
    border: 1px solid rgba(143, 211, 255, 0.18);
    box-shadow: inset 0 0 20px rgba(102, 192, 244, 0.08);
    opacity: 1;
    animation: sdsMediaLoading 1.2s ease-in-out infinite;
    pointer-events: none;
    z-index: 1;
}

.content-item > .sds-lazy-media[data-sds-src],
.content-item > video[data-sds-poster] {
    opacity: 0;
}

.content-item > .sds-lazy-media,
.content-item > video {
    transition: opacity 0.18s ease;
}

@keyframes sdsMediaLoading {
    0% { background-position: 0% 50%, 0 0; }
    100% { background-position: 220% 50%, 0 0; }
}

.sds-theme-only-toggle {
    min-height: 48px;
    padding: 0 16px;
    border-radius: 999px;
    border: 1px solid rgba(143, 211, 255, 0.26);
    background: rgba(19, 43, 66, 0.84);
    color: rgba(255, 255, 255, 0.92);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    font-size: 12px;
    font-weight: 850;
    letter-spacing: 0.2px;
    cursor: pointer;
    white-space: nowrap;
    transition: background 0.2s ease, border-color 0.2s ease, transform 0.2s ease;
}

.sds-theme-only-toggle:hover {
    transform: translateY(-1px);
    border-color: rgba(143, 211, 255, 0.5);
    background: rgba(24, 54, 82, 0.92);
}

.sds-theme-only-track {
    width: 36px;
    height: 20px;
    padding: 2px;
    border-radius: 999px;
    background: rgba(7, 16, 28, 0.86);
    border: 1px solid rgba(143, 211, 255, 0.24);
    display: inline-flex;
    align-items: center;
    justify-content: flex-start;
}

.sds-theme-only-thumb {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: rgba(205, 231, 248, 0.92);
    box-shadow: 0 0 10px rgba(143, 211, 255, 0.45);
    transition: transform 0.2s ease, background 0.2s ease;
}

.sds-theme-only-toggle.is-on {
    border-color: rgba(116, 231, 198, 0.55);
    background: rgba(22, 71, 76, 0.82);
}

.sds-theme-only-toggle.is-on .sds-theme-only-track {
    background: linear-gradient(135deg, rgba(102, 192, 244, 0.55), rgba(88, 255, 194, 0.55));
}

.sds-theme-only-toggle.is-on .sds-theme-only-thumb {
    transform: translateX(16px);
    background: #ffffff;
}

.sds-theme-only-state {
    color: rgba(143, 211, 255, 0.82);
    font-size: 11px;
}

.sds-theme-only-toggle.is-on .sds-theme-only-state {
    color: #96ffd5;
}

/* Restored staged sidebar motion + compact theme-only switch */
.sidebar {
    --sds-sidebar-open-width: min(930px, calc(100vw - 8px));
    --sds-sidebar-collapsed-width: 172px;
    width: var(--sds-sidebar-open-width) !important;
    transform: translateX(100%) !important;
    transition: transform 0.54s cubic-bezier(0.16, 1, 0.3, 1),
                opacity 0.26s ease !important;
    will-change: transform, opacity;
}

.sidebar.is-collapsed {
    width: var(--sds-sidebar-open-width) !important;
    visibility: visible;
    pointer-events: auto;
    opacity: 1 !important;
    transform: translateX(calc(100% - var(--sds-sidebar-collapsed-width))) !important;
}

.sidebar.is-open {
    width: var(--sds-sidebar-open-width) !important;
    visibility: visible;
    pointer-events: auto;
    opacity: 1 !important;
    transform: translateX(0) !important;
}

.sidebar.is-collapsing {
    display: flex !important;
    visibility: visible;
}

.sidebar.is-open.is-collapsing {
    width: var(--sds-sidebar-open-width) !important;
    opacity: 1 !important;
    pointer-events: none !important;
    transform: translateX(calc(100% - var(--sds-sidebar-collapsed-width))) !important;
}

.sidebar.is-closing,
.sidebar.is-open.is-closing,
.sidebar.is-collapsed.is-closing {
    width: var(--sds-sidebar-open-width) !important;
    opacity: 0 !important;
    pointer-events: none !important;
    transform: translateX(100%) !important;
}

.sidebar.is-collapsed .expanded-view,
.sidebar.is-open .collapsed-view,
.sidebar.is-open .collapsed-reset-wrap {
    display: none !important;
}

.sidebar.is-collapsed .collapsed-view {
    display: flex !important;
    opacity: 1 !important;
    animation: sdsCollapsedIn 0.42s cubic-bezier(0.16, 1, 0.3, 1) both !important;
}

.sidebar.is-collapsed .collapsed-reset-wrap {
    display: block !important;
    opacity: 1 !important;
}

.sidebar.is-open .expanded-view {
    display: flex !important;
    animation: sdsExpandedSmoothIn 0.42s cubic-bezier(0.16, 1, 0.3, 1) both !important;
}

.sidebar.is-open.is-collapsing .expanded-view {
    display: flex !important;
    opacity: 0;
    transform: translateX(18px) scale(0.992);
    transition: opacity 0.22s ease, transform 0.36s cubic-bezier(0.16, 1, 0.3, 1) !important;
    pointer-events: none;
}

.sidebar.is-open.is-collapsing .collapsed-view,
.sidebar.is-open.is-collapsing .collapsed-reset-wrap {
    display: none !important;
}

.action-row .sds-theme-only-toggle {
    order: 4;
    flex: 0 0 184px;
    width: 184px;
    min-height: 36px;
    height: 36px;
    padding: 4px;
    border-radius: 999px;
    border: 1px solid rgba(143, 211, 255, 0.28);
    background: rgba(13, 29, 46, 0.88);
    display: inline-grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
    align-items: center;
    gap: 0;
    position: relative;
    overflow: hidden;
    contain: layout paint;
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.025);
    transition: border-color 0.18s ease, background 0.18s ease;
}

.action-row .sds-theme-only-toggle:hover {
    transform: none;
    border-color: rgba(143, 211, 255, 0.52);
    background: rgba(16, 37, 58, 0.94);
}

.action-row .sds-theme-only-track {
    position: absolute;
    inset: 4px auto 4px 4px;
    width: calc(50% - 4px);
    height: auto;
    padding: 0;
    border: 0;
    border-radius: 12px;
    background: var(--sds-accent-gradient);
    box-shadow: 0 8px 18px rgba(0, 0, 0, 0.22);
    transform: translateX(calc(100% + 0px));
    transition: transform 0.22s cubic-bezier(0.16, 1, 0.3, 1);
    z-index: 0;
}

.action-row .sds-theme-only-thumb {
    display: none;
}

.action-row .sds-theme-only-label,
.action-row .sds-theme-only-state {
    position: relative;
    z-index: 1;
    min-width: 0;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 6px;
    color: rgba(190, 222, 244, 0.76);
    font-size: 10px;
    font-weight: 850;
    line-height: 1.1;
    text-align: center;
    white-space: normal;
}

.action-row .sds-theme-only-state {
    font-size: 10px;
}

.action-row .sds-theme-only-toggle.is-on .sds-theme-only-track {
    transform: translateX(0);
}

.action-row .sds-theme-only-toggle.is-on .sds-theme-only-label,
.action-row .sds-theme-only-toggle:not(.is-on) .sds-theme-only-state {
    color: #ffffff;
    text-shadow: 0 1px 8px rgba(0, 0, 0, 0.24);
}

.action-row {
    flex-wrap: nowrap !important;
    overflow: visible !important;
}

.filter-group.fav-group {
    order: 3;
}

/* Final tile geometry guard: loader and media share one box, top row never clips */
.tab-content {
    padding: 10px 12px 12px 12px !important;
    scroll-padding-top: 18px;
}

.content-grid {
    padding-top: 14px !important;
    overflow: visible !important;
}

.content-grid-row,
#tab3 .content-grid-row,
#tab4 .content-grid-row {
    grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
    align-items: stretch !important;
    overflow: visible !important;
    content-visibility: visible !important;
    contain-intrinsic-size: auto !important;
}

.content-item,
#tab3 .content-item,
#tab4 .content-item {
    --sds-tile-pad-x: 22px;
    --sds-tile-pad-top: 10px;
    --sds-tile-media-height: 104px;
    --sds-tile-media-gap: 8px;
    height: 184px !important;
    min-height: 184px !important;
    padding: var(--sds-tile-pad-top) var(--sds-tile-pad-x) 12px !important;
    justify-content: flex-start !important;
    overflow: hidden;
}

.content-item:hover,
#tab3 .content-item:hover,
#tab4 .content-item:hover {
    transform: translateY(-1px) scale(1.005) !important;
}

.content-item > img,
.content-item > video,
.content-item > svg,
#tab3 .content-item > img,
#tab3 .content-item > video,
#tab4 .content-item > img,
#tab4 .content-item > video {
    width: 100% !important;
    max-width: none !important;
    height: var(--sds-tile-media-height) !important;
    margin: 0 auto var(--sds-tile-media-gap) !important;
    border-radius: 7px !important;
    background: rgba(7, 16, 28, 0.55);
    object-position: center !important;
}

#tab1 .content-item > img,
#tab2 .content-item > img,
#tab2 .content-item > video,
#tab3 .content-item > img,
#tab3 .content-item > video,
#tab4 .content-item > img,
#tab4 .content-item > video,
#tab5 .content-item > img,
#tab5 .content-item > video {
    aspect-ratio: 16 / 9 !important;
    object-fit: contain !important;
}

.custom-avatar-icon {
    height: var(--sds-tile-media-height) !important;
    margin: 0 auto var(--sds-tile-media-gap) !important;
}

.content-item.is-media-pending::before {
    top: var(--sds-tile-pad-top) !important;
    left: var(--sds-tile-pad-x) !important;
    right: var(--sds-tile-pad-x) !important;
    height: var(--sds-tile-media-height) !important;
    border-radius: 7px !important;
}

.item-text,
#tab3 .item-text,
#tab4 .item-text {
    height: 48px !important;
    min-height: 48px !important;
    max-height: 48px !important;
    margin-top: auto !important;
}

/* Final layout guard: no clipped expanded tiles or sliced panel during collapse */
.sidebar {
    --sds-equipped-column-width: 184px;
    max-width: calc(100vw - 8px) !important;
}

.sidebar.is-open .expanded-view {
    overflow: hidden !important;
}

.sidebar.is-open .sidebar-main {
    flex: 1 1 auto !important;
    width: calc(100% - var(--sds-equipped-column-width)) !important;
    max-width: calc(100% - var(--sds-equipped-column-width)) !important;
    min-width: 0 !important;
    overflow: hidden !important;
}

.sidebar.is-open .equipped-column {
    width: var(--sds-equipped-column-width) !important;
    flex: 0 0 var(--sds-equipped-column-width) !important;
}

.content-grid-row,
#tab3 .content-grid-row,
#tab4 .content-grid-row {
    width: 100% !important;
    max-width: 100% !important;
    gap: 12px !important;
}

.content-item,
#tab3 .content-item,
#tab4 .content-item {
    min-width: 0 !important;
    max-width: 100% !important;
}

.sidebar.is-open.is-collapsing .expanded-view {
    display: none !important;
}

.sidebar.is-open.is-collapsing .collapsed-view {
    display: flex !important;
    opacity: 1 !important;
    animation: none !important;
}

.sidebar.is-open.is-collapsing .collapsed-reset-wrap {
    display: block !important;
    opacity: 1 !important;
    animation: none !important;
}

.profile_avatar.sds-has-animated-avatar,
.playerAvatarAutoSizeInner.sds-has-animated-avatar {
    position: relative !important;
}

.playerAvatarAutoSizeInner.sds-has-animated-avatar {
    overflow: hidden;
}

.profile_avatar .sds-profile-avatar-video,
.playerAvatarAutoSizeInner .sds-profile-avatar-video {
    position: absolute !important;
    inset: 0 !important;
    width: 100% !important;
    height: 100% !important;
    object-fit: cover !important;
    object-position: center !important;
    display: block !important;
    z-index: 3 !important;
    pointer-events: none !important;
}

.profile_avatar .profile_avatar_frame,
.playerAvatarAutoSizeInner .profile_avatar_frame {
    z-index: 4 !important;
}

/* Final right column: mirror the compact column from the collapsed menu. */
.sidebar {
    --sds-equipped-column-width: var(--sds-sidebar-collapsed-width) !important;
}

.sidebar.is-open .equipped-column {
    width: var(--sds-equipped-column-width) !important;
    flex: 0 0 var(--sds-equipped-column-width) !important;
    background: var(--sds-side-solid, #0f2236) !important;
    border-left: 1px solid rgba(124, 183, 220, 0.24) !important;
}

.sidebar.is-open .sidebar-main {
    width: calc(100% - var(--sds-equipped-column-width)) !important;
    max-width: calc(100% - var(--sds-equipped-column-width)) !important;
}

.equipped-title {
    display: none !important;
}

.sidebar.is-open .equipped-list {
    padding: 10px 8px !important;
    gap: 8px !important;
}

.equipped-slot,
.collapsed-slot {
    position: relative !important;
    padding: 7px !important;
    gap: 5px !important;
    background: var(--sds-card-solid, #173047) !important;
    border: 1px solid rgba(124, 183, 220, 0.28) !important;
    border-radius: 10px !important;
    box-shadow: none !important;
}

.equipped-slot:hover,
.collapsed-slot:hover {
    transform: none !important;
    box-shadow: none !important;
    border-color: rgba(143, 211, 255, 0.5) !important;
}

.equipped-slot-label,
.collapsed-slot-label {
    padding-bottom: 4px !important;
    color: #9cd2f7 !important;
    font-size: 9px !important;
    font-weight: 750 !important;
    letter-spacing: 0.7px !important;
}

.equipped-slot-preview,
.collapsed-slot-preview {
    position: relative !important;
    border-radius: 8px !important;
    background: var(--sds-side-solid, #0f2236) !important;
    border: 1px solid rgba(124, 183, 220, 0.2) !important;
    box-shadow: none !important;
}

.equipped-slot-name,
.collapsed-slot-name {
    min-height: 28px !important;
    padding-top: 5px !important;
    color: rgba(255, 255, 255, 0.92) !important;
    font-size: 10px !important;
    font-weight: 650 !important;
    line-height: 1.22 !important;
    display: -webkit-box !important;
    -webkit-line-clamp: 3 !important;
    -webkit-box-orient: vertical !important;
    white-space: normal !important;
}

.slot-preview-actions {
    position: absolute !important;
    top: 7px !important;
    right: 7px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: flex-end !important;
    gap: 6px !important;
    z-index: 7 !important;
    pointer-events: auto !important;
}

.slot-preview-actions .starBtn,
.slot-preview-actions .lnkBtn {
    position: static !important;
    inset: auto !important;
    width: 30px !important;
    height: 30px !important;
    min-width: 30px !important;
    min-height: 30px !important;
    margin: 0 !important;
    padding: 0 !important;
    z-index: 1 !important;
    box-shadow: 0 5px 14px rgba(0, 0, 0, 0.32) !important;
}

.slot-preview-actions .starBtn .btn-icon,
.slot-preview-actions .lnkBtn .btn-icon {
    width: 16px !important;
    height: 16px !important;
}

/* ========================================================================== */
/* Liquid Glass refresh — Apple-inspired spatial hierarchy                     */
/* ========================================================================== */
.sidebar {
    --sds-sidebar-open-width: min(980px, calc(100vw - 16px)) !important;
    --sds-sidebar-collapsed-width: 172px !important;
    --sds-equipped-column-width: 172px !important;
    top: 8px !important;
    right: 8px !important;
    height: calc(100% - 16px) !important;
    padding: 10px !important;
    border: 1px solid rgba(255, 255, 255, 0.24) !important;
    border-radius: 28px !important;
    background:
        radial-gradient(900px circle at 14% -10%, rgba(132, 216, 255, 0.18), transparent 50%),
        linear-gradient(145deg, rgba(17, 36, 53, 0.68), rgba(7, 19, 31, 0.76)) !important;
    backdrop-filter: blur(42px) saturate(185%) brightness(1.04) !important;
    -webkit-backdrop-filter: blur(42px) saturate(185%) brightness(1.04) !important;
    box-shadow:
        -24px 30px 80px rgba(0, 0, 0, 0.44),
        inset 0 1px 0 rgba(255, 255, 255, 0.18),
        inset 0 -1px 0 rgba(255, 255, 255, 0.04) !important;
    font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Segoe UI", sans-serif !important;
}

.sidebar::before {
    opacity: 0.5 !important;
    background:
        radial-gradient(circle at 18% 10%, rgba(173, 226, 255, 0.13), transparent 28%),
        radial-gradient(circle at 74% 82%, rgba(85, 176, 255, 0.09), transparent 30%) !important;
}

.sidebar.is-open .expanded-view {
    gap: 10px !important;
    border-radius: 21px !important;
}

.sidebar.is-open .sidebar-main {
    width: calc(100% - var(--sds-equipped-column-width) - 10px) !important;
    max-width: calc(100% - var(--sds-equipped-column-width) - 10px) !important;
    border-radius: 21px !important;
    overflow: hidden !important;
    background: rgba(5, 16, 27, 0.18) !important;
    border: 1px solid rgba(255, 255, 255, 0.09) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.06) !important;
}

.tabs {
    width: calc(100% - 20px) !important;
    margin: 10px !important;
    padding: 6px !important;
    gap: 6px !important;
    border: 1px solid rgba(255, 255, 255, 0.12) !important;
    border-radius: 20px !important;
    background: rgba(255, 255, 255, 0.055) !important;
    backdrop-filter: blur(24px) saturate(180%) !important;
    -webkit-backdrop-filter: blur(24px) saturate(180%) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.09), 0 10px 30px rgba(0, 0, 0, 0.14) !important;
    scrollbar-width: none !important;
}
.tabs::-webkit-scrollbar { display: none !important; }

.tab,
.tg-link-btn,
.sds-lang-switch,
.sds-profile-cost {
    min-height: 40px !important;
    height: 40px !important;
    border: 1px solid rgba(255, 255, 255, 0.11) !important;
    border-radius: 15px !important;
    background: rgba(255, 255, 255, 0.045) !important;
    color: rgba(244, 249, 255, 0.82) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.055) !important;
    backdrop-filter: blur(18px) saturate(170%) !important;
    -webkit-backdrop-filter: blur(18px) saturate(170%) !important;
    transition: transform 0.24s var(--sds-ease-out), background 0.24s ease, border-color 0.24s ease, box-shadow 0.24s ease !important;
}

.tab:hover,
.tg-link-btn:hover,
.sds-lang-switch:hover {
    transform: translateY(-1px) !important;
    background: rgba(255, 255, 255, 0.1) !important;
    border-color: rgba(255, 255, 255, 0.2) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.12), 0 8px 18px rgba(0, 0, 0, 0.18) !important;
}

.tab.active {
    color: #031522 !important;
    font-weight: 750 !important;
    border-color: rgba(205, 242, 255, 0.72) !important;
    background: linear-gradient(180deg, rgba(147, 222, 255, 0.98), rgba(74, 181, 238, 0.94)) !important;
    box-shadow:
        inset 0 1px 0 rgba(255, 255, 255, 0.72),
        0 8px 22px rgba(44, 166, 232, 0.25) !important;
}

.sds-profile-cost {
    padding: 0 16px !important;
    background: rgba(134, 196, 230, 0.1) !important;
    color: rgba(248, 252, 255, 0.92) !important;
}

.search-box {
    margin: 0 10px 9px !important;
    padding: 0 !important;
    width: calc(100% - 20px) !important;
}
.search-box::before { left: 16px !important; border-color: rgba(177, 226, 255, 0.82) !important; }
.sidebar-search {
    height: 44px !important;
    padding: 0 18px 0 43px !important;
    border: 1px solid rgba(255, 255, 255, 0.13) !important;
    border-radius: 15px !important;
    background: rgba(255, 255, 255, 0.055) !important;
    color: rgba(255, 255, 255, 0.96) !important;
    backdrop-filter: blur(20px) saturate(175%) !important;
    -webkit-backdrop-filter: blur(20px) saturate(175%) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.07) !important;
}
.sidebar-search:focus {
    background: rgba(255, 255, 255, 0.09) !important;
    border-color: rgba(129, 211, 255, 0.62) !important;
    box-shadow: 0 0 0 4px rgba(68, 180, 240, 0.12), inset 0 1px 0 rgba(255, 255, 255, 0.1) !important;
}

.action-row {
    min-height: 44px !important;
    padding: 0 10px 9px !important;
    gap: 7px !important;
}
.filter-group {
    height: 40px !important;
    border: 1px solid rgba(255, 255, 255, 0.12) !important;
    border-radius: 15px !important;
    background: rgba(255, 255, 255, 0.05) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.055) !important;
    backdrop-filter: blur(18px) saturate(175%) !important;
}
.filter-group-label,
.action-btn {
    border-color: rgba(255, 255, 255, 0.08) !important;
    background: transparent !important;
    color: rgba(244, 249, 255, 0.68) !important;
}
.action-btn:hover { background: rgba(255, 255, 255, 0.075) !important; color: #fff !important; }
.action-btn.active {
    color: #061723 !important;
    background: rgba(126, 211, 255, 0.92) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.58) !important;
}

.tab-content {
    width: calc(100% - 20px) !important;
    margin: 0 10px !important;
    padding: 2px 9px 12px !important;
    border: 1px solid rgba(255, 255, 255, 0.085) !important;
    border-radius: 20px !important;
    background: rgba(3, 14, 24, 0.18) !important;
}
.content-grid { gap: 12px !important; padding-top: 10px !important; }
.content-grid-row,
#tab3 .content-grid-row,
#tab4 .content-grid-row {
    grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
    gap: 12px !important;
}

.content-item,
#tab3 .content-item,
#tab4 .content-item {
    padding: 10px !important;
    border: 1px solid rgba(255, 255, 255, 0.14) !important;
    border-radius: 19px !important;
    background:
        linear-gradient(145deg, rgba(255, 255, 255, 0.09), rgba(255, 255, 255, 0.035)) !important;
    backdrop-filter: blur(22px) saturate(175%) !important;
    -webkit-backdrop-filter: blur(22px) saturate(175%) !important;
    box-shadow:
        inset 0 1px 0 rgba(255, 255, 255, 0.11),
        0 10px 28px rgba(0, 0, 0, 0.15) !important;
}
.content-item:hover,
#tab3 .content-item:hover,
#tab4 .content-item:hover {
    transform: translateY(-4px) scale(1.012) !important;
    border-color: rgba(169, 226, 255, 0.44) !important;
    background: linear-gradient(145deg, rgba(255, 255, 255, 0.14), rgba(92, 183, 232, 0.07)) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.16), 0 18px 38px rgba(0, 0, 0, 0.24) !important;
}
.content-item img,
.content-item video,
#tab3 .content-item img,
#tab3 .content-item video,
#tab4 .content-item img,
#tab4 .content-item video {
    border-radius: 14px !important;
    background: rgba(0, 8, 15, 0.34) !important;
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.055) !important;
}
.item-text,
#tab3 .item-text,
#tab4 .item-text {
    color: rgba(255, 255, 255, 0.92) !important;
    font-size: 11px !important;
    font-weight: 650 !important;
    line-height: 1.25 !important;
}

.starBtn,
.lnkBtn,
.slot-preview-actions .starBtn,
.slot-preview-actions .lnkBtn {
    border: 1px solid rgba(255, 255, 255, 0.24) !important;
    background: rgba(14, 35, 50, 0.58) !important;
    backdrop-filter: blur(18px) saturate(180%) !important;
    -webkit-backdrop-filter: blur(18px) saturate(180%) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.13), 0 7px 18px rgba(0, 0, 0, 0.22) !important;
}
.lnkBtn,
.slot-preview-actions .lnkBtn {
    background: linear-gradient(180deg, rgba(116, 211, 255, 0.96), rgba(52, 169, 229, 0.94)) !important;
    color: #fff !important;
}

.paginator {
    width: calc(100% - 20px) !important;
    margin: 9px 10px !important;
    padding: 6px !important;
    gap: 7px !important;
    border: 1px solid rgba(255, 255, 255, 0.11) !important;
    border-radius: 17px !important;
    background: rgba(255, 255, 255, 0.045) !important;
    backdrop-filter: blur(20px) saturate(175%) !important;
}
.paginator-btn,
.paginator-page-input {
    height: 38px !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    border-radius: 13px !important;
    background: rgba(255, 255, 255, 0.045) !important;
    color: rgba(255, 255, 255, 0.85) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.055) !important;
}
.paginator-btn.active {
    color: #041521 !important;
    background: linear-gradient(180deg, #9be0ff, #55b9ed) !important;
    border-color: rgba(221, 247, 255, 0.64) !important;
}

.sidebar.is-open .equipped-column {
    overflow: hidden !important;
    border: 1px solid rgba(255, 255, 255, 0.11) !important;
    border-radius: 21px !important;
    background: rgba(255, 255, 255, 0.045) !important;
    backdrop-filter: blur(24px) saturate(175%) !important;
    -webkit-backdrop-filter: blur(24px) saturate(175%) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.075) !important;
}
.sidebar.is-open .equipped-list { padding: 9px !important; gap: 9px !important; }
.equipped-slot,
.collapsed-slot {
    padding: 8px !important;
    border: 1px solid rgba(255, 255, 255, 0.13) !important;
    border-radius: 17px !important;
    background: linear-gradient(145deg, rgba(255, 255, 255, 0.09), rgba(255, 255, 255, 0.035)) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.09), 0 9px 24px rgba(0, 0, 0, 0.16) !important;
}
.equipped-slot:hover,
.collapsed-slot:hover {
    transform: translateY(-2px) !important;
    border-color: rgba(167, 225, 255, 0.42) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.13), 0 13px 28px rgba(0, 0, 0, 0.2) !important;
}
.equipped-slot-preview,
.collapsed-slot-preview {
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    border-radius: 13px !important;
    background: rgba(1, 10, 18, 0.34) !important;
}
.equipped-slot-label,
.collapsed-slot-label { color: rgba(166, 221, 250, 0.88) !important; }
.equipped-reset-wrap,
.collapsed-reset-wrap {
    padding: 9px !important;
    border-top: 1px solid rgba(255, 255, 255, 0.09) !important;
    background: transparent !important;
}
.reset-btn {
    min-height: 40px !important;
    border: 1px solid rgba(255, 123, 146, 0.3) !important;
    border-radius: 14px !important;
    background: rgba(255, 75, 105, 0.13) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.07) !important;
}
.reset-btn:hover {
    transform: translateY(-1px) !important;
    background: rgba(255, 75, 105, 0.22) !important;
    box-shadow: 0 9px 24px rgba(255, 69, 101, 0.16) !important;
}

.sidebar-header {
    height: 190px !important;
    padding: 9px 10px 10px !important;
    border-top: 0 !important;
    background: transparent !important;
}
.sidebar-header a {
    width: min(400px, calc(100% - 20px)) !important;
    height: auto !important;
    aspect-ratio: 200 / 86 !important;
    border: 1px solid rgba(255, 255, 255, 0.11) !important;
    border-radius: 15px !important;
    background: rgba(255, 255, 255, 0.04) !important;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.06) !important;
}
.sidebar-header img {
    object-fit: contain !important;
    object-position: center !important;
}

.content-grid::-webkit-scrollbar,
.tab-content::-webkit-scrollbar,
.equipped-list::-webkit-scrollbar { width: 5px !important; }
.tab-content::-webkit-scrollbar-track,
.equipped-list::-webkit-scrollbar-track { background: transparent !important; }
.tab-content::-webkit-scrollbar-thumb,
.equipped-list::-webkit-scrollbar-thumb {
    border-radius: 999px !important;
    background: rgba(211, 239, 255, 0.28) !important;
}

@media (max-width: 720px) {
    .sidebar {
        --sds-sidebar-open-width: calc(100vw - 8px) !important;
        top: 4px !important;
        right: 4px !important;
        height: calc(100% - 8px) !important;
        padding: 6px !important;
        border-radius: 22px !important;
    }
    .sidebar.is-open .equipped-column { display: none !important; }
    .sidebar.is-open .sidebar-main { width: 100% !important; max-width: 100% !important; }
    .tabs { border-radius: 17px !important; }
    .content-grid-row,
    #tab3 .content-grid-row,
    #tab4 .content-grid-row { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
}

/* Final glass tone: transparent shell with restrained monochrome cards. */
.sidebar {
    background: linear-gradient(145deg, rgba(12, 25, 32, 0.46), rgba(5, 12, 18, 0.38)) !important;
    border-color: rgba(174, 230, 247, 0.44) !important;
    backdrop-filter: blur(34px) saturate(145%) brightness(0.92) !important;
    -webkit-backdrop-filter: blur(34px) saturate(145%) brightness(0.92) !important;
    box-shadow:
        -18px 24px 64px rgba(0, 0, 0, 0.32),
        inset 0 1px 0 rgba(255, 255, 255, 0.13),
        inset 0 0 0 1px rgba(89, 188, 220, 0.035) !important;
}
.sidebar::before {
    opacity: 0.24 !important;
    background: radial-gradient(circle at 8% 3%, rgba(116, 220, 246, 0.16), transparent 30%) !important;
}
.sidebar.is-open .sidebar-main {
    background: rgba(5, 10, 14, 0.16) !important;
    border-color: rgba(255, 255, 255, 0.09) !important;
    backdrop-filter: blur(14px) !important;
    -webkit-backdrop-filter: blur(14px) !important;
}
.tabs,
.paginator,
.sidebar.is-open .equipped-column {
    background: rgba(8, 13, 17, 0.28) !important;
    border-color: rgba(255, 255, 255, 0.14) !important;
    backdrop-filter: blur(24px) saturate(135%) !important;
    -webkit-backdrop-filter: blur(24px) saturate(135%) !important;
}
.tab,
.tg-link-btn,
.sds-lang-switch,
.sds-profile-cost,
.sidebar-search,
.filter-group,
.paginator-btn,
.paginator-page-input {
    background: rgba(11, 15, 19, 0.34) !important;
    border-color: rgba(255, 255, 255, 0.16) !important;
    backdrop-filter: blur(18px) saturate(125%) !important;
    -webkit-backdrop-filter: blur(18px) saturate(125%) !important;
}
.tab:hover,
.tg-link-btn:hover,
.sds-lang-switch:hover,
.action-btn:hover,
.paginator-btn:hover {
    background: rgba(255, 255, 255, 0.085) !important;
    border-color: rgba(213, 240, 248, 0.3) !important;
}
.tab.active,
.action-btn.active,
.paginator-btn.active {
    background: linear-gradient(180deg, rgba(161, 225, 247, 0.94), rgba(76, 180, 222, 0.9)) !important;
    border-color: rgba(224, 248, 255, 0.68) !important;
}
.tab-content {
    background: rgba(3, 7, 10, 0.14) !important;
    border-color: rgba(255, 255, 255, 0.08) !important;
    backdrop-filter: blur(10px) !important;
    -webkit-backdrop-filter: blur(10px) !important;
}
.content-item,
#tab3 .content-item,
#tab4 .content-item,
.equipped-slot,
.collapsed-slot {
    background: linear-gradient(145deg, rgba(16, 17, 19, 0.58), rgba(8, 10, 12, 0.42)) !important;
    border-color: rgba(226, 238, 242, 0.34) !important;
    backdrop-filter: blur(20px) saturate(120%) !important;
    -webkit-backdrop-filter: blur(20px) saturate(120%) !important;
    box-shadow:
        inset 0 1px 0 rgba(255, 255, 255, 0.08),
        0 10px 26px rgba(0, 0, 0, 0.14) !important;
}
.content-item:hover,
#tab3 .content-item:hover,
#tab4 .content-item:hover,
.equipped-slot:hover,
.collapsed-slot:hover {
    background: linear-gradient(145deg, rgba(28, 31, 34, 0.68), rgba(12, 17, 20, 0.5)) !important;
    border-color: rgba(191, 230, 241, 0.55) !important;
}
.equipped-slot-preview,
.collapsed-slot-preview,
.content-item img,
.content-item video {
    background-color: rgba(2, 7, 10, 0.35) !important;
}
.equipped-reset-wrap,
.collapsed-reset-wrap,
.sidebar-header {
    background: transparent !important;
}

</style>`;

const html_part = `

<div class="sidebar">

    <!-- СВЁРНУТЫЙ РЕЖИМ: вертикальный список превью текущих надетых предметов -->
    <div class="collapsed-view" id="collapsedView">
        <!-- Слоты заполняются JS через renderCollapsedView() -->
    </div>

    <div class="collapsed-reset-wrap">
        <button class="reset-btn" id="resetEquippedBtn" title="Вернуть профиль к исходному состоянию">
            <span class="reset-icon-text">↺</span>
            <span>Сброс</span>
        </button>
    </div>

    <!-- РАСКРЫТЫЙ РЕЖИМ: полный интерфейс выбора -->
    <div class="expanded-view">
        <div class="sidebar-main">

            <div class="tabs">
                <a class="tg-link-btn" id="tgLinkBtn" href="https://t.me/SteamMakerBot" target="_blank" rel="noopener noreferrer" title="Telegram SteamShowcase">Telegram</a>
                <button class="tab" data-tab="tab1">
                    <span>Темы профиля</span>
                </button>
                <button class="tab" data-tab="tab2">
                    <span>Рамки профиля</span>
                </button>
                <button class="tab" data-tab="tab3">
                    <span>Анимированные фоны</span>
                </button>
                <button class="tab" data-tab="tab4">
                    <span>Статические фоны</span>
                </button>
                <button class="tab" data-tab="tab5">
                    <span>Аватарки</span>
                </button>
                <button class="sds-lang-switch" id="sdsLangSwitch" type="button" title="Language">
                    <span class="sds-lang-icon">&#127760;</span>
                    <span class="sds-lang-text">RU</span>
                </button>
                <div class="sds-profile-cost" id="sdsProfileCost" title="Profile points cost">
                    <span class="sds-cost-icon">&#9670;</span>
                    <span id="sdsProfileCostValue">0</span>
                </div>
            </div>

            <div class="search-box">
                    <input type="text" class="sidebar-search" placeholder="Поиск по названию игры / предмета...">
            </div>

            <div class="action-row">
                <div class="filter-group" title="Сортировка по дате">
                    <div class="filter-group-label"><span>Дата</span></div>
                    <button class="action-btn" id="dateSortBtnUp" title="Сначала новые">
                        <span class="arrow-icon">▲</span>
                        <span class="filter-text">Новые</span>
                    </button>
                    <button class="action-btn" id="dateSortBtnDown" title="Сначала старые">
                        <span class="arrow-icon">▼</span>
                        <span class="filter-text">Старые</span>
                    </button>
                </div>

                <div class="filter-group" title="Сортировка по популярности">
                    <div class="filter-group-label"><span>Популярность</span></div>
                    <button class="action-btn" id="popularityBtnDown" title="Сначала менее популярные">
                        <span class="arrow-icon">▼</span>
                        <span class="filter-text">Редкие</span>
                    </button>
                    <button class="action-btn active" id="popularityBtnUp" title="Сначала популярные">
                        <span class="arrow-icon">▲</span>
                        <span class="filter-text">Топ</span>
                    </button>
                </div>

                <div class="filter-group fav-group" title="Только избранные">
                    <button class="action-btn" id="favoriteElems" title="Показать только избранные">
                        <span class="star-icon">★</span>
                        <span class="filter-text">Избранное</span>
                    </button>
                </div>
            </div>

            <div class="tab-content" id="tab1">
                <div class="content-grid">
                </div>
            </div>

            <div class="tab-content" id="tab2">
                <div class="content-grid">
                </div>
            </div>

            <div class="tab-content" id="tab3">
                <div class="content-grid">
                </div>
            </div>

            <div class="tab-content" id="tab4">
                <div class="content-grid">
                </div>
            </div>
            <div class="tab-content" id="tab5">
                <div class="content-grid">
                </div>
            </div>
            <div class="paginator">
                <button class="paginator-btn arrow" data-action="prev" id="paginator_btn_prev" disabled>
                    <i>‹</i>
                </button>

                <button class="paginator-btn active" data-page="cur" id="pag_button_cur"></button>
                <input class="paginator-page-input" id="pag_page_input" type="text" inputmode="numeric" pattern="[0-9]*" placeholder="..." title="Введите номер страницы">
                <button class="paginator-btn" data-page="end" id="pag_button_end"></button>

                <button class="paginator-btn arrow" data-action="next" id="paginator_btn_next">
                    <i>›</i>
                </button>
            </div>
        </div>

        <div class="equipped-column">
            <div class="equipped-title">Надетое сейчас</div>
            <div class="equipped-list" id="equippedList">
                <!-- Слоты заполняются JS -->
            </div>
            <div class="equipped-reset-wrap">
                <button class="reset-btn" id="resetEquippedBtnExpanded" title="Вернуть профиль к исходному состоянию">
                    <span class="reset-icon-text">↺</span>
                    <span>Сброс</span>
                </button>
            </div>
        </div>
    </div>

</div>`;

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[char]);
}

const SDS_FETCH_TIMEOUT_MS = 14000;
const SDS_ASSET_PRELOAD_TIMEOUT_MS = 7000;
const SDS_ASSET_PRELOAD_CACHE = new Map();
const SDS_IMAGE_DIMENSION_CACHE = new Map();
const SDS_TRANSPARENT_PIXEL = 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%221%22 height=%221%22%3E%3C/svg%3E';
const SDS_LAZY_LOAD_STAGGER_MS = 85;
let sdsBackgroundApplyToken = 0;

function getCssUrlValue(url) {
    return `url("${String(url).replace(/["\\]/g, '\\$&')}")`;
}

async function fetchWithTimeout(resource, options = {}, timeoutMs = SDS_FETCH_TIMEOUT_MS) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const opts = options || {};

    if (opts.signal) {
        if (opts.signal.aborted) controller.abort();
        else opts.signal.addEventListener('abort', () => controller.abort(), { once: true });
    }

    try {
        return await fetch(resource, { ...opts, signal: controller.signal });
    } finally {
        clearTimeout(timer);
    }
}

function preloadImage(src, timeoutMs = SDS_ASSET_PRELOAD_TIMEOUT_MS) {
    if (!src) return Promise.resolve(false);
    if (SDS_ASSET_PRELOAD_CACHE.has(src)) return SDS_ASSET_PRELOAD_CACHE.get(src);

    const promise = new Promise((resolve) => {
        const img = new Image();
        let done = false;
        const finish = (ok) => {
            if (done) return;
            done = true;
            clearTimeout(timer);
            resolve(ok);
        };
        const timer = setTimeout(() => finish(false), timeoutMs);

        img.decoding = 'async';
        img.onload = () => finish(true);
        img.onerror = () => finish(false);
        img.src = src;
    });

    SDS_ASSET_PRELOAD_CACHE.set(src, promise);
    return promise;
}

function loadImageDimensions(src, timeoutMs = SDS_ASSET_PRELOAD_TIMEOUT_MS) {
    if (!src) return Promise.resolve(null);
    if (SDS_IMAGE_DIMENSION_CACHE.has(src)) return SDS_IMAGE_DIMENSION_CACHE.get(src);

    const promise = new Promise((resolve) => {
        const img = new Image();
        let done = false;
        const finish = (dims) => {
            if (done) return;
            done = true;
            clearTimeout(timer);
            resolve(dims);
        };
        const timer = setTimeout(() => finish(null), timeoutMs);

        img.decoding = 'async';
        img.onload = () => finish({ width: img.naturalWidth || img.width || 0, height: img.naturalHeight || img.height || 0 });
        img.onerror = () => finish(null);
        img.src = src;
    });

    SDS_IMAGE_DIMENSION_CACHE.set(src, promise);
    return promise;
}

function loadLazyMedia(media) {
    if (!media?.dataset) return;
    media.removeAttribute('data-sds-load-queued');
    if (media.dataset.sdsSrc) {
        const src = media.dataset.sdsSrc;
        const finish = () => {
            media.removeAttribute('data-sds-src');
            media.classList.remove('is-loading');
            media.classList.add('is-loaded');
            markLazyMediaReady(media);
        };
        media.classList.add('is-loading');
        media.addEventListener('load', finish, { once: true });
        media.addEventListener('error', finish, { once: true });
        media.src = src;
        if (media.complete) {
            setTimeout(finish, 0);
        }
    }
    if (media.dataset.sdsPoster) {
        media.poster = media.dataset.sdsPoster;
        media.removeAttribute('data-sds-poster');
        markLazyMediaReady(media);
    }
}

function markLazyMediaReady(media) {
    const item = media.closest?.('.content-item');
    if (!item) return;

    if (!media.classList.contains('animPart') || !item.querySelector('.animPrev[data-sds-src]')) {
        item.classList.remove('is-media-pending');
        item.classList.add('is-media-ready');
    }

    if (!item.querySelector('.sds-lazy-media[data-sds-src], video[data-sds-poster]')) {
        item.classList.remove('is-media-pending');
        item.classList.add('is-media-ready');
    }
}

function hydrateHoverMedia(itemNode) {
    itemNode?.querySelectorAll?.('.animPart').forEach((media) => loadLazyMedia(media));
}

function playHoverVideo(itemNode) {
    hydrateHoverMedia(itemNode);
    const video = itemNode?.querySelector?.('video.animPart');
    if (!video) return;

    const playIfHovered = () => {
        if (!itemNode.matches(':hover')) return;
        video.play?.().catch(() => {});
    };

    if (video.readyState >= 2) {
        playIfHovered();
        return;
    }

    if (video.dataset.sdsVideoLoading !== '1') {
        video.dataset.sdsVideoLoading = '1';
        video.addEventListener('loadeddata', () => {
            video.dataset.sdsVideoReady = '1';
            playIfHovered();
        }, { once: true });
        video.load?.();
    }
}

function pauseHoverVideo(itemNode) {
    const video = itemNode?.querySelector?.('video.animPart');
    if (!video) return;
    video.pause?.();
}

function getLazyScrollRoot(root) {
    if (!root?.closest && !root?.classList) return null;
    if (root.classList?.contains('tab-content')) return root;
    return root.closest?.('.tab-content') || null;
}

function isMediaNearScrollViewport(media, scrollRoot) {
    const rect = media.getBoundingClientRect();
    const rootRect = scrollRoot
        ? scrollRoot.getBoundingClientRect()
        : { top: 0, bottom: window.innerHeight };
    return rect.top < rootRect.bottom + 180 && rect.bottom > rootRect.top - 120;
}

function queueLazyMediaLoad(media, delay = 0) {
    if (!media?.dataset || media.dataset.sdsLoadQueued === '1') return;
    media.dataset.sdsLoadQueued = '1';
    window.setTimeout(() => {
        loadLazyMedia(media);
    }, delay);
}

function hydrateLazyMedia(root) {
    const mediaItems = root?.querySelectorAll?.('[data-sds-src]');
    if (!mediaItems?.length) return;

    const scrollRoot = getLazyScrollRoot(root);
    let immediateIndex = 0;
    mediaItems.forEach((media) => {
        if (isMediaNearScrollViewport(media, scrollRoot)) {
            queueLazyMediaLoad(media, immediateIndex * SDS_LAZY_LOAD_STAGGER_MS);
            immediateIndex += 1;
        }
    });
}

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function getLazyImageMarkup(src, className = '') {
    const classes = ['sds-lazy-media', className].filter(Boolean).join(' ');
    const classAttr = classes ? ` class="${escapeHtml(classes)}"` : '';
    return `<img${classAttr} src="${SDS_TRANSPARENT_PIXEL}" data-sds-src="${escapeHtml(src)}" loading="lazy" decoding="async">`;
}

function getStarIcon(isFilled = false) {
    const fill = isFilled ? 'currentColor' : 'none';
    return `<svg class="btn-icon star-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.2l2.76 5.59 6.17.9-4.47 4.35 1.05 6.14L12 17.28l-5.51 2.9 1.05-6.14-4.47-4.35 6.17-.9L12 3.2z" fill="${fill}" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>`;
}

function getExternalIcon() {
    return `<svg class="btn-icon external-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17 17 7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><path d="M9 7h8v8" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
}

function isAbsoluteAssetUrl(value) {
    return typeof value === 'string' && /^(https?:|data:|blob:)/i.test(value);
}

function getItemData(item) {
    return item?.community_item_data || item || {};
}

function getProfileAssetUrl(appid, asset) {
    if (!asset) return '';
    if (isAbsoluteAssetUrl(asset)) return asset;
    if (!appid || appid === 'custom') return asset;
    return stemLnksEnt.getProfileLnk(appid, asset);
}

function getAvatarAssetUrl(appid, asset) {
    if (!asset) return '';
    if (isAbsoluteAssetUrl(asset)) return asset;
    if (!appid || appid === 'custom') return asset;
    return stemLnksEnt.getAvatarLnk(appid, asset);
}

function getVideoMimeType(videoUrl) {
    return /\.mp4(?:$|\?)/i.test(videoUrl || '') ? 'video/mp4' : 'video/webm';
}

function getAvatarPosterUrl(item) {
    return getAvatarPosterUrls(item)[0] || '';
}

function getAvatarPosterUrls(item) {
    const data = getItemData(item);
    const appid = item?.appid;
    const assets = [
        item?.preview_src,
        data.item_image_small,
        item?.item_image_small,
        data.item_image_large,
        item?.item_image_large
    ].filter(Boolean);

    const urls = [];
    assets.forEach((asset) => {
        if (isAbsoluteAssetUrl(asset)) {
            urls.push(asset);
            return;
        }
        if (!appid || appid === 'custom' || appid === 'current') {
            urls.push(asset);
            return;
        }
        urls.push(
            stemLnksEnt.getProfileLnk(appid, asset),
            stemLnksEnt.getAvatarLnk(appid, asset),
            stemLnksEnt.getPreviewLnk(appid, asset)
        );
    });

    return [...new Set(urls.filter(Boolean))];
}

function getAvatarVideoUrls(item) {
    const data = getItemData(item);
    const domVideos = Array.isArray(item?.sds_avatar_video_urls) ? item.sds_avatar_video_urls : [];
    const video = data.item_movie_webm || data.item_movie_mp4 || data.item_movie || item?.item_movie_webm || item?.item_movie_mp4 || item?.item_movie;
    if (!video) return [...new Set(domVideos.filter(Boolean))];
    if (isAbsoluteAssetUrl(video)) return [...new Set([...domVideos, video].filter(Boolean))];
    return [...new Set([
        ...domVideos,
        getAvatarAssetUrl(item?.appid, video),
        getProfileAssetUrl(item?.appid, video)
    ].filter(Boolean))];
}

function createFavoriteButton(tabId, item) {
    if (!item?.defid || item.custom_avatar || item.synthetic_theme_item || item.dom_avatar) return null;
    const itemDefId = `${item.defid}`;
    const isFavorite = (storedTabData[tabId].favDefId || []).map(String).includes(itemDefId);
    const starBtn = document.createElement('button');
    starBtn.type = 'button';
    starBtn.className = 'starBtn';
    if (isFavorite) starBtn.classList.add('is-favorite');
    starBtn.id = itemDefId;
    starBtn.innerHTML = getStarIcon(isFavorite);
    starBtn.title = isFavorite ? 'Remove from favorites' : 'Add to favorites';
    starBtn.setAttribute('aria-label', starBtn.title);
    starBtn.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopImmediatePropagation();
        event.stopPropagation();
        const nextFavorite = !starBtn.classList.contains('is-favorite');
        starBtn.classList.toggle('is-favorite', nextFavorite);
        starBtn.innerHTML = getStarIcon(nextFavorite);
        starBtn.title = nextFavorite ? 'Remove from favorites' : 'Add to favorites';
        starBtn.setAttribute('aria-label', starBtn.title);
        if (nextFavorite) {
            addToArrayInStorage(`fav${tabId}`, itemDefId);
            if (!storedTabData[tabId].favDefId.map(String).includes(itemDefId)) {
                storedTabData[tabId].favDefId.push(itemDefId);
            }
        } else {
            removeFromArrayInStorage(`fav${tabId}`, itemDefId);
            storedTabData[tabId].favDefId = storedTabData[tabId].favDefId.map(String).filter(defId => defId !== itemDefId);
        }
    }, { capture: true });
    return starBtn;
}

function createShopButton(item) {
    if (!item?.appid || !item?.defid || item.custom_avatar || item.synthetic_theme_item || item.dom_avatar) return null;
    const lnkBtn = document.createElement('button');
    lnkBtn.type = 'button';
    lnkBtn.className = 'lnkBtn';
    lnkBtn.innerHTML = getExternalIcon();
    lnkBtn.title = 'Open in points shop';
    lnkBtn.setAttribute('aria-label', lnkBtn.title);
    lnkBtn.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopImmediatePropagation();
        event.stopPropagation();
        window.open(stemLnksEnt.getShopLnk(item.appid, item.defid), '_blank', 'noopener,noreferrer');
    }, { capture: true });
    return lnkBtn;
}

function appendEquippedActionButtons(container, tabId, item) {
    if (!container || !item) return;
    const starBtn = createFavoriteButton(tabId, item);
    const lnkBtn = createShopButton(item);
    if (!starBtn && !lnkBtn) return;
    const row = document.createElement('div');
    row.className = 'slot-preview-actions';
    if (starBtn) row.appendChild(starBtn);
    if (lnkBtn) row.appendChild(lnkBtn);
    container.appendChild(row);
}

function addToArrayInStorage(key, newItem) {
    const prevArray = getArrayFromStorage(key) || [];
    const nextArray = [...new Set([...prevArray.map(String), String(newItem)])];
    localStorage.setItem(key, JSON.stringify(nextArray));
}

function removeFromArrayInStorage(key, delItem) {
    const prevArray = getArrayFromStorage(key);
    if (prevArray) {
        localStorage.setItem(key, JSON.stringify(prevArray.map(String).filter(item => item !== String(delItem))));
    }
}

function getArrayFromStorage(key) {
    const data = localStorage.getItem(key);
    if (data) {
        try {
            return JSON.parse(data);
        } catch(e) {
            console.error('Ошибка парсинга:', e);
            return null;
        }
    }
    return null;
}

class tabData {
    itemData = [];
    currentItem = null;
    maxItemsCnt = 0;
    currentPage = 0;
    next_cursor = null;
    is_fetching = false;
    loadingPromise = null;
    prefetchTimer = null;
    fetchCountOverride = null;
    largeFetchFailed = false;
    is_nothing_found = false;
    search_word = "";
    querySortType = null;
    favDefId = [];
    revision = 0;
    renderKey = "";
    clear(){
        this.revision += 1;
        this.currentPage = 0;
        this.is_nothing_found = false;
        this.search_word = "";
        this.querySortType = null;
        this.next_cursor = null;
        this.loadingPromise = null;
        this.fetchCountOverride = null;
        this.largeFetchFailed = false;
        if (this.prefetchTimer) {
            clearTimeout(this.prefetchTimer);
        }
        this.prefetchTimer = null;
        this.maxItemsCnt = 0;
        this.itemData = [];
        this.favDefId = []
        this.renderKey = "";
    }
}

const defaultAva = 'https://avatars.fastly.steamstatic.com/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg';

let cnt_per_page = 30;
const SDS_DEFAULT_FETCH_COUNT = 60;
const SDS_PREFETCH_PAGE_OFFSET = 1;

class stemLnks{
    previewLnk = 'https://community.fastly.steamstatic.com/economy/profilebackground/items/';
    shopLnk = 'https://store.steampowered.com/points/shop/app/';
    profileLnk = 'https://shared.fastly.steamstatic.com/community_assets/images/items/';
    avatLnk = 'https://avatars.fastly.steamstatic.com/community_assets/images/items/';
    getShopLnk(appid, defid){
        return `${this.shopLnk}${appid}/reward/${defid}`; 
    }
    getProfileLnk(appid, data){
        return `${this.profileLnk}${appid}/${data}`;
    }
    getPreviewLnk(appid, data){
        return `${this.previewLnk}${appid}/${data}`;
    }
    getAvatarLnk(appid, data){
        return `${this.avatLnk}${appid}/${data}`;
    }
}

let stemLnksEnt = new stemLnks();

let storedTabData = {
    'tab1': new tabData(),
    'tab2': new tabData(),
    'tab3': new tabData(),
    'tab4': new tabData(),
    'tab5': new tabData(),
}

function loadSidebarViewState() {
    try {
        const parsed = JSON.parse(localStorage.getItem('sds_sidebar_view_state') || '{}');
        return {
            activeTabId: parsed.activeTabId || 'tab1',
            scrollByTab: parsed.scrollByTab || {},
            pageByTab: parsed.pageByTab || {}
        };
    } catch (error) {
        return { activeTabId: 'tab1', scrollByTab: {}, pageByTab: {} };
    }
}

let sidebarViewState = loadSidebarViewState();

function saveSidebarViewState() {
    try {
        localStorage.setItem('sds_sidebar_view_state', JSON.stringify(sidebarViewState));
    } catch (error) {}
}

function restoreTabScrollAfterRender(tabId, scrollTop = 0) {
    const content = document.getElementById(tabId);
    if (!content) return;

    const targetScroll = Math.max(0, Number(scrollTop) || 0);
    requestAnimationFrame(() => {
        content.scrollTop = targetScroll;
        hydrateLazyMedia(content);
    });
}

function rememberSidebarState() {
    const activeContent = document.querySelector('.tab-content.active');
    if (activeContent) {
        sidebarViewState.activeTabId = activeContent.id;
        sidebarViewState.scrollByTab[activeContent.id] = activeContent.scrollTop || 0;
    }

    Object.entries(storedTabData).forEach(([tabId, tabState]) => {
        sidebarViewState.pageByTab[tabId] = tabState.currentPage || 0;
    });

    saveSidebarViewState();
}

function restoreSidebarState(tabId = sidebarViewState.activeTabId) {
    Object.entries(sidebarViewState.pageByTab || {}).forEach(([stateTabId, page]) => {
        if (storedTabData[stateTabId] && Number.isFinite(Number(page))) {
            storedTabData[stateTabId].currentPage = Number(page);
        }
    });

    const targetTabId = tabId || sidebarViewState.activeTabId || 'tab1';
    const scrollTop = sidebarViewState.scrollByTab?.[targetTabId] || 0;
    const activatedTabId = activateTab(targetTabId, false, { restoreScroll: scrollTop }) || targetTabId;
    if (activatedTabId !== targetTabId) {
        restoreTabScrollAfterRender(activatedTabId, sidebarViewState.scrollByTab?.[activatedTabId] || 0);
    }
}

function getTabRenderKey(tabId) {
    const tabState = storedTabData[tabId];
    if (!tabState) return '';
    const favoriteKey = (tabState.querySortType === 5 || sortType === 5)
        ? [...tabState.favDefId].map(String).sort().join(',')
        : '';
    return [
        tabState.revision,
        tabState.currentPage || 0,
        tabState.search_word || '',
        tabState.querySortType ?? sortType,
        favoriteKey,
        sidebarLang
    ].join('|');
}

function hasRenderedTabContent(tabId) {
    const grid = document.getElementById(tabId)?.querySelector('.content-grid');
    if (!grid || grid.querySelector('.grid-loader')) return false;
    return !!grid.querySelector('.content-grid-row, .empty-state');
}

const DEFAULT_SORT_TYPE = 3;
const DEFAULT_SORT_BUTTON_ID = 'popularityBtnUp';
let sortType = DEFAULT_SORT_TYPE;
const CUSTOM_URL_PARAMS = ['frameST', 'bgAnimST', 'bgStST', 'ava', 'theme', 'previewprofile', 'appid', 'itemtype'];
const THEME_OVERRIDE_PARAMS = ['frameST', 'bgAnimST', 'bgStST', 'ava'];
const CUSTOM_AVATAR_DEFID = 'custom_avatar_upload';

function removeCustomUrlParams(url) {
    CUSTOM_URL_PARAMS.forEach(param => url.searchParams.delete(param));
    return url;
}

function removeThemeOverrideParams(url) {
    THEME_OVERRIDE_PARAMS.forEach(param => url.searchParams.delete(param));
    return url;
}

function getCleanProfileUrl() {
    return removeCustomUrlParams(new URL(window.location.href)).href;
}

function syncBrowserUrlToCleanProfile() {
    const cleanUrl = removeCustomUrlParams(new URL(window.location.href));
    window.history.replaceState({}, '', cleanUrl.pathname + (cleanUrl.search || '') + (cleanUrl.hash || ''));
}

function buildThemePreviewUrl(appId, defId, itemType = null) {
    const previewUrl = removeCustomUrlParams(new URL(window.location.href));
    previewUrl.searchParams.set("previewprofile", "1");
    previewUrl.searchParams.set("appid", appId);
    if (itemType !== undefined && itemType !== null && itemType !== 'undefined' && itemType !== '') {
        previewUrl.searchParams.set("itemtype", itemType);
    }
    previewUrl.searchParams.set("theme", defId);
    return previewUrl.href;
}

function getThemeItemType(item) {
    return item?.itemtype || item?.community_item_type || item?.community_item_data?.item_type || null;
}

function createEmptySnapshotItems() {
    return {
        tab1: null,
        tab2: null,
        tab3: null,
        tab4: null,
        tab5: null
    };
}

function createEmptySnapshotDom() {
    return {
        bodyClass: null,
        htmlClass: null,
        templateContentHTML: null,
        profilePageHTML: null,
        backgroundHolderHTML: null,
        backgroundImage: null,
        animatedBgHTML: null,
        frameSrcset: null,
        avatarSrcset: null,
        bioContent: null
    };
}

function resetInitialSnapshotMemory() {
    initialSnapshot = {
        captured: false,
        items: createEmptySnapshotItems(),
        dom: createEmptySnapshotDom(),
        url: null
    };
}

// === Снимок исходного состояния профиля (для кнопки Сброс) ===
// Заполняется ОДИН раз при загрузке страницы — до того как пользователь что-то изменит
let initialSnapshot = {
    captured: false,
    items: {              // Исходные надетые предметы по вкладкам (как пришли с Steam)
        tab1: null,       // Тема
        tab2: null,       // Рамка
        tab3: null,       // Анимированный фон
        tab4: null,       // Статический фон
        tab5: null        // Аватар
    },
    dom: {                // Резервные копии исходного DOM (на случай если предмет не из API)
        bodyClass: null,
        htmlClass: null,
        templateContentHTML: null,
        profilePageHTML: null,
        backgroundHolderHTML: null,
        backgroundImage: null,
        animatedBgHTML: null,
        frameSrcset: null,
        avatarSrcset: null,
        bioContent: null
    },
    url: null             // Исходный URL без наших параметров
};

// Метаданные слотов для правой колонки (иконки — Unicode, чтобы не зависеть от FontAwesome)
const SLOT_META = {
    tab1: { label: 'Тема',              wide: true  },
    tab2: { label: 'Рамка',             wide: false },
    tab3: { label: 'Анимир. фон',       wide: true  },
    tab4: { label: 'Статич. фон',       wide: true  },
    tab5: { label: 'Аватар',            wide: false }
};

const SDS_I18N = {
    ru: {
        tab1: 'Темы профиля',
        tab2: 'Рамки профиля',
        tab3: 'Анимированные фоны',
        tab4: 'Статические фоны',
        tab5: 'Аватарки',
        search: 'Поиск по названию игры / предмета...',
        date: 'Дата',
        newest: 'Новые',
        oldest: 'Старые',
        popularity: 'Популярность',
        rare: 'Редкие',
        top: 'Топ',
        favorites: 'Избранное',
        equippedTitle: 'Надето сейчас',
        reset: 'Сброс',
        slotTheme: 'Тема',
        slotFrame: 'Рамка',
        slotAnimBg: 'Анимир. фон',
        slotStaticBg: 'Статич. фон',
        slotAvatar: 'Аватар',
        notSelected: '— не выбрано —',
        themeFrame: 'Рамка темы',
        themeAvatar: 'Аватар темы',
        themeAnimBg: 'Анимир. фон темы',
        themeStaticBg: 'Статич. фон темы',
        customAvatar: 'Своя аватарка',
        currentAvatar: 'Текущая аватарка',
        loading: 'Загрузка...',
        themeOnly: 'Только тема',
        fullTheme: 'Весь набор',
        themeOnlyTitle: 'Когда включено, применяется только подфон темы без рамки, аватарки и фона'
    },
    en: {
        tab1: 'Profile themes',
        tab2: 'Profile frames',
        tab3: 'Animated backgrounds',
        tab4: 'Static backgrounds',
        tab5: 'Avatars',
        search: 'Search by game / item name...',
        date: 'Date',
        newest: 'Newest',
        oldest: 'Oldest',
        popularity: 'Popularity',
        rare: 'Rare',
        top: 'Top',
        favorites: 'Favorites',
        equippedTitle: 'Equipped now',
        reset: 'Reset',
        slotTheme: 'Theme',
        slotFrame: 'Frame',
        slotAnimBg: 'Anim. bg',
        slotStaticBg: 'Static bg',
        slotAvatar: 'Avatar',
        notSelected: '— not selected —',
        themeFrame: 'Theme frame',
        themeAvatar: 'Theme avatar',
        themeAnimBg: 'Theme anim. bg',
        themeStaticBg: 'Theme static bg',
        customAvatar: 'Custom avatar',
        currentAvatar: 'Current avatar',
        loading: 'Loading...',
        themeOnly: 'Theme only',
        fullTheme: 'Full set',
        themeOnlyTitle: 'When enabled, applies only the theme backdrop without frame, avatar, or background'
    }
};

let sidebarLang = localStorage.getItem('language') || 'ru';
localStorage.removeItem('sds_theme_only_mode');

const SDS_PREVIEW_UI_THEMES = [
    {
        id: 'default',
        name: 'SteamShowcase',
        vars: {
            '--sds-accent': '#66c0f4',
            '--sds-accent-hover': '#8fd3ff',
            '--sds-accent-gradient': 'linear-gradient(135deg, #66c0f4, #3a9fd8)',
            '--sds-accent-gradient-hover': 'linear-gradient(135deg, #8fd3ff, #66c0f4)',
            '--sds-panel-bg': 'linear-gradient(160deg, rgba(7, 17, 28, 0.94), rgba(12, 27, 44, 0.90), rgba(10, 22, 34, 0.92))',
            '--sds-card-bg': 'rgba(16, 36, 56, 0.72)',
            '--sds-card-border': '1px solid rgba(102, 192, 244, 0.16)',
            '--sds-ambient-overlay': 'radial-gradient(circle at 16% 10%, rgba(102,192,244,0.16), transparent 34%), radial-gradient(circle at 88% 82%, rgba(47,127,184,0.14), transparent 32%)'
        }
    }
];

let currentPreviewUITheme = 'default';

function getPreviewSolidThemeVars(themeId) {
    return {
        '--sds-panel-solid': '#0f2033',
        '--sds-side-solid': '#0c1a28',
        '--sds-card-solid': '#173047'
    };

}

function sdsText(key) {
    return (SDS_I18N[sidebarLang] || SDS_I18N.ru)[key] || SDS_I18N.ru[key] || key;
}

function hasLiveChromeRuntime() {
    try {
        return typeof chrome !== 'undefined' && !!chrome.runtime?.id;
    } catch (error) {
        return false;
    }
}

function safeChromeStorageSet(values) {
    try {
        if (!hasLiveChromeRuntime() || !chrome.storage?.local) return;
        chrome.storage.local.set(values, () => {
            try {
                void chrome.runtime?.lastError;
            } catch (error) {}
        });
    } catch (error) {
        console.debug('[SDS] Chrome storage set skipped:', error);
    }
}

function safeChromeStorageGet(defaults, callback) {
    try {
        if (!hasLiveChromeRuntime() || !chrome.storage?.local) {
            callback(defaults);
            return;
        }
        chrome.storage.local.get(defaults, callback);
    } catch (error) {
        console.debug('[SDS] Chrome storage get skipped:', error);
        callback(defaults);
    }
}

function safeChromeStorageOnChanged(handler) {
    try {
        if (!hasLiveChromeRuntime() || !chrome.storage?.onChanged) return;
        chrome.storage.onChanged.addListener(handler);
    } catch (error) {
        console.debug('[SDS] Chrome storage listener skipped:', error);
    }
}

function applyPreviewUITheme(themeId = currentPreviewUITheme, options = {}) {
    const sidebar = document.querySelector('.sidebar');
    const theme = SDS_PREVIEW_UI_THEMES[0];
    currentPreviewUITheme = 'default';
    localStorage.setItem('uiTheme', 'default');
    if (options.persist !== false) {
        safeChromeStorageSet({ uiTheme: 'default' });
    }

    if (sidebar) {
        Object.entries(theme.vars).forEach(([key, value]) => {
            sidebar.style.setProperty(key, value);
        });
        Object.entries(getPreviewSolidThemeVars(theme.id)).forEach(([key, value]) => {
            sidebar.style.setProperty(key, value);
        });
    }

    const themeButton = document.getElementById('sdsThemeSwitch');
    if (themeButton) {
        themeButton.title = theme.name;
        const text = themeButton.querySelector('.sds-theme-text');
        if (text) text.textContent = sidebarLang === 'ru' ? 'Тема' : 'Theme';
    }
}

function switchPreviewUITheme() {
    applyPreviewUITheme('default');
}

const SLOT_DEFAULT_POINT_COSTS = {
    tab1: 5000,
    tab2: 2000,
    tab3: 2000,
    tab4: 500,
    tab5: 3000
};
const SDS_PATTERN_STATIC_BG_COST = 1000;
const SDS_RELIABLE_POINT_COST_KEYS = [
    'point_cost',
    'point_cost_discounted',
    'points_cost',
    'points_price',
    'loyalty_point_cost'
];

function parsePointCostValue(value) {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value !== 'string') return null;
    const cleaned = value.replace(/[^\d]/g, '');
    if (!cleaned) return null;
    const parsed = parseInt(cleaned, 10);
    return Number.isFinite(parsed) ? parsed : null;
}

function findPointCost(data) {
    if (!data || typeof data !== 'object') return null;

    const directKeys = [
        'point_cost',
        'point_cost_discounted',
        'points_cost',
        'points_price',
        'loyalty_point_cost',
        'cost',
        'price',
        'points'
    ];

    for (const key of directKeys) {
        if (!Object.prototype.hasOwnProperty.call(data, key)) continue;
        const value = parsePointCostValue(data[key]);
        if (value !== null && value > 0) return value;
    }

    const nestedKeys = ['community_item_data', '_raw', 'reward', 'item', 'store_item'];
    for (const key of nestedKeys) {
        if (data[key] && data[key] !== data) {
            const value = findPointCost(data[key]);
            if (value !== null) return value;
        }
    }

    return null;
}

function findReliablePointCost(data) {
    if (!data || typeof data !== 'object') return null;

    for (const key of SDS_RELIABLE_POINT_COST_KEYS) {
        if (!Object.prototype.hasOwnProperty.call(data, key)) continue;
        const value = parsePointCostValue(data[key]);
        if (value !== null && value > 0) return value;
    }

    const nestedKeys = ['community_item_data', '_raw', 'reward', 'item', 'store_item'];
    for (const key of nestedKeys) {
        if (data[key] && data[key] !== data) {
            const value = findReliablePointCost(data[key]);
            if (value !== null) return value;
        }
    }

    return null;
}

function getItemPointCost(tabId, item) {
    if (!item || item.synthetic_theme_item || item.custom_avatar || item.dom_avatar) return 0;
    const parsedCost = findPointCost(item);
    if (parsedCost !== null) return parsedCost;
    return SLOT_DEFAULT_POINT_COSTS[tabId] || 0;
}

function isSquareLikeMedia(media) {
    const width = media?.naturalWidth || media?.videoWidth || 0;
    const height = media?.naturalHeight || media?.videoHeight || 0;
    if (!width || !height) return null;
    return Math.abs(width - height) / Math.max(width, height) <= 0.08;
}

function isSquareLikeDimensions(dimensions) {
    const width = Number(dimensions?.width) || 0;
    const height = Number(dimensions?.height) || 0;
    if (!width || !height) return null;
    return Math.abs(width - height) / Math.max(width, height) <= 0.08;
}

function isPatternStaticBackgroundItem(item, previewMedia = null) {
    if (!item) return false;
    if (typeof item.sds_static_background_pattern === 'boolean') return item.sds_static_background_pattern;

    const parsedCost = findReliablePointCost(item);
    if (parsedCost !== null) return parsedCost >= SDS_PATTERN_STATIC_BG_COST;

    const isSquarePreview = isSquareLikeMedia(previewMedia);
    return isSquarePreview === true;
}

function markStaticBackgroundKind(sourceItem, sourceRowItem = null, previewMedia = null) {
    if (!sourceItem || typeof sourceItem !== 'object') return sourceItem;
    const marked = { ...sourceItem };
    const reliableCost = findReliablePointCost(sourceRowItem || sourceItem);
    if (reliableCost !== null) {
        marked.sds_static_background_pattern = reliableCost >= SDS_PATTERN_STATIC_BG_COST;
        return marked;
    }

    const isSquarePreview = isSquareLikeMedia(previewMedia);
    if (isSquarePreview !== null) {
        marked.sds_static_background_pattern = isSquarePreview;
    }
    return marked;
}

function shouldRefineStaticBackgroundByImage(sourceItem) {
    return sourceItem
        && typeof sourceItem.sds_static_background_pattern !== 'boolean'
        && findReliablePointCost(sourceItem) === null;
}

function getCurrentProfilePointCost() {
    return ['tab1', 'tab2', 'tab3', 'tab4', 'tab5'].reduce((sum, tabId) => {
        return sum + getItemPointCost(tabId, storedTabData[tabId]?.currentItem);
    }, 0);
}

function updateProfileCost() {
    const valueNode = document.getElementById('sdsProfileCostValue');
    const wrap = document.getElementById('sdsProfileCost');
    if (!valueNode) return;

    const total = getCurrentProfilePointCost();
    valueNode.textContent = `${total.toLocaleString(sidebarLang === 'ru' ? 'ru-RU' : 'en-US')} pts`;
    if (wrap) {
        wrap.title = sidebarLang === 'ru' ? 'Стоимость текущего профиля в очках' : 'Current profile points cost';
    }
}

async function replaceStaticBG(newImg, defID, sourceItem = null, options = {}){
    const applyToken = ++sdsBackgroundApplyToken;
    let pageRespCont = document.getElementById('responsive_page_template_content').getElementsByClassName('profile_page').item(0);
    let videoElem = pageRespCont.getElementsByClassName('profile_animated_background');
    
    if(videoElem.length >0)
        videoElem.item(0).remove();

    clearProfileBackgroundLayout(pageRespCont);
    pageRespCont.classList.add('has_profile_background');

    const previewImg = getItemPreviewUrl(sourceItem);
    const refineBackgroundRepeatFromImage = () => {
        if (!shouldRefineStaticBackgroundByImage(sourceItem)) return;
        loadImageDimensions(newImg).then((dimensions) => {
            if (applyToken !== sdsBackgroundApplyToken) return;
            const isSquareImage = isSquareLikeDimensions(dimensions);
            if (isSquareImage === null) return;
            sourceItem.sds_static_background_pattern = isSquareImage;
            applyStaticProfileBackground(pageRespCont, newImg, sourceItem, { staticBackgroundRepeat: isSquareImage });
        }).catch(() => {});
    };

    if (previewImg) {
        applyStaticProfileBackground(pageRespCont, previewImg, sourceItem, options);
        preloadImage(newImg).finally(() => {
            if (applyToken !== sdsBackgroundApplyToken) return;
            applyStaticProfileBackground(pageRespCont, newImg, sourceItem, options);
            refineBackgroundRepeatFromImage();
        });
    } else {
        applyStaticProfileBackground(pageRespCont, newImg, sourceItem, options);
        refineBackgroundRepeatFromImage();
    }

    storedTabData['tab3'].currentItem = null;
    await setCurrentItem('tab4', sourceItem, options);
    syncBrowserUrlToCleanProfile();
}

async function replaceAnimBG(newVideo, posterLnk, defID, sourceItem = null, options = {}){
    const applyToken = ++sdsBackgroundApplyToken;
    const previewPoster = getItemPreviewUrl(sourceItem) || posterLnk;
    let elmnt = `<div class="profile_animated_background">
                                            <video autoplay="" muted="" loop="" playsinline preload="auto" poster="${previewPoster}" fetchpriority="high"><source src="${newVideo}" type="video/webm"></video>
                                        </div>`
    let pageRespCont = document.getElementById('responsive_page_template_content')?.getElementsByClassName('profile_page')?.item(0);
    if (!pageRespCont || !newVideo) return;
    let videoElem = pageRespCont.getElementsByClassName('profile_animated_background');
    if(videoElem.length > 0){
        videoElem.item(0).remove()
    }

    clearProfileBackgroundLayout(pageRespCont);
    pageRespCont.classList.add('has_profile_background');
    pageRespCont.style.backgroundImage = "";

    pageRespCont.insertAdjacentHTML('afterbegin',elmnt);
    const video = pageRespCont.getElementsByClassName('profile_animated_background').item(0)?.querySelector('video');
    video?.load?.();
    video?.play?.().catch(() => {});
    preloadImage(posterLnk).then(() => {
        if (applyToken !== sdsBackgroundApplyToken) return;
        const activeVideo = pageRespCont.getElementsByClassName('profile_animated_background').item(0)?.querySelector('video');
        if (activeVideo) activeVideo.poster = posterLnk;
    }).catch(() => false);
    
    storedTabData['tab4'].currentItem = null;
    await setCurrentItem('tab3', sourceItem, options);
    syncBrowserUrlToCleanProfile();
}

async function replaceFrame(posterLnk, defID, sourceItem = null, options = {}){

    let elmnt = `<div class="profile_avatar_frame">
								<img src="${posterLnk}">
                            </div>`
    const profileScope = getCurrentProfileScope();
    let frameElement = findProfileFrameElement(profileScope);
    if(frameElement){
        updateFrameElement(frameElement, posterLnk);
        window.requestAnimationFrame(() => updateFrameElement(frameElement, posterLnk));
    }else{
        const avatarHolder = getProfileAvatarHolder(profileScope);
        avatarHolder?.insertAdjacentHTML('afterbegin', elmnt);
        frameElement = findProfileFrameElement(profileScope);
        updateFrameElement(frameElement, posterLnk);
    }

    await setCurrentItem('tab2', sourceItem, options);
    syncBrowserUrlToCleanProfile();
}

async function replaceAvatar(posterLnk, defID, sourceItem = null, options = {}){

    const profileScope = getCurrentProfileScope();
    const avatarPicture = getProfileAvatarPicture(profileScope);
    const avatarTarget = avatarPicture || getProfileAvatarHolder(profileScope);
    const avatarVideo = getAvatarVideoUrls(sourceItem);
    const posterCandidates = sourceItem ? getAvatarPosterUrls(sourceItem) : [];
    const posterUrls = [...new Set([posterLnk, ...posterCandidates].filter(Boolean))];
    const primaryPoster = posterUrls[0] || posterLnk;
    if(avatarTarget){
        updateAvatarMedia(avatarTarget, primaryPoster, avatarVideo, posterUrls);
        window.requestAnimationFrame(() => updateAvatarMedia(avatarTarget, primaryPoster, avatarVideo, posterUrls));
    }

    await setCurrentItem('tab5', sourceItem, options);
    syncBrowserUrlToCleanProfile();
}

function applySteamProfileThemeClass(appId, defId, exactClass = null) {
    const themeClass = exactClass || `GameProfile_${appId}_${defId}_Theme`;
    [document.body, document.documentElement].forEach((element) => {
        if (!element) return;
        [...element.classList]
            .filter(className => /^GameProfile_\d+_\d+_Theme$/.test(className))
            .forEach(className => element.classList.remove(className));
        element.classList.add(themeClass);
    });
}

function syncThemeRootClasses(themeDocument) {
    [
        [document.documentElement, themeDocument.documentElement],
        [document.body, themeDocument.body]
    ].forEach(([currentElement, nextElement]) => {
        if (!currentElement || !nextElement) return;
        currentElement.className = nextElement.className || '';
    });
}

function addThemeStylesFromDocument(themeDocument) {
    const styleNodes = themeDocument.querySelectorAll('style');
    styleNodes.forEach((styleNode, index) => {
        const key = `sds-theme-style-${index}-${styleNode.textContent.length}`;
        if (document.querySelector(`style[data-sds-theme-style="${key}"]`)) return;
        const clone = document.createElement('style');
        clone.setAttribute('data-sds-theme-style', key);
        clone.textContent = styleNode.textContent;
        document.head.appendChild(clone);
    });

    const links = themeDocument.querySelectorAll('link[rel="stylesheet"][href]');
    links.forEach((link) => {
        const href = new URL(link.getAttribute('href'), window.location.href).href;
        if (document.querySelector(`link[data-sds-theme-href="${href}"], link[href="${href}"]`)) return;
        const clone = document.createElement('link');
        clone.rel = 'stylesheet';
        clone.href = href;
        clone.setAttribute('data-sds-theme-href', href);
        document.head.appendChild(clone);
    });
}

function clearInjectedThemeAssets() {
    document.querySelectorAll('style[data-sds-theme-style], link[data-sds-theme-href]').forEach((node) => {
        node.remove();
    });
}

function replaceThemeElementFromDocument(themeDocument, selector) {
    const currentElement = document.querySelector(selector);
    const nextElement = themeDocument.querySelector(selector);
    if (!currentElement || !nextElement) return false;

    currentElement.replaceWith(nextElement.cloneNode(true));
    return true;
}

function syncThemeElementOrRemove(themeDocument, selector) {
    const currentElements = [...document.querySelectorAll(selector)];
    const nextElements = [...themeDocument.querySelectorAll(selector)];

    if (!nextElements.length) {
        currentElements.forEach((element) => element.remove());
        return false;
    }

    if (!currentElements.length) return false;

    currentElements.forEach((element, index) => {
        if (index === 0) {
            element.replaceWith(nextElements[0].cloneNode(true));
        } else {
            element.remove();
        }
    });
    return true;
}

function copyThemeBackdropStyle(currentElement, nextElement) {
    if (!currentElement || !nextElement?.style) return;
    const hasNextInlineStyle = nextElement.hasAttribute('style');

    [
        'background',
        'backgroundImage',
        'backgroundColor',
        'backgroundSize',
        'backgroundPosition',
        'backgroundRepeat',
        'backgroundAttachment'
    ].forEach((propertyName) => {
        const value = nextElement.style[propertyName];
        if (value || hasNextInlineStyle) currentElement.style[propertyName] = value || '';
    });

    [...nextElement.classList]
        .filter(className => /GameProfile_\d+_\d+_Theme|profile_theme|has_profile_background|full_width_background/i.test(className))
        .forEach(className => currentElement.classList.add(className));
}

function syncThemeBackdropStyles(themeDocument) {
    [
        'body',
        '#responsive_page_template_content',
        '#profile_background_holder',
        '#profile_background_holder_content',
        '.profile_background_holder',
        '.profile_background_holder_content',
        '.profile_page',
        '.profile_header_bg',
        '.profile_header',
        '.profile_content',
        '.profile_customization',
        '.profile_leftcol',
        '.profile_rightcol'
    ].forEach((selector) => {
        copyThemeBackdropStyle(document.querySelector(selector), themeDocument.querySelector(selector));
    });
}

function parseSrcsetUrl(srcset) {
    if (!srcset) return '';
    return srcset.split(',')[0].trim().split(/\s+/)[0] || '';
}

function toAbsoluteUrl(value) {
    if (!value) return '';
    try {
        return new URL(value, window.location.href).href;
    } catch (error) {
        return value;
    }
}

function getElementAssetUrl(element) {
    if (!element) return '';
    const srcset = element.getAttribute('srcset');
    const src = parseSrcsetUrl(srcset) || element.getAttribute('src') || element.getAttribute('poster');
    return toAbsoluteUrl(src);
}

function getCssUrl(value) {
    if (!value || value === 'none') return '';
    const match = value.match(/url\(["']?([^"')]+)["']?\)/);
    return match ? toAbsoluteUrl(match[1]) : '';
}

function makeThemeSyntheticItem(slotName, previewSrc, previewMarkup = '') {
    if (!previewSrc && !previewMarkup) return null;
    return {
        synthetic_theme_item: true,
        slot_name: slotName,
        preview_src: previewSrc,
        preview_markup: previewMarkup,
        community_item_data: {
            item_title: slotName,
            item_image_small: previewSrc
        }
    };
}

function getItemPreviewUrl(item) {
    if (!item) return '';
    if (item.preview_src) return item.preview_src;
    const data = item['community_item_data'] || item;
    const previewImage = data['item_image_large'] || data['item_image_small'];
    if (!previewImage || !item['appid']) return '';
    return stemLnksEnt.getPreviewLnk(item['appid'], previewImage);
}

function clearProfileBackgroundLayout(profilePage) {
    if (!profilePage?.style) return;
    [
        'background',
        'backgroundSize',
        'backgroundPosition',
        'backgroundRepeat',
        'backgroundAttachment'
    ].forEach((propertyName) => {
        profilePage.style[propertyName] = '';
    });
}

function setProfileBackgroundProperty(profilePage, propertyName, value, priority = 'important') {
    profilePage.style.setProperty(propertyName, value, priority);
}

function applyStaticProfileBackground(profilePage, imageUrl, sourceItem = null, options = {}) {
    if (!profilePage?.style || !imageUrl) return;
    const shouldRepeat = typeof options.staticBackgroundRepeat === 'boolean'
        ? options.staticBackgroundRepeat
        : isPatternStaticBackgroundItem(sourceItem);

    setProfileBackgroundProperty(profilePage, 'background-image', getCssUrlValue(imageUrl));
    setProfileBackgroundProperty(profilePage, 'background-repeat', shouldRepeat ? 'repeat' : 'no-repeat');
    setProfileBackgroundProperty(profilePage, 'background-size', 'auto');
    setProfileBackgroundProperty(profilePage, 'background-position', 'center top');
    setProfileBackgroundProperty(profilePage, 'background-attachment', 'scroll');
    if (!shouldRepeat) {
        setProfileBackgroundProperty(profilePage, 'background-color', '#000');
    }
}

function findLastAssetUrl(root, selector) {
    const elements = [...(root || document).querySelectorAll(selector)];
    return getElementAssetUrl(elements[elements.length - 1]);
}

function getThemeProfileScope(themeDocument) {
    return themeDocument.querySelector('#responsive_page_template_content .profile_page')
        || themeDocument.querySelector('.profile_page')
        || themeDocument;
}

function getCurrentProfileScope() {
    return document.querySelector('#responsive_page_template_content .profile_page')
        || document.querySelector('.profile_page')
        || document;
}

function getProfileAvatarHolder(root = getCurrentProfileScope()) {
    if (!root?.querySelector) return null;
    return root.querySelector('.profile_header .profile_avatar')
        || root.querySelector('.profile_header_bg .profile_avatar')
        || root.querySelector('.profile_avatar')
        || root.querySelector('.playerAvatarAutoSizeInner')
        || document.querySelector('#responsive_page_template_content .profile_avatar')
        || document.querySelector('#responsive_page_template_content .playerAvatarAutoSizeInner');
}

function getProfileAvatarPicture(root = getCurrentProfileScope()) {
    if (!root?.querySelectorAll) return null;
    const pictures = [
        ...root.querySelectorAll('.playerAvatarAutoSizeInner picture'),
        ...root.querySelectorAll('.profile_avatar picture')
    ].filter((picture) => !picture.closest('.profile_avatar_frame'));
    return pictures[pictures.length - 1] || null;
}

function getProfileAvatarImage(root = getCurrentProfileScope()) {
    if (!root?.querySelectorAll) return null;
    const images = [
        ...root.querySelectorAll('.playerAvatarAutoSizeInner picture img'),
        ...root.querySelectorAll('.playerAvatarAutoSizeInner img'),
        ...root.querySelectorAll('.profile_avatar picture img'),
        ...root.querySelectorAll('.profile_avatar img')
    ].filter((img) => !img.closest('.profile_avatar_frame'));
    return images[images.length - 1] || null;
}

function getProfileAvatarVideo(root = getCurrentProfileScope()) {
    const selectors = [
        '.playerAvatarAutoSizeInner video',
        '.profile_avatar video',
        '#responsive_page_template_content .playerAvatarAutoSizeInner video',
        '#responsive_page_template_content .profile_avatar video'
    ];
    const seen = new Set();
    const videos = [];

    selectors.forEach((selector) => {
        [...(root || document).querySelectorAll(selector)].forEach((video) => {
            if (!video || seen.has(video)) return;
            if (video.closest('.profile_avatar_frame') || video.closest('.sds-profile-avatar-video')) return;
            seen.add(video);
            videos.push(video);
        });
    });

    return videos[videos.length - 1] || null;
}

function getVideoSourceUrls(video) {
    if (!video) return [];
    const urls = [
        video.getAttribute('src'),
        ...[...video.querySelectorAll('source')].map((source) => source.getAttribute('src'))
    ].map(toAbsoluteUrl).filter(Boolean);
    return [...new Set(urls)];
}

function getCurrentAvatarDomMedia() {
    const scope = getCurrentProfileScope();
    const avatarVideo = getProfileAvatarVideo(scope);
    const avatarImg = getProfileAvatarImage(scope);
    const videoUrls = getVideoSourceUrls(avatarVideo);
    const posterUrl = toAbsoluteUrl(avatarVideo?.getAttribute('poster'))
        || getElementAssetUrl(avatarImg)
        || getElementAssetUrl(avatarVideo);

    if (!posterUrl && !videoUrls.length) return null;

    const videoMarkup = videoUrls.length
        ? `<video autoplay muted loop playsinline preload="auto" poster="${escapeHTML(posterUrl || SDS_TRANSPARENT_PIXEL)}">${videoUrls.map((url) => `<source src="${escapeHTML(url)}" type="${getVideoMimeType(url)}">`).join('')}</video>`
        : '';

    return {
        posterUrl,
        videoUrls,
        previewMarkup: videoMarkup || (posterUrl ? `<img src="${escapeHTML(posterUrl)}" loading="lazy" alt="">` : '')
    };
}

function createDomAvatarItem(media) {
    const poster = media?.posterUrl || '';
    return {
        dom_avatar: true,
        appid: 'current',
        defid: 'current_profile_avatar',
        preview_src: poster,
        preview_markup: media?.previewMarkup || '',
        sds_avatar_video_urls: media?.videoUrls || [],
        community_item_data: {
            item_title: sdsText('currentAvatar'),
            item_image_small: poster,
            item_image_large: poster
        }
    };
}

function ensureCurrentAvatarFromDom(options = {}) {
    const { preferDomWhenMissing = true, enrichExisting = true } = options;
    const media = getCurrentAvatarDomMedia();
    if (!media) return false;

    const currentAvatar = storedTabData?.tab5?.currentItem;
    if (currentAvatar && enrichExisting) {
        if (media.videoUrls.length && !getAvatarVideoUrls(currentAvatar).length) {
            currentAvatar.sds_avatar_video_urls = media.videoUrls;
        }
        if (!currentAvatar.preview_src && media.posterUrl) {
            currentAvatar.preview_src = media.posterUrl;
        }
        if (!currentAvatar.preview_markup && media.previewMarkup) {
            currentAvatar.preview_markup = media.previewMarkup;
        }
        return true;
    }

    if (!currentAvatar && preferDomWhenMissing) {
        storedTabData.tab5.currentItem = createDomAvatarItem(media);
        return true;
    }

    return false;
}

function updateFrameElement(frameElement, frameUrl) {
    if (!frameElement || !frameUrl) return false;
    const media = frameElement.querySelectorAll('source, img');
    if (!media.length) {
        frameElement.innerHTML = `<img src="${escapeHtml(frameUrl)}" alt="">`;
        return true;
    }
    media.forEach((element) => {
        if ('srcset' in element) element.srcset = frameUrl;
        if ('src' in element) element.src = frameUrl;
    });
    return true;
}

function attachAvatarImageFallback(img, urls) {
    if (!img || !urls?.length) return;
    img.dataset.sdsAvatarFallbackUrls = JSON.stringify(urls);
    img.dataset.sdsAvatarFallbackIndex = '0';
    img.onerror = () => {
        let fallbackUrls = [];
        try {
            fallbackUrls = JSON.parse(img.dataset.sdsAvatarFallbackUrls || '[]');
        } catch (error) {}
        const nextIndex = (Number(img.dataset.sdsAvatarFallbackIndex) || 0) + 1;
        if (!fallbackUrls[nextIndex]) return;
        img.dataset.sdsAvatarFallbackIndex = String(nextIndex);
        img.src = fallbackUrls[nextIndex];
    };
}

function updateAvatarMedia(root, avatarUrl, videoUrls = [], avatarFallbackUrls = []) {
    const videos = Array.isArray(videoUrls) ? videoUrls.filter(Boolean) : [videoUrls].filter(Boolean);
    const fallbackUrls = [...new Set([avatarUrl, ...avatarFallbackUrls].filter(Boolean))];
    const primaryAvatarUrl = fallbackUrls[0] || avatarUrl;
    if (!root || (!avatarUrl && !videos.length)) return false;
    const holder = root.matches?.('.profile_avatar, .playerAvatarAutoSizeInner')
        ? root
        : root.closest?.('.profile_avatar, .playerAvatarAutoSizeInner');
    const existingVideo = holder?.querySelector?.('.sds-profile-avatar-video');

    if (videos.length && holder) {
        holder.classList.add('sds-has-animated-avatar');
        if (getComputedStyle(holder).position === 'static') {
            holder.style.position = 'relative';
        }
        let video = existingVideo;
        if (!video) {
            video = document.createElement('video');
            video.className = 'sds-profile-avatar-video';
            video.autoplay = true;
            video.muted = true;
            video.loop = true;
            video.playsInline = true;
            video.preload = 'auto';
            video.setAttribute('aria-hidden', 'true');
            holder.appendChild(video);
        }
        const currentSources = [...video.querySelectorAll('source')].map((source) => source.getAttribute('src')).join('|');
        if (currentSources !== videos.join('|')) {
            video.innerHTML = '';
            videos.forEach((url) => {
                const source = document.createElement('source');
                source.src = url;
                source.type = getVideoMimeType(url);
                video.appendChild(source);
            });
            video.load?.();
        }
        video.poster = primaryAvatarUrl || SDS_TRANSPARENT_PIXEL;
        video.play?.().catch(() => {});
    } else if (existingVideo) {
        existingVideo.remove();
        holder?.classList.remove('sds-has-animated-avatar');
    }

    const searchRoots = [root, holder].filter(Boolean);
    const seen = new Set();
    const media = [
        ...searchRoots.flatMap((mediaRoot) => [
            ...(mediaRoot.matches?.('source, img') ? [mediaRoot] : []),
            ...(mediaRoot.querySelectorAll?.('source, img') || [])
        ])
    ].filter((element) => {
        if (!element || seen.has(element)) return false;
        seen.add(element);
        return !element.closest('.profile_avatar_frame') && !element.closest('.sds-profile-avatar-video');
    });
    if (!media.length && holder && primaryAvatarUrl) {
        const img = document.createElement('img');
        img.alt = '';
        holder.appendChild(img);
        media.push(img);
    }
    if (!media.length) return !!videos.length;
    media.forEach((element) => {
        if ('srcset' in element) element.srcset = primaryAvatarUrl;
        if ('src' in element) {
            attachAvatarImageFallback(element, fallbackUrls);
            element.src = primaryAvatarUrl;
        }
    });
    return true;
}

function findProfileFrameElement(root = document) {
    if (!root?.querySelector) return null;
    return root.querySelector('.profile_header .profile_avatar_frame')
        || root.querySelector('.profile_header_bg .profile_avatar_frame')
        || root.querySelector('.profile_avatar .profile_avatar_frame')
        || root.querySelector('.profile_avatar_frame');
}

function getFrameAssetFromElement(frameElement) {
    return getElementAssetUrl(frameElement?.querySelector('img'))
        || getElementAssetUrl(frameElement?.querySelector('source'));
}

function getPreviewMarkupFromElement(element) {
    if (!element) return '';
    const clone = element.cloneNode(true);
    clone.querySelectorAll('script').forEach((node) => node.remove());
    return clone.outerHTML;
}

function isStandardSteamThemeItem(item) {
    if (!item) return false;
    const defId = `${item.defid || ''}`;
    const name = `${item.storeName || item.community_item_data?.item_title || ''}`.trim().toLowerCase();
    return item.default_steam_theme === true
        || defId === 'steam_default_theme'
        || name === 'стандартная steam'
        || name === 'default steam';
}

function captureProfileBioContent() {
    const scope = getCurrentProfileScope();
    if (!scope?.querySelector) return [];

    const headerSummary = scope.querySelector('.profile_header_summary');
    if (headerSummary) {
        return [{
            selector: '.profile_header_summary',
            className: headerSummary.className,
            style: headerSummary.getAttribute('style'),
            outerHTML: headerSummary.outerHTML,
            html: headerSummary.innerHTML
        }];
    }

    return ['.profile_summary', '.profile_summary_footer'].map((selector) => {
        const element = scope.querySelector(selector);
        if (!element) return null;
        return {
            selector,
            className: element.className,
            style: element.getAttribute('style'),
            outerHTML: element.outerHTML,
            html: element.innerHTML
        };
    }).filter(Boolean);
}

function restoreProfileBioContent(snapshot) {
    if (!snapshot?.length) return;
    const scope = getCurrentProfileScope();
    if (!scope?.querySelector) return;

    snapshot.forEach((entry) => {
        let element = scope.querySelector(entry.selector);
        if (!element && entry.outerHTML) {
            const holder = document.createElement('div');
            holder.innerHTML = entry.outerHTML;
            const restoredElement = holder.firstElementChild;
            const container = scope.querySelector('.profile_header_content')
                || scope.querySelector('.profile_header')
                || scope;
            if (restoredElement && container?.appendChild) {
                const beforeNode = container.querySelector?.('.profile_header_actions, .profile_header_badgeinfo');
                container.insertBefore(restoredElement, beforeNode || null);
                element = restoredElement;
            }
        }
        if (!element) return;
        element.className = entry.className || '';
        if (entry.style === null || entry.style === undefined) {
            element.removeAttribute('style');
        } else {
            element.setAttribute('style', entry.style);
        }
        element.innerHTML = entry.html || '';
    });
}

function applyThemePackageState(themeDocument, sourceItem = null) {
    if (sourceItem) {
        storedTabData['tab1'].currentItem = sourceItem;
    }

    const profileScope = getThemeProfileScope(themeDocument);
    const currentProfileScope = getCurrentProfileScope();
    const frameElement = findProfileFrameElement(currentProfileScope) || findProfileFrameElement(profileScope);
    const avatarUrl = findLastAssetUrl(currentProfileScope, '.playerAvatarAutoSizeInner picture img, .playerAvatarAutoSizeInner img')
        || findLastAssetUrl(profileScope, '.playerAvatarAutoSizeInner picture img, .playerAvatarAutoSizeInner img');
    const frameUrl = getFrameAssetFromElement(frameElement)
        || findLastAssetUrl(profileScope, '.profile_header .profile_avatar_frame img, .profile_header .profile_avatar_frame source, .profile_avatar_frame img, .profile_avatar_frame source');
    const frameMarkup = getPreviewMarkupFromElement(frameElement);
    const bgVideo = currentProfileScope.querySelector('.profile_animated_background video')
        || profileScope.querySelector('.profile_animated_background video');
    const bgVideoUrl = getElementAssetUrl(bgVideo?.querySelector('source'));
    const bgPosterUrl = getElementAssetUrl(bgVideo)
        || findLastAssetUrl(currentProfileScope, '.profile_animated_background img')
        || findLastAssetUrl(profileScope, '.profile_animated_background img');
    const profilePage = currentProfileScope.matches?.('.profile_page')
        ? currentProfileScope
        : (profileScope.matches?.('.profile_page') ? profileScope : themeDocument.querySelector('#responsive_page_template_content .profile_page, .profile_page'));
    const backgroundUrl = getCssUrl(profilePage?.style?.backgroundImage)
        || getCssUrl(themeDocument.body?.style?.backgroundImage)
        || getItemPreviewUrl(sourceItem);

    storedTabData['tab2'].currentItem = makeThemeSyntheticItem(sdsText('themeFrame'), frameUrl, frameMarkup);
    const themeAvatarItem = makeThemeSyntheticItem(sdsText('themeAvatar'), avatarUrl);
    storedTabData['tab5'].currentItem = themeAvatarItem;
    if (themeAvatarItem && avatarUrl) {
        const avatarTarget = getProfileAvatarPicture(currentProfileScope) || getProfileAvatarHolder(currentProfileScope);
        updateAvatarMedia(avatarTarget, avatarUrl, [], getAvatarPosterUrls(themeAvatarItem));
        window.requestAnimationFrame(() => updateAvatarMedia(avatarTarget, avatarUrl, [], getAvatarPosterUrls(themeAvatarItem)));
    }

    if (bgVideoUrl) {
        const poster = bgPosterUrl ? ` poster="${bgPosterUrl}"` : '';
        storedTabData['tab3'].currentItem = makeThemeSyntheticItem(
            sdsText('themeAnimBg'),
            bgPosterUrl,
            `<video autoplay muted loop playsinline${poster}><source src="${bgVideoUrl}" type="video/webm"></video>`
        );
        storedTabData['tab4'].currentItem = null;
    } else {
        storedTabData['tab3'].currentItem = null;
        storedTabData['tab4'].currentItem = makeThemeSyntheticItem(sdsText('themeStaticBg'), backgroundUrl);
    }

    if (storedTabData['tab3'].currentItem?.synthetic_theme_item) {
        storedTabData['tab3'].currentItem.slot_name = sdsText('themeAnimBg');
        storedTabData['tab3'].currentItem.community_item_data.item_title = sdsText('themeAnimBg');
    }
    if (storedTabData['tab4'].currentItem?.synthetic_theme_item) {
        storedTabData['tab4'].currentItem.slot_name = sdsText('themeStaticBg');
        storedTabData['tab4'].currentItem.community_item_data.item_title = sdsText('themeStaticBg');
    }
}

function syncThemeProfileDom(themeDocument, options = {}) {
    const bioSnapshot = options.preserveBio ? captureProfileBioContent() : [];
    const currentTemplate = document.querySelector('#responsive_page_template_content');
    const nextTemplate = themeDocument.querySelector('#responsive_page_template_content');
    if (currentTemplate && nextTemplate) {
        currentTemplate.replaceWith(nextTemplate.cloneNode(true));
        syncThemeBackdropStyles(themeDocument);
        restoreProfileBioContent(bioSnapshot);
        return;
    }

    [
        '#profile_background_holder',
        '#profile_background_holder_content',
        '.profile_background_holder',
        '.profile_background_holder_content',
        '.profile_animated_background'
    ].forEach((selector) => syncThemeElementOrRemove(themeDocument, selector));

    syncThemeBackdropStyles(themeDocument);

    const replacedProfile = replaceThemeElementFromDocument(themeDocument, '#responsive_page_template_content .profile_page');
    if (replacedProfile) {
        syncThemeBackdropStyles(themeDocument);
        restoreProfileBioContent(bioSnapshot);
        return;
    }

    [
        '.profile_page',
        '.profile_header_bg',
        '.profile_header',
        '.profile_content'
    ].forEach((selector) => replaceThemeElementFromDocument(themeDocument, selector));

    syncThemeBackdropStyles(themeDocument);
    restoreProfileBioContent(bioSnapshot);
}

function removeSteamProfileThemeClasses() {
    const themedElements = [
        document.documentElement,
        document.body,
        ...document.querySelectorAll('[class*="GameProfile_"]')
    ];

    themedElements.forEach((element) => {
        if (!element) return;
        [...element.classList]
            .filter(className => /^GameProfile_\d+_\d+_Theme$/.test(className))
            .forEach(className => element.classList.remove(className));
    });
}

function restoreSyntheticFrameFromSnapshot() {
    if (!storedTabData['tab2']?.currentItem?.synthetic_theme_item) return;

    const profileScope = getCurrentProfileScope();
    const frameElement = findProfileFrameElement(profileScope);
    if (!initialSnapshot.dom.frameSrcset) {
        frameElement?.remove();
        return;
    }

    updateFrameElement(frameElement, initialSnapshot.dom.frameSrcset);
}

function restoreSyntheticAvatarFromSnapshot() {
    if (!storedTabData['tab5']?.currentItem?.synthetic_theme_item || !initialSnapshot.dom.avatarSrcset) return;

    const profileScope = getCurrentProfileScope();
    const avatarPicture = getProfileAvatarPicture(profileScope);
    updateAvatarMedia(avatarPicture || getProfileAvatarHolder(profileScope), initialSnapshot.dom.avatarSrcset);
}

function restoreSyntheticBackgroundFromSnapshot() {
    if (!storedTabData['tab3']?.currentItem?.synthetic_theme_item && !storedTabData['tab4']?.currentItem?.synthetic_theme_item) return;

    const profilePage = document.querySelector('#responsive_page_template_content .profile_page')
        || document.querySelector('.profile_page');
    if (profilePage) {
        profilePage.querySelectorAll('.profile_animated_background').forEach((element) => element.remove());
        clearProfileBackgroundLayout(profilePage);
        profilePage.style.backgroundImage = initialSnapshot.dom.backgroundImage || '';
        if (initialSnapshot.dom.animatedBgHTML) {
            profilePage.insertAdjacentHTML('afterbegin', initialSnapshot.dom.animatedBgHTML);
        }
    }

    const backgroundHolder = document.querySelector('#profile_background_holder, .profile_background_holder');
    if (initialSnapshot.dom.backgroundHolderHTML && backgroundHolder) {
        backgroundHolder.outerHTML = initialSnapshot.dom.backgroundHolderHTML;
    } else if (backgroundHolder) {
        backgroundHolder.remove();
    }
}

async function applyDefaultSteamTheme() {
    const preservedBio = captureProfileBioContent();

    clearInjectedThemeAssets();
    removeSteamProfileThemeClasses();
    restoreSyntheticFrameFromSnapshot();
    restoreSyntheticAvatarFromSnapshot();
    restoreSyntheticBackgroundFromSnapshot();

    storedTabData['tab1'].currentItem = null;
    ['tab2', 'tab3', 'tab4', 'tab5'].forEach((tabId) => {
        if (storedTabData[tabId].currentItem?.synthetic_theme_item) {
            storedTabData[tabId].currentItem = null;
        }
    });

    restoreProfileBioContent(preservedBio);
    init_customization();
    updateEquippedColumn();
    savePreviewState();
    syncBrowserUrlToCleanProfile();
}

async function applySteamProfileTheme(appId, defId, previewUrl, sourceItem = null, options = {}) {
    applySteamProfileThemeClass(appId, defId);

    try {
        const response = await fetchWithTimeout(previewUrl, { credentials: 'include' });
        if (!response.ok) return;

        const html = await response.text();
        const themeDocument = new DOMParser().parseFromString(html, 'text/html');
        const themeClass = [...themeDocument.body.classList].find(className => /^GameProfile_\d+_\d+_Theme$/.test(className));
        syncThemeRootClasses(themeDocument);
        if (themeClass) {
            applySteamProfileThemeClass(appId, defId, themeClass);
        }
        clearInjectedThemeAssets();
        addThemeStylesFromDocument(themeDocument);
        syncThemeBackdropStyles(themeDocument);
        syncThemeProfileDom(themeDocument, { preserveBio: true });
        applyThemePackageState(themeDocument, sourceItem);
        init_customization();
        updateEquippedColumn();
        if (options.persist === true) {
            savePreviewState();
        }
        syncBrowserUrlToCleanProfile();
    } catch (error) {
        console.debug('[SDS] Не удалось подгрузить тему без перезагрузки:', error);
    }
}

async function replaceTheme(appId, defId, itemType, sourceItem = null){
    const previewUrl = buildThemePreviewUrl(appId, defId, itemType || getThemeItemType(sourceItem));
    await applySteamProfileTheme(appId, defId, previewUrl, sourceItem, { persist: true });
}

function getBulkFetchCountForRows(missingRows) {
    const missingItems = Math.max(0, missingRows * 3);
    if (missingItems > 2400) return 5000;
    if (missingItems > 900) return 2500;
    if (missingItems > 420) return 1200;
    return null;
}

function getFallbackFetchCount(count) {
    if (count > 5000) return 5000;
    if (count > 2500) return 2500;
    if (count > 1200) return 1200;
    if (count > 600) return 600;
    if (count > 180) return 180;
    return null;
}

async function load_new_content(tabId, itemClass, filter = null) {
    const tabState = storedTabData[tabId];
    const requestRevision = tabState.revision;

    if (tabState.next_cursor == "*")
        return [];
    let resDefId = []
    
    resDefId = getArrayFromStorage('fav'+tabId);
    if(resDefId && (JSON.stringify(tabState.favDefId) !== JSON.stringify(resDefId))){
        tabState.next_cursor = null;
        tabState.favDefId = resDefId;
    }else if(resDefId === null)
        tabState.favDefId = []
    

    tabState.is_fetching = true;

    let cnt = tabState.fetchCountOverride || SDS_DEFAULT_FETCH_COUNT;

    let url = `https://api.steampowered.com/ILoyaltyRewardsService/BatchedQueryRewardItems/v1/`
    let lng = sidebarLang === 'en' ? 'english' : 'russian';

    let isDecending = 'true';
    let isDate = 1;

    if(sortType%2==1){
        isDecending = 'false';
    }

    if(sortType >= 2){
        isDate = 2;
    }

    let del = {
        "requests": [{
            "community_item_classes": [`${itemClass}`],
            "sort_descending": isDecending,
            "count": cnt,
            "language": lng,
            "sort": isDate,
        }]

    };
    
    if(sortType === 5){
        if(resDefId === null || resDefId.length === 0)
            resDefId = [-1];
        del = {
            "requests": [{
                "community_item_classes": [`${itemClass}`],
                "count": cnt,
                "language": lng,
                "definitionids": resDefId,
            }]
    
        };
    }

    if (tabState.next_cursor !== null)
        del['requests'][0]['cursor'] = tabState.next_cursor;

    if (tabState.search_word != "")
        del['requests'][0]['search_term'] = tabState.search_word;

    if (filter == "anim")
        del['requests'][0]['filters'] = ["1"];
    else if (filter == "stat")
        del['requests'][0]['filters'] = ["2"];

    const searchParams = encodeURIComponent(JSON.stringify(del));

    let response;
    try {
        response = await fetchWithTimeout(url + `?access_token=${getApiKey()}&input_json=` + searchParams);
    } catch (error) {
        if (tabState.revision !== requestRevision) {
            tabState.is_fetching = false;
            return [];
        }
        const fallbackCount = getFallbackFetchCount(cnt);
        if (fallbackCount && fallbackCount < cnt) {
            tabState.fetchCountOverride = fallbackCount;
            tabState.is_fetching = false;
            return load_new_content(tabId, itemClass, filter);
        }
        tabState.largeFetchFailed = true;
        tabState.maxItemsCnt = Math.max(tabState.maxItemsCnt || 0, tabId === 'tab5' ? 1 : 0);
        tabState.next_cursor = "*";
        tabState.is_fetching = false;
        console.debug('[SDS] Items fetch failed:', error);
        return [];
    }
    if (tabState.revision !== requestRevision) {
        tabState.is_fetching = false;
        return [];
    }

    if (!response.ok) {
        const fallbackCount = getFallbackFetchCount(cnt);
        if (fallbackCount && fallbackCount < cnt) {
            tabState.fetchCountOverride = fallbackCount;
            return load_new_content(tabId, itemClass, filter);
        }
        tabState.largeFetchFailed = true;
        tabState.is_fetching = false;
        return [];
    }

    let data = await response.json();
    if (tabState.revision !== requestRevision) {
        tabState.is_fetching = false;
        return [];
    }

    data = data?.['response']?.['responses']?.[0]?.['response'];

    if (data == null || data['definitions'] == null) {
        const fallbackCount = getFallbackFetchCount(cnt);
        if (fallbackCount && fallbackCount < cnt) {
            tabState.fetchCountOverride = fallbackCount;
            return load_new_content(tabId, itemClass, filter);
        }
        tabState.largeFetchFailed = true;
        tabState.maxItemsCnt = tabId === 'tab5' ? 1 : 0;
        tabState.next_cursor = "*";
        tabState.is_fetching = false;
        return [];
    }

    tabState.maxItemsCnt = (Number(data['total_count']) || 0) + (tabId === 'tab5' ? 1 : 0)

    tabState.next_cursor = data['next_cursor'];
    data = data['definitions'];

    tabState.is_fetching = false;
    return data;
}

async function parse_item_content(tabId){
    const tabState = storedTabData[tabId];
    const requestRevision = tabState.revision;
    let filter = null;
    let itemClass = 0;

    if(tabId === 'tab1'){
        itemClass = 8;
    }
    else if(tabId === 'tab2'){
        itemClass = 14;
    }        
    else if(tabId === 'tab3'){
        filter = 'anim';
        itemClass = 3;
    }else if(tabId === 'tab4'){
        filter = 'stat';
        itemClass = 3;
    }else if(tabId === 'tab5'){
        itemClass = 15;
    }
    
    let data = await load_new_content(tabId, itemClass, filter);
    if (tabState.revision !== requestRevision) return;
    let itemsForRows = data;

    if(tabId === 'tab5' && storedTabData[tabId].itemData.length === 0){
        itemsForRows = [createCustomAvatarItem(), ...data];
    }

    if(itemsForRows.length === 0)
        return;

    let rowHld = []
    itemsForRows.forEach((element) => {
        if (isStandardSteamThemeItem(element)) return;

        if(rowHld.length === 3){
            storedTabData[tabId].itemData.push(rowHld);
            rowHld = [];
        }

        if (element.custom_avatar) {
            rowHld.push(element);
            return;
        }

        let rowItem = {};

        rowItem['item_image_large'] = element['community_item_data']['item_image_small'];
        if('item_image_large' in element['community_item_data']){
            rowItem['item_image_large'] = element['community_item_data']['item_image_large']
        }
        rowItem['item_image_small'] = element['community_item_data']['item_image_small']

        rowItem['item_movie_webm'] = null
        if('item_movie_webm' in element['community_item_data']){ 
            rowItem['item_movie_webm'] = element['community_item_data']['item_movie_webm']
        }
        if('item_movie_mp4' in element['community_item_data']){
            rowItem['item_movie_mp4'] = element['community_item_data']['item_movie_mp4']
        }
        if('item_movie' in element['community_item_data']){
            rowItem['item_movie'] = element['community_item_data']['item_movie']
        }

        rowItem['storeName'] = element['community_item_data']['item_title'];
        rowItem['itemtype'] = element['community_item_type'];

        rowItem['appid'] = element['appid'];
        rowItem['defid'] = element['defid'];
        rowItem['point_cost'] = findPointCost(element);
        rowItem['reliable_point_cost'] = findReliablePointCost(element);
        if (tabId === 'tab4' && rowItem['reliable_point_cost'] !== null) {
            rowItem['sds_static_background_pattern'] = rowItem['reliable_point_cost'] >= SDS_PATTERN_STATIC_BG_COST;
        }
        rowItem['_raw'] = element;

        rowHld.push(rowItem);
    });
    if(rowHld.length != 0){
        storedTabData[tabId].itemData.push(rowHld);
        rowHld = [];
    }
}

function cropImage(url, startX, startY, width, height) {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "Anonymous"; // Важно, если картинка с другого домена
    img.src = url;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
     const sq = Math.min(img.width, img.height);
      // drawImage(image, sourceX, sourceY, sourceWidth, sourceHeight, destX, destY, destWidth, destHeight)
      if(img.width > img.height){
        ctx.drawImage(img, img.width-img.height, 0, sq, sq, 0, 0, width, height);
      }else{
        ctx.drawImage(img, 0, img.height-img.width, sq, sq, 0, 0, width, height);
      }
      
      resolve(canvas.toDataURL('image/png')); // Получаем обрезанное изображение
    };
  });
}

function getPageStartRow(page) {
    return Math.floor((page * cnt_per_page) / 3);
}

function getPageEndRow(page) {
    return Math.ceil(((page + 1) * cnt_per_page) / 3) - 1;
}

async function ensureRowsLoaded(tabId, targetRow) {
    const tabState = storedTabData[tabId];
    while (tabState.itemData.length <= targetRow && tabState.next_cursor !== "*") {
        const beforeLength = tabState.itemData.length;
        const missingRows = Math.max(0, targetRow - beforeLength + 1);
        tabState.fetchCountOverride = !tabState.largeFetchFailed ? getBulkFetchCountForRows(missingRows) : null;

        if (!tabState.loadingPromise) {
            tabState.loadingPromise = parse_item_content(tabId).finally(() => {
                tabState.loadingPromise = null;
                tabState.fetchCountOverride = null;
            });
        }

        await tabState.loadingPromise;

        if (tabState.itemData.length === beforeLength) {
            break;
        }
    }
}

function schedulePrefetchNextPage(tabId) {
    const tabState = storedTabData[tabId];
    if (!tabState || tabState.next_cursor === "*" || tabState.prefetchTimer) return;

    const targetRow = getPageEndRow(tabState.currentPage + SDS_PREFETCH_PAGE_OFFSET);
    if (tabState.itemData.length > targetRow) return;

    tabState.prefetchTimer = setTimeout(() => {
        tabState.prefetchTimer = null;
        ensureRowsLoaded(tabId, targetRow).catch((error) => {
            console.debug('[SDS] Предзагрузка страницы не удалась:', error);
        });
    }, 900);
}

function createCustomAvatarItem(src = '') {
    return {
        custom_avatar: true,
        appid: 'custom',
        defid: CUSTOM_AVATAR_DEFID,
        community_item_data: {
            item_title: 'Своя аватарка',
            item_image_small: src,
            item_image_large: src
        }
    };
}

function applyCustomAvatar(src) {
    const profileScope = getCurrentProfileScope();
    const avatarTarget = getProfileAvatarPicture(profileScope) || getProfileAvatarHolder(profileScope) || getProfileAvatarImage(profileScope);
    if (avatarTarget !== null) {
        updateAvatarMedia(avatarTarget, src, []);
        window.requestAnimationFrame(() => {
            updateAvatarMedia(avatarTarget, src, []);
        });
    }

    storedTabData.tab5.currentItem = createCustomAvatarItem(src);
    savePreviewState();
    updateEquippedColumn();
}

function ensureAvatarInput() {
    let avatarInput = document.getElementById('inputAvatar');
    if (avatarInput) return avatarInput;

    avatarInput = document.createElement('input');
    avatarInput.type = 'file';
    avatarInput.id = 'inputAvatar';
    avatarInput.style = "display: none;";
    avatarInput.accept = 'image/*';
    document.body.appendChild(avatarInput);

    avatarInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (!file) return;

        const objectUrl = window.URL.createObjectURL(file);
        cropImage(objectUrl, 0, 0, 800, 800).then((res) => {
            window.URL.revokeObjectURL(objectUrl);
            applyCustomAvatar(res);
            avatarInput.value = '';
        });
    });

    return avatarInput;
}

async function setCurrentItem(tabId, item = null, options = {}){
    if (item !== null) {
        storedTabData[tabId].currentItem = item;
    }

    if(tabId === 'tab5'){
        ensureAvatarInput();
    }

    if (item !== null && options.persist !== false) {
        savePreviewState();
    }

    // Обновляем правую колонку с надетыми предметами
    updateEquippedColumn();
}

function getApplyAssetUrls(tabId, item) {
    if (!item || item.custom_avatar || item.dom_avatar) return [];
    if (tabId === 'tab2' || tabId === 'tab5') {
        return [stemLnksEnt.getProfileLnk(item['appid'], item['item_image_small'])];
    }
    if (tabId === 'tab3') {
        return [stemLnksEnt.getProfileLnk(item['appid'], item['item_image_large'])];
    }
    if (tabId === 'tab4') {
        return [stemLnksEnt.getProfileLnk(item['appid'], item['item_image_large'])];
    }
    return [];
}

function warmApplyAssets(tabId, item) {
    getApplyAssetUrls(tabId, item).forEach((url) => {
        preloadImage(url).catch(() => false);
    });
}

function createRow(tabId, row_data){
    let newRow = document.createElement('div');
    newRow.className = "content-grid-row";
    storedTabData[tabId].itemData[row_data].forEach((item,index) => {
        if (isStandardSteamThemeItem(item)) return;

        const newItem = document.createElement('div');
        newItem.className = 'content-item';
        if (item.custom_avatar) {
            newItem.classList.add('custom-avatar-tile');
            newItem.innerHTML = `
                <div class="custom-avatar-icon">+</div>
                <div class="item-text"><a>${sdsText('customAvatar')}</a></div>
            `;
            newItem.addEventListener("click", (event) => {
                event.stopPropagation();
                ensureAvatarInput().click();
            });
            newItem.style.width = '100%';
            newRow.appendChild(newItem);
            return;
        }

        if(tabId == "tab1"){
            newItem.innerHTML = `
                ${getLazyImageMarkup(stemLnksEnt.getPreviewLnk(item['appid'], item['item_image_small']))}
            `;
            newItem.addEventListener("click", (event)=>{
                replaceTheme(item['appid'], item['defid'], item['itemtype'], item['_raw'] || item);
            });
        }else if(tabId == "tab2"){
            newItem.innerHTML = `
                ${getLazyImageMarkup(stemLnksEnt.getPreviewLnk(item['appid'], item['item_image_large']), 'animPrev')}
                ${getLazyImageMarkup(stemLnksEnt.getProfileLnk(item['appid'], item['item_image_small']), 'animPart')}                
            `;
            newItem.addEventListener("click", (event)=>{
                replaceFrame(stemLnksEnt.getProfileLnk(item['appid'], item['item_image_small']), item['defid'], item['_raw'] || item)
            });
            newItem.addEventListener("mouseenter", () => hydrateHoverMedia(newItem));
        }else if(tabId == "tab3"){
            newItem.innerHTML = `
                ${getLazyImageMarkup(stemLnksEnt.getPreviewLnk(item['appid'], item['item_image_large']), 'animPrev')}
                <video class="animPart" playsinline muted loop poster="${SDS_TRANSPARENT_PIXEL}" data-sds-poster="${stemLnksEnt.getPreviewLnk(item['appid'], item['item_image_large'])}" preload="none">
                    <source src="${stemLnksEnt.getProfileLnk(item['appid'], item['item_movie_webm'])}" type="video/webm">
                </video>
            `;
            newItem.addEventListener("click", (event)=>
            {
                replaceAnimBG(stemLnksEnt.getProfileLnk(item['appid'], item['item_movie_webm']), 
                                      stemLnksEnt.getProfileLnk(item['appid'], item['item_image_large']),
                                      item['defid'],
                                      item['_raw'] || item);
            });
            newItem.addEventListener("mouseenter", () => {
                playHoverVideo(newItem);
            });
            newItem.addEventListener("mouseleave", () => {
                pauseHoverVideo(newItem);
            });
        }else if(tabId == "tab4"){
            newItem.innerHTML = `
                ${getLazyImageMarkup(stemLnksEnt.getPreviewLnk(item['appid'], item['item_image_large']))}
            `;
            newItem.addEventListener("click", (event)=>
            {
                const previewMedia = event.currentTarget.querySelector('.sds-lazy-media');
                const sourceItem = markStaticBackgroundKind(item['_raw'] || item, item, previewMedia);
                replaceStaticBG(stemLnksEnt.getProfileLnk(item['appid'], item['item_image_large']),
                                      item['defid'],
                                      sourceItem,
                                      { staticBackgroundRepeat: sourceItem?.sds_static_background_pattern });
            });
        }else if(tabId == "tab5"){
            const avatarVideo = getAvatarVideoUrls(item);
            newItem.innerHTML = `
                ${getLazyImageMarkup(stemLnksEnt.getPreviewLnk(item['appid'], item['item_image_large']), 'animPrev')}
                ${avatarVideo.length
                    ? `<video class="animPart" playsinline muted loop poster="${SDS_TRANSPARENT_PIXEL}" data-sds-poster="${stemLnksEnt.getPreviewLnk(item['appid'], item['item_image_large'])}" preload="none">
                        ${avatarVideo.map((url) => `<source src="${url}" type="${getVideoMimeType(url)}">`).join('')}
                    </video>`
                    : getLazyImageMarkup(stemLnksEnt.getProfileLnk(item['appid'], item['item_image_small']), 'animPart')}                
            `;
            newItem.addEventListener("click", (event)=>{
                replaceAvatar(getAvatarPosterUrl(item) || stemLnksEnt.getProfileLnk(item['appid'], item['item_image_small']), item['defid'], item['_raw'] || item)
            });
            newItem.addEventListener("mouseenter", () => {
                if (avatarVideo.length) {
                    playHoverVideo(newItem);
                } else {
                    hydrateHoverMedia(newItem);
                }
            });
            if (avatarVideo.length) {
                newItem.addEventListener("mouseleave", () => pauseHoverVideo(newItem));
            }
        }

        newItem.classList.add('is-media-pending');

        newItem.innerHTML = newItem.innerHTML +
        `<div class="item-text"><a>${escapeHTML(item['storeName'])}</a></div>`;
        

        const itemDefId = `${item['defid']}`;
        const isFavorite = storedTabData[tabId].favDefId.includes(itemDefId);
        let isStared = isFavorite ? '★' : '☆';

        let starBtn = document.createElement('button');
        starBtn.className = "starBtn";
        if (isFavorite) {
            starBtn.classList.add('is-favorite');
        }
        starBtn.id = item['defid'];
        starBtn.innerText = isStared;
        starBtn.title = isFavorite ? 'Убрать из избранного' : 'Добавить в избранное';
        
        let lnkBtn = document.createElement('button');
        lnkBtn.className = "lnkBtn";
        lnkBtn.innerText = "↗";
        lnkBtn.addEventListener('click', (event) => {
            window.open(stemLnksEnt.getShopLnk(item['appid'], item['defid']), '_blank', 'noopener,noreferrer');
             event.stopPropagation();
        });
        
        starBtn.addEventListener('click', (event) => {
            const btn = event.currentTarget;
            if(btn.innerText == "☆"){
                btn.innerText = '★';
                btn.classList.add('is-favorite');
                btn.title = 'Убрать из избранного';
                addToArrayInStorage(`fav${tabId}`, btn.id);
                storedTabData[tabId].favDefId.push(itemDefId);
            }
            else{
                btn.innerText = '☆';
                btn.classList.remove('is-favorite');
                btn.title = 'Добавить в избранное';
                removeFromArrayInStorage(`fav${tabId}`, btn.id);
                storedTabData[tabId].favDefId = storedTabData[tabId].favDefId.filter(defId => defId !== itemDefId);
            }

            event.stopPropagation();
            
        });
        
        starBtn.type = "button";
        starBtn.innerHTML = getStarIcon(isFavorite);
        starBtn.title = isFavorite ? 'Remove from favorites' : 'Add to favorites';
        starBtn.setAttribute('aria-label', starBtn.title);

        lnkBtn.type = "button";
        lnkBtn.innerHTML = getExternalIcon();
        lnkBtn.title = "Open in points shop";
        lnkBtn.setAttribute('aria-label', lnkBtn.title);

        newItem.addEventListener('mouseenter', () => warmApplyAssets(tabId, item), { once: true });
        newItem.addEventListener('focusin', () => warmApplyAssets(tabId, item), { once: true });

        starBtn.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopImmediatePropagation();
            event.stopPropagation();

            const btn = event.currentTarget;
            const nextFavorite = !btn.classList.contains('is-favorite');

            if (nextFavorite) {
                btn.classList.add('is-favorite');
                btn.innerHTML = getStarIcon(true);
                btn.title = 'Remove from favorites';
                btn.setAttribute('aria-label', btn.title);
                addToArrayInStorage(`fav${tabId}`, btn.id);
                if (!storedTabData[tabId].favDefId.includes(itemDefId)) {
                    storedTabData[tabId].favDefId.push(itemDefId);
                }
            } else {
                btn.classList.remove('is-favorite');
                btn.innerHTML = getStarIcon(false);
                btn.title = 'Add to favorites';
                btn.setAttribute('aria-label', btn.title);
                removeFromArrayInStorage(`fav${tabId}`, btn.id);
                storedTabData[tabId].favDefId = storedTabData[tabId].favDefId.filter(defId => defId !== itemDefId);
            }
        }, { capture: true });

        newItem.style.width = '100%';  
        newItem.appendChild(starBtn);
        newItem.appendChild(lnkBtn);

        newRow.appendChild(newItem);
    })

    return newRow;
}

async function fill_page(tabId){
    let activeTab = document.getElementById(tabId);
    const tabState = storedTabData[tabId];
    const requestRevision = tabState.revision;

    
    let contentGrid = activeTab.querySelector('.content-grid');
    const startRow = getPageStartRow(tabState.currentPage);
    const endRow = getPageEndRow(tabState.currentPage);

    if (!tabState.itemData[startRow]) {
        contentGrid.innerHTML = `<div class="grid-loader">
            <div class="spinner"></div>
            <span class="loader-text">${sdsText('loading')}</span>
        </div>`;
    }

    let loadFailed = false;
    try {
        await ensureRowsLoaded(tabId, endRow);
    } catch (error) {
        loadFailed = true;
        tabState.next_cursor = "*";
        tabState.is_fetching = false;
        console.debug('[SDS] Page load failed:', error);
    }
    if (tabState.revision !== requestRevision) return;

    const fragmentNew = document.createDocumentFragment();

    for(let i = startRow; i <= endRow; i++){
        if (!storedTabData[tabId].itemData[i]) {
            break;
        }
        fragmentNew.append(createRow(tabId, i));
    }

    if (!fragmentNew.childNodes.length) {
        const emptyState = document.createElement('div');
        emptyState.className = 'empty-state';
        emptyState.textContent = getSharedSearchTerm() ? 'Ничего не найдено' : 'Нет предметов для показа';
        if (loadFailed) {
            emptyState.textContent = 'Load failed. Try refreshing this tab.';
        }
        fragmentNew.append(emptyState);
    }

    await new Promise((resolve) => {
        window.requestAnimationFrame(() => {
            if (tabState.revision !== requestRevision) {
                resolve();
                return;
            }
            contentGrid.innerHTML = ``;

            contentGrid.append(fragmentNew);
            tabState.renderKey = loadFailed ? "" : getTabRenderKey(tabId);
            hydrateLazyMedia(contentGrid);
            schedulePrefetchNextPage(tabId);
            resolve();
        });
    });
}

function getApiKey() {
    let webAPIToken = document.getElementById('application_config');

    if (webAPIToken === null)
        throw new Error("Not logged in");

    try {
        webAPIToken = webAPIToken.dataset.loyalty_webapi_token.toString();
    } catch {
        throw new Error("Not logged in");
    }

    webAPIToken = webAPIToken.replace(`"`, ``);
    return webAPIToken;
}

async function getLnkSettings() {

    let curLocation = new URL(location.href);
    const hasFrameOverride = curLocation.searchParams.has("frameST");
    const hasAnimBgOverride = curLocation.searchParams.has("bgAnimST");
    const hasStaticBgOverride = curLocation.searchParams.has("bgStST");
    const hasAvatarOverride = curLocation.searchParams.has("ava");

    let defIDS = [curLocation.searchParams.get("frameST"),
    curLocation.searchParams.get("bgAnimST"),
    curLocation.searchParams.get("bgStST"),
    curLocation.searchParams.get("ava"),
    curLocation.searchParams.get("theme")]

    let webToken = getApiKey();

    let paramDefIds = []

    defIDS.forEach(element => {
        if (element !== null) {
            paramDefIds.push(element)
        }
    })

    if (paramDefIds.length === 0) {
        return;
    }

    const url = `https://api.steampowered.com/ILoyaltyRewardsService/BatchedQueryRewardItems/v1/`
    const lng = 'russian';
    const del = {
        "requests": [{
            "sort_descending": "true",
            "count": paramDefIds.length,
            "language": lng,
            "definitionids": paramDefIds
        }]

    };
    const searchParams = encodeURIComponent(JSON.stringify(del));

    let data = await fetchWithTimeout(url + `?access_token=${webToken}&input_json=` + searchParams);

    if (!data.ok)
        return;

    data = await data.json();

    data = data["response"]["responses"][0]["response"]["definitions"];

    const preservedThemeItems = {
        tab2: !hasFrameOverride && storedTabData['tab2'].currentItem?.synthetic_theme_item ? storedTabData['tab2'].currentItem : null,
        tab3: !hasAnimBgOverride && !hasStaticBgOverride && storedTabData['tab3'].currentItem?.synthetic_theme_item ? storedTabData['tab3'].currentItem : null,
        tab4: !hasAnimBgOverride && !hasStaticBgOverride && storedTabData['tab4'].currentItem?.synthetic_theme_item ? storedTabData['tab4'].currentItem : null,
        tab5: !hasAvatarOverride && storedTabData['tab5'].currentItem?.synthetic_theme_item ? storedTabData['tab5'].currentItem : null
    };
    const customAvatarItem = !hasAvatarOverride && storedTabData['tab5'].currentItem?.custom_avatar ? storedTabData['tab5'].currentItem : null;
    storedTabData['tab2'].currentItem = preservedThemeItems.tab2;
    storedTabData['tab3'].currentItem = preservedThemeItems.tab3;
    storedTabData['tab4'].currentItem = preservedThemeItems.tab4;
    storedTabData['tab5'].currentItem = customAvatarItem || preservedThemeItems.tab5;

    if (data != null && paramDefIds.length > 0) {
        data.forEach(element => {
            if (element['community_item_class'] == 8)
                storedTabData['tab1'].currentItem = element;
            else if (element['community_item_class'] == 3) {
                if (element['community_item_data']['animated'] == true)
                    storedTabData['tab3'].currentItem = element;
                else
                    storedTabData['tab4'].currentItem = element;
            } else if (element['community_item_class'] == 14) {
                storedTabData['tab2'].currentItem = element;
            }
             else if (element['community_item_class'] == 15) {
                storedTabData['tab5'].currentItem = element;
            }
        })
    }
    if (storedTabData['tab5'].currentItem) {
        const item = storedTabData['tab5'].currentItem;
        const avatarPoster = getAvatarPosterUrl(item) || getProfileAssetUrl(item['appid'], item['community_item_data']?.['item_image_small']);
        const avatarVideo = getAvatarVideoUrls(item);
        if (avatarVideo.length) {
            updateAvatarMedia(
                getProfileAvatarPicture(getCurrentProfileScope()) || getProfileAvatarHolder(getCurrentProfileScope()),
                avatarPoster,
                avatarVideo
            );
        }
    }
}

async function getProfileItems() {
    let key = document.querySelector('body').innerHTML.match(/g_rgProfileData = .+(765611[\d+]{11})/);

    if (!key || key.length < 2 || key[1] === null)
        return;

    const language = sidebarLang === 'en' ? 'english' : 'russian';
    let data = await fetchWithTimeout(`https://api.steampowered.com/ILoyaltyRewardsService/GetEquippedProfileItems/v1?input_json={%22steamid%22:%22${key[1]}%22,%22language%22:%22${language}%22}`)

    if (!data.ok)
        return;

    data = await data.json();

    data = data?.["response"]?.["active_definitions"];
    if (Array.isArray(data)) {
        data.forEach(element => {
            if (element['community_item_class'] == 8 && storedTabData['tab1'].currentItem === null)
                storedTabData['tab1'].currentItem = element;
            else if (element['community_item_class'] == 3
                && (storedTabData['tab3'].currentItem === null
                    && storedTabData['tab4'].currentItem === null)) {
                if (element['community_item_data']['animated'] == true)
                    storedTabData['tab3'].currentItem = element;
                else
                    storedTabData['tab4'].currentItem = element;
            } else if (element['community_item_class'] == 14 && storedTabData['tab2'].currentItem === null) {
                storedTabData['tab2'].currentItem = element;
            }
            else if (element['community_item_class'] == 15 && storedTabData['tab5'].currentItem === null) {
                storedTabData['tab5'].currentItem = element;
            }
        })
    }

    ensureCurrentAvatarFromDom({ preferDomWhenMissing: true, enrichExisting: true });
}

// === Снимок исходного состояния ===
// Запоминаем что было надето ИЗНАЧАЛЬНО — для кнопки "Сброс".
// Хранится в localStorage по ключу SteamID, чтобы пережить релоад
// (пользователь меняет тему -> страница перезагружается с темой -> мы должны
// помнить ИСХОДНУЮ тему, а не свежеприменённую).

function getCurrentSteamId() {
    try {
        const m = document.querySelector('body').innerHTML.match(/g_rgProfileData = .+(765611\d{11})/);
        if (m && m[1]) return m[1];
    } catch (e) {}
    return null;
}

function snapshotStorageKey() {
    const sid = getCurrentSteamId();
    return sid ? `sds_initial_snapshot_${sid}` : null;
}

function previewStateStorageKey() {
    const sid = getCurrentSteamId();
    return sid ? `sds_preview_state_${sid}` : null;
}

function getSerializableCurrentItems() {
    return ['tab1', 'tab2', 'tab3', 'tab4', 'tab5'].reduce((acc, tabId) => {
        acc[tabId] = storedTabData[tabId].currentItem ? structuredClone(storedTabData[tabId].currentItem) : null;
        return acc;
    }, {});
}

function savePreviewState() {
    const key = previewStateStorageKey();
    if (!key) return;
    try {
        localStorage.setItem(key, JSON.stringify({
            items: getSerializableCurrentItems(),
            savedAt: Date.now()
        }));
    } catch (e) {
        console.warn('[SDS] Не удалось сохранить preview state:', e);
    }
}

function loadPreviewState() {
    const key = previewStateStorageKey();
    if (!key) return false;
    try {
        const raw = localStorage.getItem(key);
        if (!raw) return false;
        const parsed = JSON.parse(raw);
        if (!parsed?.items) return false;
        for (const tabId of ['tab1', 'tab2', 'tab3', 'tab4', 'tab5']) {
            if (Object.prototype.hasOwnProperty.call(parsed.items, tabId)) {
                storedTabData[tabId].currentItem = parsed.items[tabId] ? structuredClone(parsed.items[tabId]) : null;
            }
        }
        localStorage.removeItem('sds_theme_only_mode');
        return true;
    } catch (e) {
        console.warn('[SDS] Не удалось загрузить preview state:', e);
    }
    return false;
}

function clearPreviewState() {
    const key = previewStateStorageKey();
    if (!key) return;
    try {
        localStorage.removeItem(key);
    } catch (e) {}
}

function loadSnapshotFromStorage() {
    const key = snapshotStorageKey();
    if (!key) return false;
    try {
        const raw = localStorage.getItem(key);
        if (!raw) return false;
        const parsed = JSON.parse(raw);
        if (parsed && parsed.captured) {
            // Аккуратно сливаем (не перезаписываем структуру целиком,
            // т.к. там могут быть undefined-поля)
            initialSnapshot.captured = true;
            initialSnapshot.items = parsed.items || initialSnapshot.items;
            initialSnapshot.dom = { ...initialSnapshot.dom, ...(parsed.dom || {}) };
            initialSnapshot.url = parsed.url || null;
            return true;
        }
    } catch (e) {
        console.warn('[SDS] Не удалось загрузить snapshot:', e);
    }
    return false;
}

function saveSnapshotToStorage() {
    const key = snapshotStorageKey();
    if (!key) return;
    try {
        localStorage.setItem(key, JSON.stringify(initialSnapshot));
    } catch (e) {
        console.warn('[SDS] Не удалось сохранить snapshot:', e);
    }
}

function clearSnapshotFromStorage() {
    const key = snapshotStorageKey();
    if (!key) return;
    try {
        localStorage.removeItem(key);
    } catch (e) {}
}

function resetCurrentItems() {
    for (const tabId of ['tab1', 'tab2', 'tab3', 'tab4', 'tab5']) {
        storedTabData[tabId].currentItem = null;
    }
}

async function restoreCleanProfileFromNetwork(cleanUrl, preservedBio = null) {
    try {
        const response = await fetchWithTimeout(cleanUrl.href, { credentials: 'include' });
        if (!response.ok) return false;

        const html = await response.text();
        const cleanDocument = new DOMParser().parseFromString(html, 'text/html');
        if (!cleanDocument.querySelector('#responsive_page_template_content, .profile_page')) return false;

        clearInjectedThemeAssets();
        syncThemeRootClasses(cleanDocument);
        syncThemeProfileDom(cleanDocument);
        restoreProfileBioContent(preservedBio);
        return true;
    } catch (e) {
        console.debug('[SDS] Clean profile restore failed:', e);
    }
    return false;
}

async function refreshInitialSnapshotFromCurrentDom() {
    clearSnapshotFromStorage();
    resetInitialSnapshotMemory();
    resetCurrentItems();
    await getProfileItems();
    captureInitialSnapshot();
}

function captureInitialSnapshot() {
    if (initialSnapshot.captured) return;

    ensureCurrentAvatarFromDom({ preferDomWhenMissing: true, enrichExisting: true });

    // 1. Сохраняем текущие предметы (то, что getProfileItems уже положил в storedTabData)
    for (const tabId of ['tab1', 'tab2', 'tab3', 'tab4', 'tab5']) {
        const item = storedTabData[tabId].currentItem;
        if (item !== null) {
            initialSnapshot.items[tabId] = structuredClone(item);
        }
    }

    // 2. Резервные копии DOM (на случай элементов, которых нет в API)
    try {
        initialSnapshot.dom.bodyClass = document.body?.className || '';
        initialSnapshot.dom.htmlClass = document.documentElement?.className || '';

        const templateContent = document.getElementById('responsive_page_template_content');
        if (templateContent) {
            initialSnapshot.dom.templateContentHTML = templateContent.outerHTML;
        }

        const backgroundHolder = document.querySelector('#profile_background_holder, .profile_background_holder');
        if (backgroundHolder) {
            initialSnapshot.dom.backgroundHolderHTML = backgroundHolder.outerHTML;
        }

        const profilePage = document.getElementById('responsive_page_template_content')
            ?.getElementsByClassName('profile_page')?.item(0);
        if (profilePage) {
            initialSnapshot.dom.profilePageHTML = profilePage.outerHTML;
            initialSnapshot.dom.backgroundImage = profilePage.style.backgroundImage || '';
            const animBg = profilePage.getElementsByClassName('profile_animated_background').item(0);
            initialSnapshot.dom.animatedBgHTML = animBg ? animBg.outerHTML : null;
        }

        const frameElement = findProfileFrameElement(getCurrentProfileScope());
        const frameSrc = getFrameAssetFromElement(frameElement);
        if (frameSrc) initialSnapshot.dom.frameSrcset = frameSrc;

        const avatarImg = getProfileAvatarImage(getCurrentProfileScope());
        if (avatarImg) initialSnapshot.dom.avatarSrcset = avatarImg.srcset || avatarImg.src || '';

        initialSnapshot.dom.bioContent = captureProfileBioContent();
    } catch (e) {
        console.warn('[SDS] Не удалось снять снимок DOM:', e);
    }

    // 3. Сохраняем "чистый" URL — без наших параметров
    const cleanUrl = removeCustomUrlParams(new URL(window.location.href));
    initialSnapshot.url = cleanUrl.href;

    initialSnapshot.captured = true;

    // Сохраняем в localStorage, чтобы пережил релоад
    saveSnapshotToStorage();
}

// === Правая колонка: текущие надетые предметы ===
function getSlotPreviewMarkup(tabId, item) {
    if (!item) return '';
    if (item.preview_markup) return item.preview_markup;
    if (item.preview_src) return `<img src="${item.preview_src}" loading="lazy" alt="">`;
    if (item.custom_avatar) {
        const customSrc = item['community_item_data']?.['item_image_small'];
        return customSrc ? `<img src="${customSrc}" loading="lazy" alt="">` : '<div class="custom-avatar-slot-icon">+</div>';
    }
    const data = item['community_item_data'] || item;
    const appid = item['appid'];

    // Темы — маленькое превью
    if (tabId === 'tab1') {
        const small = data['item_image_small'];
        if (!small) return '';
        return `<img src="${stemLnksEnt.getPreviewLnk(appid, small)}" loading="lazy" alt="">`;
    }
    // Рамка — превью кадра
    if (tabId === 'tab2') {
        const img = data['item_image_large'] || data['item_image_small'];
        return `<img src="${stemLnksEnt.getPreviewLnk(appid, img)}" loading="lazy" alt="">`;
    }
    // Анимированный фон — превью + видео при наведении
    if (tabId === 'tab3') {
        const poster = data['item_image_large'] || data['item_image_small'];
        return `<img src="${stemLnksEnt.getPreviewLnk(appid, poster)}" loading="lazy" alt="">`;
    }
    // Статический фон
    if (tabId === 'tab4') {
        const img = data['item_image_large'] || data['item_image_small'];
        return `<img src="${stemLnksEnt.getPreviewLnk(appid, img)}" loading="lazy" alt="">`;
    }
    // Аватар
    if (tabId === 'tab5') {
        const poster = data['item_image_large'] || data['item_image_small'];
        const avatarVideo = getAvatarVideoUrls(item);
        if (avatarVideo.length) {
            const sources = avatarVideo.map((url) => `<source src="${url}" type="${getVideoMimeType(url)}">`).join('');
            return `<video autoplay muted loop playsinline preload="auto" poster="${stemLnksEnt.getPreviewLnk(appid, poster)}">${sources}</video>`;
        }
        return `<img src="${stemLnksEnt.getPreviewLnk(appid, poster)}" loading="lazy" alt="">`;
    }
    return '';
}

function getSlotName(item) {
    if (!item) return '';
    if (item.slot_name) return item.slot_name;
    if (item.custom_avatar) return sdsText('customAvatar');
    return item['community_item_data']?.['item_title'] || item['storeName'] || '';
}

function applySidebarLanguage(lang = sidebarLang) {
    sidebarLang = lang === 'en' ? 'en' : 'ru';
    localStorage.setItem('language', sidebarLang);

    SLOT_META.tab1.label = sdsText('slotTheme');
    SLOT_META.tab2.label = sdsText('slotFrame');
    SLOT_META.tab3.label = sdsText('slotAnimBg');
    SLOT_META.tab4.label = sdsText('slotStaticBg');
    SLOT_META.tab5.label = sdsText('slotAvatar');

    Object.entries({
        tab1: sdsText('tab1'),
        tab2: sdsText('tab2'),
        tab3: sdsText('tab3'),
        tab4: sdsText('tab4'),
        tab5: sdsText('tab5')
    }).forEach(([tabId, label]) => {
        const labelNode = document.querySelector(`.tab[data-tab="${tabId}"] span`);
        if (labelNode) labelNode.textContent = label;
    });

    const searchInput = document.querySelector('.sidebar-search');
    if (searchInput) searchInput.placeholder = sdsText('search');

    const filterLabels = document.querySelectorAll('.filter-group-label span');
    if (filterLabels[0]) filterLabels[0].textContent = sdsText('date');
    if (filterLabels[1]) filterLabels[1].textContent = sdsText('popularity');

    Object.entries({
        dateSortBtnUp: sdsText('newest'),
        dateSortBtnDown: sdsText('oldest'),
        popularityBtnDown: sdsText('rare'),
        popularityBtnUp: sdsText('top'),
        favoriteElems: sdsText('favorites')
    }).forEach(([id, label]) => {
        const node = document.querySelector(`#${id} .filter-text`);
        if (node) node.textContent = label;
    });

    const equippedTitle = document.querySelector('.equipped-title');
    if (equippedTitle) equippedTitle.textContent = sdsText('equippedTitle');

    document.querySelectorAll('.reset-btn span:last-child').forEach(node => {
        node.textContent = sdsText('reset');
    });

    const langText = document.querySelector('.sds-lang-text');
    if (langText) langText.textContent = sidebarLang.toUpperCase();

    const themeText = document.querySelector('.sds-theme-text');
    if (themeText) themeText.textContent = sidebarLang === 'ru' ? 'Тема' : 'Theme';
    Object.entries({
        tab2: 'themeFrame',
        tab3: 'themeAnimBg',
        tab4: 'themeStaticBg',
        tab5: 'themeAvatar'
    }).forEach(([tabId, labelKey]) => {
        const item = storedTabData[tabId].currentItem;
        if (!item?.synthetic_theme_item) return;
        const label = sdsText(labelKey);
        item.slot_name = label;
        if (item.community_item_data) {
            item.community_item_data.item_title = label;
        }
    });

    updateEquippedColumn();
}

function updateEquippedColumn() {
    const tabIds = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5'];

    // === 1. Узкое представление (collapsed-view) — список превью вертикально ===
    const collapsed = document.getElementById('collapsedView');
    if (collapsed) {
        collapsed.innerHTML = '';
        const cFrag = document.createDocumentFragment();

        for (const tabId of tabIds) {
            const item = storedTabData[tabId].currentItem;
            const meta = SLOT_META[tabId];

            const slot = document.createElement('div');
            slot.className = 'collapsed-slot' + (item ? '' : ' empty') + (meta.wide ? ' wide' : '');
            slot.dataset.tab = tabId;

            const previewMarkup = item ? getSlotPreviewMarkup(tabId, item) : '';
            const name = item ? getSlotName(item) : sdsText('notSelected');
            const safeLabel = escapeHTML(meta.label);
            const safeName = escapeHTML(name);

            slot.innerHTML = `
                <div class="collapsed-slot-label">${safeLabel}</div>
                <div class="collapsed-slot-preview">${previewMarkup}</div>
                <div class="collapsed-slot-name" title="${safeName}">${safeName}</div>
            `;
            appendEquippedActionButtons(slot.querySelector('.collapsed-slot-preview'), tabId, item);

            // Клик по слоту в узком виде → раскрыть sidebar и открыть вкладку
            slot.addEventListener('click', () => {
                expandSidebarToTab(tabId);
            });

            cFrag.appendChild(slot);
        }

        collapsed.appendChild(cFrag);
    }

    // === 2. Правая колонка в раскрытом виде (equippedList) ===
    const list = document.getElementById('equippedList');
    if (list) {
        list.innerHTML = '';
        const fragment = document.createDocumentFragment();

        for (const tabId of tabIds) {
            const item = storedTabData[tabId].currentItem;
            const meta = SLOT_META[tabId];
            const slot = document.createElement('div');
            slot.className = 'equipped-slot' + (item ? '' : ' empty') + (meta.wide ? ' wide' : '');
            slot.dataset.tab = tabId;

            const previewMarkup = item ? getSlotPreviewMarkup(tabId, item) : '';
            const name = item ? getSlotName(item) : sdsText('notSelected');
            const safeLabel = escapeHTML(meta.label);
            const safeName = escapeHTML(name);

            slot.innerHTML = `
                <div class="equipped-slot-label">${safeLabel}</div>
                <div class="equipped-slot-preview">${previewMarkup}</div>
                <div class="equipped-slot-name" title="${safeName}">${safeName}</div>
            `;

            slot.addEventListener('click', () => {
                activateTab(tabId);
            });

            appendEquippedActionButtons(slot.querySelector('.equipped-slot-preview'), tabId, item);
            fragment.appendChild(slot);
        }

        list.appendChild(fragment);
    }

    updateProfileCost();
}

// Раскрыть sidebar и открыть конкретную вкладку
function activateTab(tabId, forceRefresh = false, options = {}) {
    const targetTabId = tabId || 'tab1';
    const tabBtn = document.querySelector(`.tab[data-tab="${targetTabId}"]`);
    const tabContent = document.getElementById(targetTabId);
    if (!tabBtn || !tabContent) return null;

    const previousContent = document.querySelector('.tab-content.active');
    if (previousContent && previousContent !== tabContent) {
        rememberSidebarState();
    }

    const alreadyActive = tabBtn.classList.contains('active') && tabContent.classList.contains('active');
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t === tabBtn));
    document.querySelectorAll('.tab-content').forEach(content => {
        const shouldBeActive = content === tabContent;
        content.classList.toggle('active', shouldBeActive);
    });

    const paginator = document.querySelector('.paginator');
    if (paginator) paginator.style.display = 'flex';
    sidebarViewState.activeTabId = targetTabId;
    saveSidebarViewState();

    const hasRestoreScroll = Object.prototype.hasOwnProperty.call(options, 'restoreScroll');

    if (!alreadyActive || forceRefresh) {
        setTimeout(() => {
            if (!document.getElementById(targetTabId)?.classList.contains('active')) return;
            setCurrentItem(targetTabId);
            refreshTab(targetTabId, {
                ...(hasRestoreScroll ? { restoreScroll: options.restoreScroll } : {}),
                forceRender: forceRefresh
            });
        }, 75);
    } else if (hasRestoreScroll) {
        restoreTabScrollAfterRender(targetTabId, options.restoreScroll);
    }

    return targetTabId;
}

function ensureActiveTab(defaultTabId = 'tab1') {
    const activeTab = document.querySelector('.tab.active');
    const activeContent = activeTab ? document.getElementById(activeTab.dataset.tab) : null;
    if (activeTab && activeContent?.classList.contains('active')) {
        const paginator = document.querySelector('.paginator');
        if (paginator) paginator.style.display = 'flex';
        return activeTab.dataset.tab;
    }
    return activateTab(defaultTabId, true);
}

let sidebarCloseTimer = null;
let sidebarTransitionTimer = null;

function clearSidebarCloseTimer() {
    if (!sidebarCloseTimer) return;
    clearTimeout(sidebarCloseTimer);
    sidebarCloseTimer = null;
}

function setSidebarMotionClass(sidebar, className, duration = 520) {
    if (!sidebar) return;
    if (sidebarTransitionTimer) {
        clearTimeout(sidebarTransitionTimer);
        sidebarTransitionTimer = null;
    }
    sidebar.classList.remove('is-expanding', 'is-collapsing');
    if (!className) return;
    sidebar.classList.add(className);
    sidebarTransitionTimer = setTimeout(() => {
        sidebar.classList.remove(className);
        sidebarTransitionTimer = null;
    }, duration);
}

function openCollapsedSidebar() {
    const sidebar = document.querySelector(".sidebar");
    if (!sidebar) return;

    clearSidebarCloseTimer();
    setSidebarMotionClass(sidebar, null);
    updateEquippedColumn();
    sidebar.classList.remove('is-open', 'is-closing', 'is-collapsing');
    sidebar.classList.add('is-collapsed');
    isOpen = true;
}

function expandSidebarToTab(tabId) {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;

    const activeTab = document.querySelector('.tab.active');
    const targetTabId = tabId || sidebarViewState.activeTabId || activeTab?.dataset?.tab || 'tab1';

    clearSidebarCloseTimer();
    setSidebarMotionClass(sidebar, 'is-expanding', 540);
    sidebar.classList.remove('is-collapsed', 'is-closing', 'is-collapsing');
    sidebar.classList.add('is-open');
    isOpen = true;

    // Открываем нужную вкладку
    setTimeout(() => {
        restoreSidebarState(targetTabId);
    }, 50);
}

// Свернуть sidebar обратно к узкому виду
function collapseSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;
    if (sidebar.classList.contains('is-closing') || sidebar.classList.contains('is-collapsed')) return;
    clearSidebarCloseTimer();
    rememberSidebarState();
    updateEquippedColumn();
    ensureActiveTab();

    if (sidebarTransitionTimer) {
        clearTimeout(sidebarTransitionTimer);
        sidebarTransitionTimer = null;
    }

    sidebar.classList.remove('is-open', 'is-closing', 'is-expanding', 'is-collapsing');
    sidebar.classList.add('is-collapsed');
    isOpen = true;
}

function hideSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;
    if (!sidebar.classList.contains('is-open') && !sidebar.classList.contains('is-collapsed')) return;

    clearSidebarCloseTimer();
    rememberSidebarState();
    setSidebarMotionClass(sidebar, null);
    sidebar.classList.remove('is-collapsing');
    sidebar.classList.add('is-closing');
    isOpen = false;

    const finish = () => {
        if (!sidebar.classList.contains('is-closing')) return;
        sidebar.classList.remove('is-open', 'is-collapsed', 'is-closing');
        sidebarCloseTimer = null;
    };

    sidebarCloseTimer = setTimeout(finish, 460);
}

function pulseResetButtons(btns) {
    btns.forEach(btn => {
        const original = btn.style.background;
        btn.style.background = 'linear-gradient(135deg, rgba(102, 244, 162, 0.4), rgba(74, 226, 144, 0.4))';
        setTimeout(() => { btn.style.background = original; }, 600);
    });
}

// === Сброс к исходному состоянию ===
// === Сброс к исходному состоянию (без перезагрузки страницы) ===
async function resetToInitial() {
    const btns = [
        document.getElementById('resetEquippedBtn'),
        document.getElementById('resetEquippedBtnExpanded')
    ].filter(Boolean);
    btns.forEach(b => b.disabled = true);

    try {
        const url = removeCustomUrlParams(new URL(window.location.href));
        window.history.replaceState({}, '', url.pathname + (url.search || '') + (url.hash || ''));
        clearPreviewState();
        const preservedBio = initialSnapshot.dom.bioContent?.length
            ? structuredClone(initialSnapshot.dom.bioContent)
            : captureProfileBioContent();

        const restoredFromNetwork = await restoreCleanProfileFromNetwork(url, preservedBio);
        if (restoredFromNetwork) {
            await refreshInitialSnapshotFromCurrentDom();
            init_customization();
            applySidebarLanguage(sidebarLang);
            updateEquippedColumn();
            pulseResetButtons(btns);
            return;
        }

        if (!initialSnapshot.captured) {
            updateEquippedColumn();
            return;
        }

        clearInjectedThemeAssets();

        if (initialSnapshot.dom.htmlClass !== null) {
            document.documentElement.className = initialSnapshot.dom.htmlClass || '';
        }
        if (initialSnapshot.dom.bodyClass !== null) {
            document.body.className = initialSnapshot.dom.bodyClass || '';
        }

        const templateContent = document.getElementById('responsive_page_template_content');
        if (templateContent && initialSnapshot.dom.templateContentHTML) {
            templateContent.outerHTML = initialSnapshot.dom.templateContentHTML;
        } else {
            const backgroundHolder = document.querySelector('#profile_background_holder, .profile_background_holder');
            if (backgroundHolder && initialSnapshot.dom.backgroundHolderHTML) {
                backgroundHolder.outerHTML = initialSnapshot.dom.backgroundHolderHTML;
            }

            const profilePage = document.getElementById('responsive_page_template_content')
                ?.getElementsByClassName('profile_page')?.item(0);

            if (profilePage && initialSnapshot.dom.profilePageHTML) {
                profilePage.outerHTML = initialSnapshot.dom.profilePageHTML;
            } else if (profilePage) {
                const curAnim = profilePage.getElementsByClassName('profile_animated_background').item(0);
                if (curAnim) curAnim.remove();

                clearProfileBackgroundLayout(profilePage);
                profilePage.style.backgroundImage = initialSnapshot.dom.backgroundImage || '';
                if (initialSnapshot.dom.animatedBgHTML) {
                    profilePage.insertAdjacentHTML('afterbegin', initialSnapshot.dom.animatedBgHTML);
                }
            }
        }

        restoreProfileBioContent(preservedBio);

        if (initialSnapshot.dom.frameSrcset !== null) {
            updateFrameElement(findProfileFrameElement(getCurrentProfileScope()), initialSnapshot.dom.frameSrcset);
        }

        if (initialSnapshot.dom.avatarSrcset !== null) {
            updateAvatarMedia(getProfileAvatarPicture(getCurrentProfileScope()) || getProfileAvatarHolder(getCurrentProfileScope()), initialSnapshot.dom.avatarSrcset);
        }

        for (const tabId of ['tab1', 'tab2', 'tab3', 'tab4', 'tab5']) {
            const snap = initialSnapshot.items[tabId];
            storedTabData[tabId].currentItem = snap ? structuredClone(snap) : null;
        }

        init_customization();
        applySidebarLanguage(sidebarLang);
        updateEquippedColumn();

        pulseResetButtons(btns);
    } catch (e) {
        console.error('[SDS] Ошибка сброса:', e);
    } finally {
        btns.forEach(b => b.disabled = false);
    }
}

function getSharedSearchTerm() {
    const searchInput = document.querySelector('.sidebar-search');
    const value = (searchInput?.value || '').trim().toLowerCase();
    return value.length >= 2 ? value : "";
}

function prepareTabQueryState(tabId) {
    const tabState = storedTabData[tabId];
    if (!tabState) return;

    const searchTerm = getSharedSearchTerm();
    if (tabState.querySortType === null && tabState.itemData.length === 0 && tabState.search_word === "") {
        tabState.search_word = searchTerm;
        tabState.querySortType = sortType;
        return;
    }

    if (tabState.search_word !== searchTerm || tabState.querySortType !== sortType) {
        tabState.clear();
        tabState.search_word = searchTerm;
        tabState.querySortType = sortType;
    }
}

function refreshTab(tabId, options = {}) {
    const tabContent = document.getElementById(tabId);
    if (!tabContent) return;
    prepareTabQueryState(tabId);
    const tabState = storedTabData[tabId];
    const renderKey = getTabRenderKey(tabId);
    if (!options.forceRender && tabState.renderKey === renderKey && hasRenderedTabContent(tabId)) {
        update_paginator();
        hydrateLazyMedia(tabContent);
        schedulePrefetchNextPage(tabId);
        if (Object.prototype.hasOwnProperty.call(options, 'restoreScroll')) {
            restoreTabScrollAfterRender(tabId, options.restoreScroll);
        }
        return Promise.resolve();
    }
    return fill_page(tabId).then(() => {
        update_paginator();
        if (Object.prototype.hasOwnProperty.call(options, 'restoreScroll')) {
            restoreTabScrollAfterRender(tabId, options.restoreScroll);
        }
    });
}

const searchHandler = debounce(function(e) {
    const activeTab = document.querySelector('.tab-content.active');
    if(activeTab === null) return;
    refreshTab(activeTab.id);
}, 300);

function isValidSteamProfileUrl(lnk) {
    const patterns = [
        /^https:\/\/steamcommunity\.com\/id\/[a-zA-Z0-9_-]+[\/]?$/,
        /^https:\/\/steamcommunity\.com\/profiles\/[0-9]+[\/]?$/
    ];

    return patterns.some(pattern => pattern.test(lnk));
}

let isOpen = false;

function switch_sidebar_state() {
    const sidebar = document.querySelector(".sidebar");
    if (!sidebar) return;

    const sidebarVisible = sidebar.classList.contains('is-open') || sidebar.classList.contains('is-collapsed');
    if (sidebarVisible && !sidebar.classList.contains('is-closing')) {
        rememberSidebarState();
        hideSidebar();
    } else {
        openCollapsedSidebar();
    }
}

function init_customization() {
    let customBtnFthr = document.querySelector(".profile_header_actions");
    if (!customBtnFthr || document.getElementById("sdsCustomizeBtn")) return;
    if (customBtnFthr.style.display === 'grid') customBtnFthr.style.removeProperty('display');
    if (customBtnFthr.style.gap === '5px') customBtnFthr.style.removeProperty('gap');
    if (window.getComputedStyle(customBtnFthr).position === 'static') {
        customBtnFthr.style.position = 'relative';
    }
    const referenceBtn = customBtnFthr.querySelector('.btn_profile_action');
    let newBtn = document.createElement('a');
    newBtn.id = "sdsCustomizeBtn";
    newBtn.className = "btn_profile_action btn_medium";
    newBtn.href = "javascript:void(0)";
    newBtn.style.cssText = [
        'position: absolute',
        'left: 0',
        'right: auto',
        'top: calc(100% + 8px)',
        'z-index: 20',
        'box-sizing: border-box',
        'margin: 0',
        'white-space: nowrap',
        'overflow: hidden',
        'border-radius: 8px',
        'border: 1px solid rgba(102,192,244,0.35)',
        'background: linear-gradient(135deg, #66c0f4, #3a9fd8)',
        'box-shadow: 0 8px 20px rgba(102,192,244,0.22)'
    ].join(';');
    newBtn.innerHTML = '<span style="color:#062033;font-weight:780;letter-spacing:.01em">Кастомизация</span>'
    newBtn.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        switch_sidebar_state();
    });
    customBtnFthr.insertAdjacentElement('beforeend', newBtn);

    const syncButtonLayout = () => {
        const referenceRect = referenceBtn?.getBoundingClientRect();
        const parentRect = customBtnFthr.getBoundingClientRect();
        if (!referenceRect || referenceRect.width <= 0 || parentRect.width <= 0) return;

        newBtn.style.width = 'auto';
        newBtn.style.height = `${Math.ceil(referenceRect.height)}px`;
        newBtn.style.minHeight = '0';
        newBtn.style.lineHeight = 'normal';

        newBtn.style.left = `${Math.round(referenceRect.left - parentRect.left)}px`;
        newBtn.style.top = `${Math.round(referenceRect.bottom - parentRect.top + 2)}px`;

        const naturalWidth = Math.ceil(newBtn.scrollWidth || newBtn.getBoundingClientRect().width);
        const maxAvailableWidth = Math.max(1, Math.floor(parentRect.right - referenceRect.left));
        const targetWidth = Math.min(
            maxAvailableWidth,
            Math.max(Math.ceil(referenceRect.width), naturalWidth)
        );
        newBtn.style.width = `${targetWidth}px`;
    };

    syncButtonLayout();
    requestAnimationFrame(syncButtonLayout);
    window.addEventListener('resize', syncButtonLayout, { passive: true });
    if (window.ResizeObserver && referenceBtn) {
        const resizeObserver = new ResizeObserver(syncButtonLayout);
        resizeObserver.observe(referenceBtn);
        resizeObserver.observe(customBtnFthr);
        newBtn._sdsResizeObserver = resizeObserver;
    }
}

function getPageCount(tabId) {
    const count = Math.ceil((storedTabData[tabId]?.maxItemsCnt || 0) / cnt_per_page);
    return Math.max(1, count);
}

function update_paginator() {
    let curPageBtn = document.getElementById("pag_button_cur");
    let endPageBtn = document.getElementById("pag_button_end");
    let pageInput = document.getElementById("pag_page_input");
    let activeTab = document.querySelector('.tab.active');

    if (curPageBtn === null || endPageBtn === null || activeTab === null) return;

    const tabId = activeTab.dataset.tab;
    const pageCount = getPageCount(tabId);
    const currentPage = Math.min(storedTabData[tabId].currentPage, pageCount - 1);
    storedTabData[tabId].currentPage = currentPage;

    if(currentPage === 0){
        document.querySelector('#paginator_btn_prev').disabled = true; 
    }else{
        document.querySelector('#paginator_btn_prev').disabled = false;
    }
    
    if(currentPage >= pageCount - 1){
        document.querySelector('#paginator_btn_next').disabled = true;
    }else{
        document.querySelector('#paginator_btn_next').disabled = false;
    }

    curPageBtn.textContent = currentPage + 1;
    endPageBtn.textContent = pageCount;
    if (pageInput && document.activeElement !== pageInput) {
        pageInput.value = '';
        pageInput.placeholder = '...';
    }
}

async function goToPage(pageNumber) {
    const activeContent = document.querySelector('.tab-content.active');
    if (!activeContent) return;
    const tabId = activeContent.id;
    const pageCount = getPageCount(tabId);
    const normalizedPage = parseInt(pageNumber, 10);
    if (!Number.isFinite(normalizedPage)) return;

    const targetPage = Math.min(Math.max(normalizedPage, 1), pageCount) - 1;
    if (targetPage === storedTabData[tabId].currentPage) {
        update_paginator();
        return;
    }

    document.querySelector('#paginator_btn_prev').disabled = true;
    document.querySelector('#paginator_btn_next').disabled = true;
    storedTabData[tabId].currentPage = targetPage;
    activeContent.scrollTop = 0;
    await fill_page(tabId);
    update_paginator();
    rememberSidebarState();
}

function movePage(isTowards = true){
    let page_step = 1 - 2 * (isTowards === false);
    let curTabId = document.querySelector('.tab-content.active').id;
    goToPage(storedTabData[curTabId].currentPage + page_step + 1);
}

function getButtonIdForSortType(type) {
    if (type === 0) return 'dateSortBtnUp';
    if (type === 1) return 'dateSortBtnDown';
    if (type === 3) return 'popularityBtnUp';
    if (type === 4) return 'popularityBtnDown';
    if (type === 5) return 'favoriteElems';
    return DEFAULT_SORT_BUTTON_ID;
}

function setSortType(nextSortType) {
    sortType = nextSortType;
    document.querySelectorAll('.action-btn').forEach(btn => btn.classList.remove('active'));
    const activeButton = document.getElementById(getButtonIdForSortType(sortType));
    if (activeButton) activeButton.classList.add('active');

    const favoriteBtn = document.getElementById('favoriteElems');
    if (favoriteBtn) {
        favoriteBtn.title = sortType === 5
            ? (sidebarLang === 'ru' ? 'Включено: показываются только избранные' : 'Enabled: showing favorites only')
            : (sidebarLang === 'ru' ? 'Показать только избранные' : 'Show favorites only');
    }
}

async function initProfileCustomisationItems() {
    // 0. Пытаемся загрузить snapshot из localStorage.
    //    Если он там есть — это значит, что мы уже снимали "чистый" снимок
    //    при первом заходе на профиль, и теперь его надо просто использовать
    //    (актуально после relocate из replaceTheme — страница перезагружается,
    //    в storedTabData попадает уже изменённое состояние, поэтому захватывать
    //    его повторно нельзя).
    const snapshotLoaded = loadSnapshotFromStorage();

    try {
        await getLnkSettings();
    } catch (error) {
        console.debug('[SDS] Link settings load failed:', error);
    }
    try {
        await getProfileItems();
    } catch (error) {
        console.debug('[SDS] Profile items load failed:', error);
    }
    ensureCurrentAvatarFromDom({ preferDomWhenMissing: true, enrichExisting: true });
    if (snapshotLoaded && !initialSnapshot.items.tab5 && storedTabData['tab5'].currentItem) {
        initialSnapshot.items.tab5 = structuredClone(storedTabData['tab5'].currentItem);
        saveSnapshotToStorage();
    }
    const initUrlParams = new URL(window.location.href).searchParams;
    const initHasOurParams = CUSTOM_URL_PARAMS.some(p => initUrlParams.has(p));

    // Если snapshot не был загружен из storage — значит это первое посещение
    // профиля в этой "сессии". Снимаем новый снимок, но только если URL чистый
    // (нет наших параметров). Иначе мы зафиксируем уже изменённое состояние.
    if (!snapshotLoaded) {
        const urlParams = new URL(window.location.href).searchParams;
        const hasOurParams = CUSTOM_URL_PARAMS.some(p => urlParams.has(p));
        if (!hasOurParams) {
            captureInitialSnapshot();
        }
    }

    if (!initHasOurParams) {
        clearPreviewState();
    }

    if(initHasOurParams && storedTabData['tab1'].currentItem !== null){
        const activeTheme = storedTabData['tab1'].currentItem;
        await applySteamProfileTheme(
            activeTheme['appid'],
            activeTheme['defid'],
            buildThemePreviewUrl(activeTheme['appid'], activeTheme['defid'], getThemeItemType(activeTheme)),
            activeTheme,
            { persist: false }
        );
    }

    const existItems = structuredClone(storedTabData);
    for(const [key, elem] of Object.entries(existItems)){
        if(elem.currentItem !== null){
            if (elem.currentItem.synthetic_theme_item) continue;
            if (elem.currentItem.custom_avatar) {
                const customAvatarSrc = elem.currentItem['community_item_data']?.['item_image_small'];
                if (customAvatarSrc) applyCustomAvatar(customAvatarSrc);
                continue;
            }
            if (!elem.currentItem['appid'] || !elem.currentItem['defid'] || !elem.currentItem['community_item_data']) continue;
            if(key === 'tab2'){
                await replaceFrame(stemLnksEnt.getProfileLnk(elem.currentItem['appid'], elem.currentItem['community_item_data']['item_image_small']), elem.currentItem['defid'], elem.currentItem, { persist: false })
            }
            else if(key === 'tab3'){
                await replaceAnimBG(stemLnksEnt.getProfileLnk(elem.currentItem['appid'], elem.currentItem['community_item_data']['item_movie_webm']), 
                                stemLnksEnt.getProfileLnk(elem.currentItem['appid'], elem.currentItem['community_item_data']['item_image_large']),
                                elem.currentItem['defid'],
                                elem.currentItem,
                                { persist: false });
            }
            else if(key === 'tab4'){
                await replaceStaticBG(stemLnksEnt.getProfileLnk(elem.currentItem['appid'], elem.currentItem['community_item_data']['item_image_large']),
                                elem.currentItem['defid'],
                                elem.currentItem,
                                { persist: false });
            }else if(key === 'tab5'){
                await replaceAvatar(getAvatarPosterUrl(elem.currentItem) || stemLnksEnt.getProfileLnk(elem.currentItem['appid'], elem.currentItem['community_item_data']['item_image_small']),
                    elem.currentItem['defid'],
                    elem.currentItem,
                    { persist: false });
            }
        }
    }

    // Обновляем правую колонку (надетое сейчас)
    updateEquippedColumn();
}

function init() {
    let hrefToTest = new URL(location.href);
    hrefToTest.search = "";

    if (isValidSteamProfileUrl(hrefToTest.href) == false)
        return;

    document.querySelector('body').insertAdjacentHTML('beforebegin', css_part + html_part);
    applyPreviewUITheme(currentPreviewUITheme, { persist: false });
    safeChromeStorageGet({ uiTheme: 'default' }, ({ uiTheme }) => {
        if (uiTheme && uiTheme !== currentPreviewUITheme) {
            applyPreviewUITheme(uiTheme, { persist: false });
        }
    });
    safeChromeStorageOnChanged((changes, areaName) => {
        if (areaName !== 'local' || !changes.uiTheme) return;
        // Profile sidebar uses a single shared SteamShowcase theme.
        applyPreviewUITheme('default', { persist: false });
    });
    applySidebarLanguage(sidebarLang);
    window.addEventListener('beforeunload', rememberSidebarState);
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') {
            rememberSidebarState();
        }
    });

    initProfileCustomisationItems().then(() => {
        init_customization();
    }).catch((error) => {
        console.debug('[SDS] Initial customization load failed:', error);
        init_customization();
        updateEquippedColumn();
    });

    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', function () {
            rememberSidebarState();
            activateTab(this.dataset.tab);
        });
    });

    document.querySelectorAll('.tab-content').forEach((content) => {
        content.addEventListener('scroll', debounce(() => {
            rememberSidebarState();
            hydrateLazyMedia(content);
        }, 120), { passive: true });
    });

    const langSwitch = document.getElementById('sdsLangSwitch');
    if (langSwitch) {
        langSwitch.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            const activeContentId = document.querySelector('.tab-content.active')?.id;
            Object.values(storedTabData).forEach((tabState) => tabState.clear());
            applySidebarLanguage(sidebarLang === 'ru' ? 'en' : 'ru');
            setSortType(sortType);
            if (activeContentId) {
                refreshTab(activeContentId);
            }
        });
    }

    // Single SteamShowcase UI theme — no switcher on profile sidebar.

    const searchInput = document.querySelector('.sidebar-search');
    searchInput.addEventListener('focus', function () {
        this.parentElement.style.zIndex = '1001';
    });

    searchInput.addEventListener('blur', function () {
        this.parentElement.style.zIndex = 'auto';
    });

    searchInput.addEventListener('input', searchHandler);

    document.querySelector('#paginator_btn_prev').addEventListener("click", function (event) {
        movePage(false);
    });
    document.querySelector('#paginator_btn_next').addEventListener("click", function (event) {
        movePage(true);
    });
    document.querySelector('#pag_button_end').addEventListener("click", function () {
        const activeTab = document.querySelector('.tab.active');
        if (!activeTab) return;
        goToPage(getPageCount(activeTab.dataset.tab));
    });
    const pageInput = document.getElementById('pag_page_input');
    if (pageInput) {
        const submitPageInput = () => {
            const page = parseInt(pageInput.value, 10);
            pageInput.value = '';
            if (Number.isFinite(page)) {
                goToPage(page);
            }
        };
        pageInput.addEventListener('click', (event) => {
            event.stopPropagation();
            pageInput.select();
        });
        pageInput.addEventListener('keydown', (event) => {
            event.stopPropagation();
            if (event.key !== 'Enter') return;
            event.preventDefault();
            submitPageInput();
            pageInput.blur();
        });
        pageInput.addEventListener('blur', () => {
            submitPageInput();
        });
        pageInput.addEventListener('change', submitPageInput);
        pageInput.addEventListener('input', () => {
            pageInput.value = pageInput.value.replace(/[^\d]/g, '');
        });
    }

    // === Фильтры сортировки (с учётом группировки: дата ↑/↓, популярность ↑/↓, ★) ===
    document.querySelectorAll('.action-btn').forEach(filter => {
        filter.addEventListener('click', function () {
            if (this.id === "favoriteElems" && sortType === 5) {
                setSortType(DEFAULT_SORT_TYPE);
            } else if (this.id === "popularityBtnUp") {
                setSortType(3);
            } else if (this.id === "popularityBtnDown") {
                setSortType(4);
            } else if (this.id === "dateSortBtnDown") {
                setSortType(1);
            } else if (this.id === "dateSortBtnUp") {
                setSortType(0);
            } else if (this.id === "favoriteElems") {
                setSortType(5);
            }

            const activeTab = document.querySelector('.tab-content.active');
            if (activeTab === null) return;
            refreshTab(activeTab.id);
        });
    });

    // === Кнопки "Сброс" (и в свёрнутом, и в раскрытом виде) ===
    ['resetEquippedBtn', 'resetEquippedBtnExpanded'].forEach(id => {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.addEventListener('click', async (event) => {
            event.stopPropagation();
            await resetToInitial();
        });
    });

    const sidebar = document.querySelector('.sidebar');
    let sidebarLeaveTimer = null;
    if (sidebar) {
        sidebar.addEventListener('mouseenter', () => {
            if (sidebarLeaveTimer) {
                clearTimeout(sidebarLeaveTimer);
                sidebarLeaveTimer = null;
            }
            if (sidebar.classList.contains('is-collapsed')) {
                expandSidebarToTab();
            }
        });

        sidebar.addEventListener('mouseleave', () => {
            if (sidebar.classList.contains('is-closing')) return;
            if (!sidebar.classList.contains('is-open')) return;
            sidebarLeaveTimer = setTimeout(() => {
                if (!sidebar.matches(':hover')) {
                    collapseSidebar();
                }
            }, 260);
        });
    }

    document.addEventListener('pointerdown', (event) => {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar?.classList.contains('is-closing')) return;
        if (!sidebar || !sidebar.classList.contains('is-open')) return;
        if (sidebar.contains(event.target)) return;
        if (event.target.closest('#sdsCustomizeBtn')) return;
        collapseSidebar();
    }, true);

    setSortType(DEFAULT_SORT_TYPE);
}

init();
