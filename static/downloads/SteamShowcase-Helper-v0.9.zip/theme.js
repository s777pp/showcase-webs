// Расширенная система тем с анимациями и эффектами (без волн)
const THEMES = {
    default: {
        name: "Steam Ocean",
        icon: "fa-palette",
        colors: {
            primaryBg: "linear-gradient(135deg, #0a1520, #132536, #0a1520)",
            primaryText: "rgba(255, 255, 255, 0.97)",
            accentColor: "#66c0f4",
            accentHover: "#8fd3ff",
            accentGradient: "linear-gradient(135deg, #66c0f4, #4a90e2)",
            accentGradientHover: "linear-gradient(135deg, #7acdff, #5b9df5)",
            cardBg: "rgba(31, 58, 78, 0.35)",
            cardBorder: "1px solid rgba(102, 192, 244, 0.25)",
            glowColor: "rgba(102, 192, 244, 0.4)",
            particleColor: "rgba(102, 192, 244, 0.15)"
        },
        animations: {
            bgAnimation: "waveFlow 15s ease infinite",
            particleType: "bubbles"
        }
    },
    cyberpunk: {
        name: "Neon Pink",
        icon: "fa-moon",
        colors: {
            primaryBg: "linear-gradient(135deg, #1a1a2e, #16213e, #0f3460)",
            primaryText: "#f8f8f8",
            accentColor: "#ff2a6d",
            accentHover: "#ff7aa2",
            accentGradient: "linear-gradient(135deg, #ff2a6d, #d53b8c)",
            accentGradientHover: "linear-gradient(135deg, #ff7aa2, #ff2a6d)",
            cardBg: "rgba(30, 30, 60, 0.5)",
            cardBorder: "1px solid rgba(212, 59, 140, 0.3)",
            glowColor: "rgba(255, 42, 109, 0.5)",
            particleColor: "rgba(255, 42, 109, 0.2)"
        },
        animations: {
            bgAnimation: "cyberScan 12s linear infinite",
            particleType: "digitalRain"
        }
    },
    darkNeon: {
        name: "Cyber Green",
        icon: "fa-star",
        colors: {
            primaryBg: "linear-gradient(135deg, #0d0221, #240046, #0d0221)",
            primaryText: "#e2f3f5",
            accentColor: "#00f5d4",
            accentHover: "#72efdd",
            accentGradient: "linear-gradient(135deg, #00f5d4, #00bbf9)",
            accentGradientHover: "linear-gradient(135deg, #72efdd, #00f5d4)",
            cardBg: "rgba(41, 10, 65, 0.4)",
            cardBorder: "1px solid rgba(0, 245, 212, 0.25)",
            glowColor: "rgba(0, 245, 212, 0.4)",
            particleColor: "rgba(0, 245, 212, 0.15)"
        },
        animations: {
            bgAnimation: "matrixFlow 18s linear infinite",
            particleType: "hexagons"
        }
    },
    sunset: {
        name: "Sunset Orange",
        icon: "fa-sun",
        colors: {
            primaryBg: "linear-gradient(135deg, #0f0c29, #302b63, #24243e)",
            primaryText: "rgba(255, 255, 255, 0.95)",
            accentColor: "#ff7b25",
            accentHover: "#ff9e53",
            accentGradient: "linear-gradient(135deg, #ff7b25, #ff512f)",
            accentGradientHover: "linear-gradient(135deg, #ff9e53, #ff7b25)",
            cardBg: "rgba(63, 43, 86, 0.4)",
            cardBorder: "1px solid rgba(255, 123, 37, 0.25)",
            glowColor: "rgba(255, 123, 37, 0.4)",
            particleColor: "rgba(255, 123, 37, 0.15)"
        },
        animations: {
            bgAnimation: "sunsetPulse 20s ease infinite",
            particleType: "embers"
        }
    }
};

// Анимации фона
const BG_ANIMATIONS = {
    waveFlow: `
        @keyframes waveFlow {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
    `,
    cyberScan: `
        @keyframes cyberScan {
            0% { background-position: 0 0; }
            100% { background-position: 0 100vh; }
        }
    `,
    matrixFlow: `
        @keyframes matrixFlow {
            0% { background-position: 0% 0%; }
            100% { background-position: 100% 100%; }
        }
    `,
    sunsetPulse: `
        @keyframes sunsetPulse {
            0% { background-size: 100% 100%; }
            50% { background-size: 150% 150%; }
            100% { background-size: 100% 100%; }
        }
    `
};

// Применение темы с анимациями
function applyTheme(themeName) {
    const theme = THEMES[themeName] || THEMES.default;
    const root = document.documentElement;
    
    // Применяем цвета
    Object.entries(theme.colors).forEach(([key, value]) => {
        root.style.setProperty(`--${key}`, value);
    });
    
    // Добавляем анимацию фона
    const styleId = 'theme-bg-animation';
    let styleElement = document.getElementById(styleId);
    
    if (!styleElement) {
        styleElement = document.createElement('style');
        styleElement.id = styleId;
        document.head.appendChild(styleElement);
    }
    
    styleElement.textContent = BG_ANIMATIONS[theme.animations.bgAnimation];
    document.body.style.animation = theme.animations.bgAnimation;
    
    // Обновляем частицы
    updateParticles(theme.animations.particleType);
    
    // Обновляем иконку кнопки темы
    const themeButton = document.getElementById('theme-button');
    if (themeButton) {
        const icon = themeButton.querySelector('i');
        if (icon) {
            icon.className = `fas ${theme.icon}`;
            themeButton.setAttribute('aria-label', `Тема: ${theme.name}`);
        }
    }
    
    localStorage.setItem('selectedTheme', themeName);
    playThemeTransition();
}

// Анимация перехода между темами
function playThemeTransition() {
    const cards = document.querySelectorAll('.card');
    const logo = document.querySelector('.logo-inner');
    
    // Анимация "вспышка"
    document.body.style.opacity = '0.7';
    setTimeout(() => {
        document.body.style.opacity = '1';
        document.body.style.transition = 'opacity 0.5s ease';
    }, 100);
    
    // Анимация карточек
    cards.forEach((card, index) => {
        card.style.transform = 'translateY(20px) rotateX(15deg)';
        card.style.opacity = '0';
        card.style.transition = `all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) ${index * 0.1}s`;
        
        setTimeout(() => {
            card.style.transform = 'translateY(0) rotateX(0)';
            card.style.opacity = '1';
        }, 100 + index * 50);
    });
    
    // Анимация логотипа
    if (logo) {
        logo.style.transform = 'scale(0.8) rotate(180deg)';
        logo.style.opacity = '0';
        logo.style.transition = 'all 0.7s cubic-bezier(0.68, -0.55, 0.265, 1.55)';
        
        setTimeout(() => {
            logo.style.transform = 'scale(1) rotate(0)';
            logo.style.opacity = '1';
        }, 300);
    }
}

// Обновление частиц
function updateParticles(type) {
    const container = document.querySelector('.particles-container');
    if (!container) return;
    
    container.innerHTML = '';
    
    const particleCount = type === 'digitalRain' ? 100 : 50;
    
    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.background = `var(--particleColor)`;
        
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.top = `${Math.random() * 120}%`;
        
        container.appendChild(particle);
    }
}

// Инициализация темы
function initTheme() {
    const savedTheme = localStorage.getItem('selectedTheme') || 'default';
    
    const themeButton = document.getElementById('theme-button');
    if (themeButton) {
        themeButton.addEventListener('click', () => {
            const themes = Object.keys(THEMES);
            const currentIndex = themes.indexOf(localStorage.getItem('selectedTheme') || 'default');
            const nextIndex = (currentIndex + 1) % themes.length;
            applyTheme(themes[nextIndex]);
            
            themeButton.style.transform = 'scale(0.8) rotate(90deg)';
            setTimeout(() => {
                themeButton.style.transform = 'scale(1.1) rotate(0)';
                setTimeout(() => {
                    themeButton.style.transform = 'scale(1)';
                }, 100);
            }, 100);
        });
    }
    
    applyTheme(savedTheme);
}

document.addEventListener('DOMContentLoaded', initTheme);