(() => {
  if (window.__sdsContentButton1Loaded) return;
  window.__sdsContentButton1Loaded = true;

  const TOOL_NAME = 'artwork';

  async function readActiveTool() {
    try {
      if (chrome?.storage?.session?.get) {
        const sessionData = await chrome.storage.session.get('sshActiveTool');
        if (sessionData?.sshActiveTool) return sessionData.sshActiveTool;
      }
      if (chrome?.storage?.local?.get) {
        const localData = await chrome.storage.local.get('sshActiveTool');
        if (localData?.sshActiveTool) return localData.sshActiveTool;
      }
    } catch (error) {
      console.warn('[SSH] active tool lookup failed', error);
    }
    return null;
  }

  function clearActiveTool() {
    try {
      chrome?.storage?.session?.remove?.('sshActiveTool');
      chrome?.storage?.local?.remove?.('sshActiveTool');
    } catch (error) {}
  }

  async function shouldRun() {
    const active = await readActiveTool();
    // Direct navigation fallback: artwork/workshop/guide content scripts may run without popup flag.
    if (!active) return TOOL_NAME !== 'screenshot';
    return active === TOOL_NAME;
  }

const CONFIG = {
  widthValue: '1000',
  heightValue: '1',
  titleValue: ' ᠌᠌ ᠌᠌ ᠌᠌ ᠌᠌ ᠌᠌ ᠌',
  maxRetries: 20,
  retryInterval: 500,
  bannerImageUrl: chrome.runtime.getURL('./company_links/main.gif'),
  bannerLink: 'https://t.me/SteamMakerBot',
};

const SELECTORS = {
  widthInput: '#image_width',
  heightInput: '#image_height',
  titleInput: '#title',
  agreeTermsCheckbox: '#agree_terms',
  imagePreview: '#PreviewImage',
  titleBlock: '.detailBox.collection .titleField',
  imageBlock: '.imagesizepreview',
};

/**
 * Проверяет, применены ли значения из конфигурации.
 * @returns {boolean} True, если значения применены, иначе false.
 */
function areValuesApplied() {
  const { widthInput, heightInput, titleInput, agreeTermsCheckbox } = SELECTORS;
  const elements = {
    width: document.querySelector(widthInput),
    height: document.querySelector(heightInput),
    title: document.querySelector(titleInput),
    agreeTerms: document.querySelector(agreeTermsCheckbox),
  };

  if (Object.values(elements).every(el => el !== null)) {
    return (
      elements.width.value === CONFIG.widthValue &&
      elements.height.value === CONFIG.heightValue &&
      elements.title.value === CONFIG.titleValue &&
      elements.agreeTerms.checked === true
    );
  }
  return false;
}

/**
 * Применяет значения из конфигурации к элементам формы.
 * @returns {boolean} True, если значения успешно применены, иначе false.
 */
function applyValues() {
  const { widthInput, heightInput, titleInput, agreeTermsCheckbox } = SELECTORS;
  const elements = {
    width: document.querySelector(widthInput),
    height: document.querySelector(heightInput),
    title: document.querySelector(titleInput),
    agreeTerms: document.querySelector(agreeTermsCheckbox),
  };

  if (Object.values(elements).every(el => el !== null)) {
    elements.width.value = CONFIG.widthValue;
    elements.height.value = CONFIG.heightValue;
    elements.title.value = CONFIG.titleValue;
    elements.agreeTerms.checked = true;

    console.log('Значения применены.');
    return true;
  }
  console.log('Элементы не найдены.');
  return false;
}

/**
 * Повторяет попытки применения значений с интервалом.
 * @param {number} maxRetries - Максимальное количество попыток.
 * @param {number} interval - Интервал между попытками в миллисекундах.
 */
function retryApplyValues(maxRetries, interval) {
  let retries = 0;

  const intervalId = setInterval(() => {
    if (applyValues() || retries >= maxRetries) {
      clearInterval(intervalId);
      console.log(retries >= maxRetries ? 'Достигнуто максимальное количество попыток.' : 'Значения успешно применены.');
    }
    retries++;
  }, interval);
}

/**
 * Отслеживает загрузку изображения и проверяет значения.
 */
function observeImageLoad() {
  const { imagePreview } = SELECTORS;
  const imageElement = document.querySelector(imagePreview);

  if (imageElement) {
    const observer = new MutationObserver((mutationsList) => {
      for (const mutation of mutationsList) {
        if (mutation.type === 'attributes' && mutation.attributeName === 'src') {
          console.log('Изображение загружено, проверка значений...');
          if (!areValuesApplied()) {
            console.log('Значения сброшены, повторное применение...');
            retryApplyValues(CONFIG.maxRetries, CONFIG.retryInterval);
          }
        }
      }
    });

    observer.observe(imageElement, { attributes: true });
  } else {
    console.log('Элемент превью изображения не найден, повторная попытка...');
    setTimeout(observeImageLoad, CONFIG.retryInterval);
  }
}

/**
 * Добавляет рекламный баннер на страницу.
 */
function addBanner() {
  const { titleBlock, imageBlock } = SELECTORS;
  const titleElement = document.querySelector(titleBlock)?.closest('.detailBox.collection');
  const imageElement = document.querySelector(imageBlock)?.closest('.detailBox.collection');

  if (titleElement && imageElement && !document.querySelector('.ad-banner')) {
    const banner = document.createElement('div');
    banner.className = "detailBox collection";
    const bannerInner = document.createElement('div');
    bannerInner.className = 'ad-banner';
    const link = document.createElement('a');
    link.href = CONFIG.bannerLink;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    const img = document.createElement('img');
    img.src = CONFIG.bannerImageUrl;
    img.alt = 'Рекламный баннер';
    link.appendChild(img);
    bannerInner.appendChild(link);
    banner.appendChild(bannerInner);
    titleElement.insertAdjacentElement('afterend', banner);
  }
}

/**
 * Добавляет стили для рекламного баннера.
 */
function addBannerStyles() {
  if (!document.querySelector('style[data-banner-styles]')) {
    const styleSheet = document.createElement('style');
    styleSheet.type = 'text/css';
    styleSheet.setAttribute('data-banner-styles', 'true');
    styleSheet.textContent = `
      .ad-banner {
        margin: 10px 0 14px;
      }
      .ad-banner img {
        display: block;
        max-width: 100%;
        height: auto;
        cursor: pointer;
        border-radius: 12px;
        box-shadow: 0 10px 24px rgba(0,0,0,.25);
      }
    `;
    document.head.appendChild(styleSheet);
  }
}

/**
 * Инициализирует скрипт.
 */
async function init() {
  if (!(await shouldRun())) return;
  clearActiveTool();

  if (typeof MutationObserver === 'undefined') {
    console.error('MutationObserver not supported');
    return;
  }

  retryApplyValues(CONFIG.maxRetries, CONFIG.retryInterval);
  observeImageLoad();
  addBanner();
  addBannerStyles();

  // Лёгкий observer: только если форма сбросилась
  try {
    let scheduled = false;
    const observer = new MutationObserver(() => {
      if (scheduled || areValuesApplied()) return;
      scheduled = true;
      setTimeout(() => {
        scheduled = false;
        if (!areValuesApplied()) applyValues();
      }, 250);
    });
    observer.observe(document.body, { childList: true, subtree: false });
  } catch (error) {
    console.error('Error setting up MutationObserver:', error);
  }
}

// Запуск инициализации
if (document.readyState === 'complete' || document.readyState === 'interactive') {
  setTimeout(init, 100);
} else {
  document.addEventListener('DOMContentLoaded', init);
}

})();
