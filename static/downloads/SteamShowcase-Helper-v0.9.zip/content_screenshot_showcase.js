var sdsScreenshotUpload = (function () {
  if (window.__sdsScreenshotUploadInitialized) return null;
  window.__sdsScreenshotUploadInitialized = true;

  var titleValue = ' ᠌᠌ ᠌᠌ ᠌᠌ ᠌᠌ ᠌᠌ ᠌';
  var bannerImageUrl = chrome.runtime.getURL('./company_links/main.gif');
  var bannerLink = 'https://t.me/SteamMakerBot';
  var cachedWidthInput = null;
  var cachedHeightInput = null;

  function readActiveTool() {
    return new Promise(function (resolve) {
      try {
        if (chrome?.storage?.session?.get) {
          chrome.storage.session.get('sshActiveTool', function (sessionData) {
            if (sessionData?.sshActiveTool) return resolve(sessionData.sshActiveTool);
            if (chrome?.storage?.local?.get) {
              chrome.storage.local.get('sshActiveTool', function (localData) {
                resolve(localData?.sshActiveTool || null);
              });
            } else {
              resolve(null);
            }
          });
          return;
        }
        if (chrome?.storage?.local?.get) {
          chrome.storage.local.get('sshActiveTool', function (localData) {
            resolve(localData?.sshActiveTool || null);
          });
          return;
        }
      } catch (error) {
        console.warn('[SSH] screenshot tool lookup failed', error);
      }
      resolve(null);
    });
  }

  function clearActiveTool() {
    try {
      chrome?.storage?.session?.remove?.('sshActiveTool');
      chrome?.storage?.local?.remove?.('sshActiveTool');
    } catch (error) {}
  }

  function setValue(element, value) {
    if (!element) return false;
    element.value = value;
    element.setAttribute('value', value);
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function getCachedInput(selector, cacheKey) {
    var freshElement = document.querySelector(selector);
    if (freshElement) {
      if (cacheKey === 'width') cachedWidthInput = freshElement;
      if (cacheKey === 'height') cachedHeightInput = freshElement;
      return freshElement;
    }
    if (cacheKey === 'width') return cachedWidthInput && cachedWidthInput.isConnected ? cachedWidthInput : null;
    if (cacheKey === 'height') return cachedHeightInput && cachedHeightInput.isConnected ? cachedHeightInput : null;
    return null;
  }

  function apply() {
    var imageWidth = getCachedInput('#image_width', 'width');
    var imageHeight = getCachedInput('#image_height', 'height');
    var title = document.querySelector('#title, [name="title"], [name=title]');
    var agreeTerms = document.querySelector('#agree_terms, [name="agree_terms"], [name=agree_terms]') || document.querySelector('input[type="checkbox"]');

    if (imageWidth) {
      setValue(imageWidth, '1000');
      // Steam sometimes reverts by id; keep the node but mark as managed.
      imageWidth.dataset.sshManaged = '1';
    }
    if (imageHeight) {
      setValue(imageHeight, '1');
      imageHeight.dataset.sshManaged = '1';
    }
    document.querySelectorAll('[name="file_type"], [name=file_type]').forEach(function (fileType) {
      setValue(fileType, '5');
    });
    if (title) setValue(title, titleValue);
    if (agreeTerms) {
      agreeTerms.checked = true;
      agreeTerms.defaultChecked = true;
      agreeTerms.setAttribute('checked', 'checked');
      agreeTerms.dispatchEvent(new Event('input', { bubbles: true }));
      agreeTerms.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  function addBanner() {
    var titleNode = document.querySelector('.detailBox.collection .titleField');
    var imageNode = document.querySelector('.imagesizepreview');
    var titleElement = titleNode ? titleNode.closest('.detailBox.collection') : null;
    var imageElement = imageNode ? imageNode.closest('.detailBox.collection') : null;

    if (titleElement && imageElement && !document.querySelector('.ad-banner')) {
      var banner = document.createElement('div');
      var bannerInner = document.createElement('div');
      var link = document.createElement('a');
      var img = document.createElement('img');

      banner.className = 'detailBox collection';
      bannerInner.className = 'ad-banner';
      link.href = bannerLink;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      img.src = bannerImageUrl;
      img.alt = 'Steam Profile Design';

      link.appendChild(img);
      bannerInner.appendChild(link);
      banner.appendChild(bannerInner);
      titleElement.insertAdjacentElement('afterend', banner);
    }
  }

  function addBannerStyles() {
    if (document.querySelector('style[data-banner-styles]')) return;
    var styleSheet = document.createElement('style');
    styleSheet.type = 'text/css';
    styleSheet.setAttribute('data-banner-styles', 'true');
    styleSheet.textContent = [
      '.ad-banner { margin: 10px 0 14px; }',
      '.ad-banner img { display: block; max-width: 100%; height: auto; cursor: pointer; border-radius: 12px; }'
    ].join('\n');
    document.head.appendChild(styleSheet);
  }

  function retryApply() {
    var retries = 0;
    var intervalId = setInterval(function () {
      apply();
      retries += 1;
      if (retries >= 20) clearInterval(intervalId);
    }, 500);
  }

  function bindGuards() {
    document.addEventListener('submit', apply, true);
    document.addEventListener('click', function (event) {
      if (event.target.closest('input[type="submit"], button[type="submit"], .btn_green_steamui, .btn_medium')) {
        apply();
      }
    }, true);
  }

  async function init() {
    var active = await readActiveTool();
    if (active && active !== 'screenshot') return;
    apply();
    addBanner();
    addBannerStyles();
    retryApply();
    bindGuards();
    clearActiveTool();

    var scheduled = false;
    new MutationObserver(function () {
      if (scheduled) return;
      scheduled = true;
      setTimeout(function () {
        scheduled = false;
        apply();
        addBanner();
      }, 250);
    }).observe(document.body, { childList: true, subtree: false });
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(init, 100);
  } else {
    document.addEventListener('DOMContentLoaded', init);
  }

  return { apply: apply };
})();
