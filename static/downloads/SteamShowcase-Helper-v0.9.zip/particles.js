document.addEventListener('DOMContentLoaded', function() {
    const container = document.querySelector('.particles-container');
    if (!container) return;

    const particleCount = 28;
    const types = ['circle', 'line'];
    const colors = [
        'rgba(102, 192, 244, 0.3)',
        'rgba(102, 192, 244, 0.2)',
        'rgba(102, 192, 244, 0.15)',
        'rgba(255, 255, 255, 0.15)',
        'rgba(200, 230, 255, 0.2)'
    ];
    
    // Создаем градиентный фон
    container.style.background = 'none';
    
    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.classList.add('particle');
        
        // Случайные параметры
        const size = Math.random() * 16 + 4;
        const posX = Math.random() * 100;
        const posY = Math.random() * 120 + 100;
        const delay = Math.random() * 20;
        const duration = Math.random() * 25 + 15;
        const color = colors[Math.floor(Math.random() * colors.length)];
        const type = types[Math.floor(Math.random() * types.length)];
        const rotation = Math.random() * 360;
        const blur = Math.random() * 3 + 1;
        const opacity = Math.random() * 0.22 + 0.06;
        
        particle.style.width = `${size}px`;
        particle.style.height = type === 'line' ? '2px' : `${size}px`;
        particle.style.left = `${posX}%`;
        particle.style.top = `${posY}%`;
        particle.style.animationDelay = `${delay}s`;
        particle.style.animationDuration = `${duration}s`;
        particle.style.opacity = opacity;
        particle.style.background = color;
        particle.style.filter = `blur(${blur}px)`;
        particle.style.transform = `rotate(${rotation}deg)`;
        particle.style.animationTimingFunction = 'cubic-bezier(0.4, 0, 0.2, 1)';
        
        // Разные формы частиц
        if (type === 'triangle') {
            particle.style.clipPath = 'polygon(50% 0%, 0% 100%, 100% 100%)';
            particle.style.background = 'transparent';
            particle.style.borderBottom = `${size}px solid ${color}`;
            particle.style.borderLeft = `${size/2}px solid transparent`;
            particle.style.borderRight = `${size/2}px solid transparent`;
            particle.style.width = '0';
            particle.style.height = '0';
        } else if (type === 'square') {
            particle.style.borderRadius = '4px';
        } else if (type === 'line') {
            particle.style.width = `${size * 3}px`;
            particle.style.height = '2px';
            particle.style.background = `linear-gradient(90deg, transparent, ${color}, transparent)`;
        }
        
        container.appendChild(particle);
    }
});
