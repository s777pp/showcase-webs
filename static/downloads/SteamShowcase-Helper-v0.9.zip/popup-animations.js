// Расширенные анимации для попапа (без волн)
function initCardAnimations() {
  const cards = document.querySelectorAll('.card');
  
  cards.forEach((card, index) => {
      card.style.transform = 'translateY(30px) rotateX(15deg) scale(0.95)';
      card.style.opacity = '0';
      card.style.filter = 'blur(2px)';
      card.style.transition = `all 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275) ${index * 0.1}s`;
      
      const glow = document.createElement('div');
      glow.className = 'card-glow';
      card.appendChild(glow);
      
      setTimeout(() => {
          card.style.transform = 'translateY(0) rotateX(0) scale(1)';
          card.style.opacity = '1';
          card.style.filter = 'blur(0)';
          
          glow.style.opacity = '1';
          glow.style.transform = 'scale(1.5)';
          
          setTimeout(() => {
              glow.style.opacity = '0';
              glow.style.transform = 'scale(1.2)';
              setTimeout(() => glow.remove(), 500);
          }, 300);
      }, 100 + index * 50);
      
      card.addEventListener('mousemove', (e) => {
          const rect = card.getBoundingClientRect();
          const x = e.clientX - rect.left;
          const y = e.clientY - rect.top;
          const centerX = rect.width / 2;
          const centerY = rect.height / 2;
          
          const angleX = (y - centerY) / 20;
          const angleY = (centerX - x) / 20;
          
          card.style.transform = `perspective(1000px) rotateX(${angleX}deg) rotateY(${angleY}deg) scale(1.03)`;
      });
      
      card.addEventListener('mouseleave', () => {
          card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
      });
  });
}

function initTitleAnimation() {
  const title = document.getElementById('title');
  if (!title) return;
  
  title.style.opacity = '0';
  title.style.transform = 'translateY(20px) scale(0.9)';
  title.style.textShadow = '0 0 20px rgba(102, 192, 244, 0)';
  title.style.transition = 'all 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.4)';
  
  setTimeout(() => {
      title.style.opacity = '1';
      title.style.transform = 'translateY(0) scale(1)';
      title.style.textShadow = '0 0 20px rgba(102, 192, 244, 0.5)';
      title.style.animation = 'textPulse 3s infinite alternate';
  }, 300);
}

function initLogoAnimation() {
  const logo = document.querySelector('.logo-inner');
  if (!logo) return;
  
  logo.style.transform = 'scale(0) rotate(180deg)';
  logo.style.opacity = '0';
  logo.style.transition = 'all 0.7s cubic-bezier(0.68, -0.55, 0.265, 1.55)';
  
  setTimeout(() => {
      logo.style.transform = 'scale(1) rotate(0)';
      logo.style.opacity = '1';
      logo.style.animation = 'logoFloat 6s ease-in-out infinite';
  }, 500);
}

function initButtonAnimations() {
  const buttons = document.querySelectorAll('button');
  
  buttons.forEach((button, index) => {
      button.style.transform = 'translateY(10px)';
      button.style.opacity = '0';
      button.style.transition = `all 0.4s ease ${0.3 + index * 0.1}s`;
      
      setTimeout(() => {
          button.style.transform = 'translateY(0)';
          button.style.opacity = '1';
      }, 500 + index * 50);
      
      button.addEventListener('mousedown', () => {
          button.style.transform = 'scale(0.95)';
      });
      
      button.addEventListener('mouseup', () => {
          button.style.transform = 'scale(1)';
      });
      
      button.addEventListener('mouseleave', () => {
          button.style.transform = 'scale(1)';
      });
  });
}

function initParticleEffect() {
  let container = document.querySelector('.particles-container');
  if (!container) {
      container = document.createElement('div');
      container.className = 'particles-container';
      document.body.insertBefore(container, document.body.firstChild);
  }
}

function initAdvancedEffects() {
  document.body.addEventListener('mousemove', (e) => {
      const x = e.clientX / window.innerWidth;
      const y = e.clientY / window.innerHeight;
      
      document.body.style.setProperty('--mouse-x', x);
      document.body.style.setProperty('--mouse-y', y);
  });
  
  const style = document.createElement('style');
  style.textContent = `
      @keyframes textPulse {
          0% { transform: scale(1); text-shadow: 0 0 10px var(--glowColor); }
          100% { transform: scale(1.02); text-shadow: 0 0 20px var(--glowColor); }
      }
      
      @keyframes logoFloat {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-10px) rotate(5deg); }
      }
      
      .particles-container {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: -1;
      }
      
      .particle {
          position: absolute;
          background: var(--particleColor);
          border-radius: 50%;
          animation: float 15s infinite linear;
      }
      
      @keyframes float {
          0% { transform: translateY(0) rotate(0deg); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateY(-500px) rotate(360deg); opacity: 0; }
      }
  `;
  document.head.appendChild(style);
}

function initAnimations() {
  initParticleEffect();
  initCardAnimations();
  initTitleAnimation();
  initLogoAnimation();
  initButtonAnimations();
  initAdvancedEffects();
  
  setTimeout(() => {
      document.body.classList.add('animations-complete');
  }, 1500);
}

if (document.readyState === 'complete' || document.readyState === 'interactive') {
  setTimeout(initAnimations, 100);
} else {
  document.addEventListener('DOMContentLoaded', initAnimations);
}
